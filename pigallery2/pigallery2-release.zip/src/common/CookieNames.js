"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CookieNames = void 0;
class CookieNames {
    static { this.lang = 'pigallery2-lang'; }
    static { this.session = 'pigallery2-session'; }
    static { this.configPriority = 'config-priority'; }
    static { this.configStyle = 'config-style'; }
}
exports.CookieNames = CookieNames;
