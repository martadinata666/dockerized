"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServerPG2ConfMap = exports.ServerSidePG2ConfAction = exports.PG2ConfMap = void 0;
const SortingMethods_1 = require("./entities/SortingMethods");
const Utils_1 = require("./Utils");
/**
 * This contains the action of the supported list of *.pg2conf files.
 * These files are passed down to the client as metaFiles (like photos and directories)
 */
exports.PG2ConfMap = {
    sorting: {}
};
Utils_1.Utils.enumToArray(SortingMethods_1.SortByTypes).forEach(kv => {
    if (!Utils_1.Utils.isValidEnumInt(SortingMethods_1.SortByDirectionalTypes, kv.key)) {
        exports.PG2ConfMap.sorting['.order_random.pg2conf'] = { method: kv.key, ascending: null };
        return;
    }
    exports.PG2ConfMap.sorting['.order_descending' + kv.value.toLowerCase() + '.pg2conf'] = { method: kv.key, ascending: false };
    exports.PG2ConfMap.sorting['.order_ascending' + kv.value.toLowerCase() + '.pg2conf'] = { method: kv.key, ascending: true };
});
/**
 * These files are processed on the server side,
 * do not get passed down to the client or saved to the DB
 */
var ServerSidePG2ConfAction;
(function (ServerSidePG2ConfAction) {
    // Enum always starts from 1 as !!0 === false
    ServerSidePG2ConfAction[ServerSidePG2ConfAction["SAVED_SEARCH"] = 1] = "SAVED_SEARCH";
})(ServerSidePG2ConfAction = exports.ServerSidePG2ConfAction || (exports.ServerSidePG2ConfAction = {}));
exports.ServerPG2ConfMap = {
    '.saved_searches.pg2conf': ServerSidePG2ConfAction.SAVED_SEARCH,
};
