"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomHeaders = void 0;
class CustomHeaders {
    static { this.dataVersion = 'PI-GALLERY2-DATA-VERSION'; }
}
exports.CustomHeaders = CustomHeaders;
