"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LRU = exports.Utils = void 0;
class Utils {
    static GUID() {
        const s4 = () => Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
        return s4() + s4() + '-' + s4() + s4();
    }
    static chunkArrays(arr, chunkSize) {
        const R = [];
        for (let i = 0; i < arr.length; i += chunkSize) {
            R.push(arr.slice(i, i + chunkSize));
        }
        return R;
    }
    static wait(time) {
        return new Promise((resolve) => {
            setTimeout(resolve, time);
        });
    }
    static removeNullOrEmptyObj(obj) {
        if (typeof obj !== 'object' || obj == null) {
            return obj;
        }
        const keys = Object.keys(obj);
        for (const key of keys) {
            if (obj[key] !== null && typeof obj[key] === 'object') {
                if (Utils.removeNullOrEmptyObj(obj[key])) {
                    if (Object.keys(obj[key]).length === 0) {
                        delete obj[key];
                    }
                }
            }
            else if (obj[key] === null) {
                delete obj[key];
            }
        }
        return obj;
    }
    static clone(object) {
        return JSON.parse(JSON.stringify(object));
    }
    static shallowClone(object) {
        const c = {};
        for (const e of Object.entries(object)) {
            c[e[0]] = e[1];
        }
        return c;
    }
    static zeroPrefix(value, length) {
        const ret = '00000' + value;
        return ret.substr(ret.length - length);
    }
    /**
     * Checks if the two input (let them be objects or arrays or just primitives) are equal
     */
    static equalsFilter(object, filter, skipProp = []) {
        if (typeof filter !== 'object' || filter == null) {
            return object === filter;
        }
        if (!object) {
            return false;
        }
        if (Array.isArray(object) && object.length !== filter.length) {
            return false;
        }
        const keys = Object.keys(filter);
        for (const key of keys) {
            if (skipProp.includes(key)) {
                continue;
            }
            if (typeof filter[key] === 'object') {
                if (Utils.equalsFilter(object[key], filter[key], skipProp) === false) {
                    return false;
                }
            }
            else if (object[key] !== filter[key]) {
                return false;
            }
        }
        return true;
    }
    static toIsoString(d) {
        if (!(d instanceof Date)) {
            d = new Date(d);
        }
        return d.getUTCFullYear() + '-' + d.getUTCMonth() + '-' + d.getUTCDate();
    }
    static makeUTCMidnight(d) {
        if (!(d instanceof Date)) {
            d = new Date(d);
        }
        d.setUTCHours(0);
        d.setUTCMinutes(0);
        d.setUTCSeconds(0);
        d.setUTCMilliseconds(0);
        return d;
    }
    static renderDataSize(size) {
        const postFixes = ['B', 'KB', 'MB', 'GB', 'TB'];
        let index = 0;
        while (size > 1000 && index < postFixes.length - 1) {
            size /= 1000;
            index++;
        }
        return size.toFixed(2) + postFixes[index];
    }
    static getUnique(arr) {
        return arr.filter((value, index, arr) => arr.indexOf(value) === index);
    }
    static createRange(from, to) {
        const arr = new Array(to - from + 1);
        let c = to - from + 1;
        while (c--) {
            arr[c] = to--;
        }
        return arr;
    }
    static canonizePath(path) {
        return path
            .replace(new RegExp('\\\\', 'g'), '/')
            .replace(new RegExp('/+', 'g'), '/');
    }
    static concatUrls(...args) {
        let url = '';
        for (const item of args) {
            if (item === '' || typeof item === 'undefined') {
                continue;
            }
            const part = item.replace(new RegExp('\\\\', 'g'), '/');
            if (part === '/' || part === './') {
                continue;
            }
            url += part + '/';
        }
        url = url.replace(/(https?:\/\/)|(\/){2,}/g, '$1$2');
        if (url.trim() === '') {
            url = './';
        }
        return url.substring(0, url.length - 1);
    }
    static updateKeys(targetObject, sourceObject) {
        Object.keys(sourceObject).forEach((key) => {
            if (typeof targetObject[key] === 'undefined') {
                return;
            }
            if (typeof targetObject[key] === 'object') {
                Utils.updateKeys(targetObject[key], sourceObject[key]);
            }
            else {
                targetObject[key] = sourceObject[key];
            }
        });
    }
    static setKeys(targetObject, sourceObject) {
        Object.keys(sourceObject).forEach((key) => {
            if (typeof targetObject[key] === 'object') {
                Utils.setKeys(targetObject[key], sourceObject[key]);
            }
            else {
                targetObject[key] = sourceObject[key];
            }
        });
    }
    static setKeysForced(targetObject, sourceObject) {
        Object.keys(sourceObject).forEach((key) => {
            if (typeof sourceObject[key] === 'object') {
                if (typeof targetObject[key] === 'undefined') {
                    targetObject[key] = {};
                }
                Utils.setKeysForced(targetObject[key], sourceObject[key]);
            }
            else {
                targetObject[key] = sourceObject[key];
            }
        });
    }
    static isValidEnumInt(EnumType, value) {
        return typeof EnumType[value] === 'string';
    }
    static enumToArray(EnumType) {
        const arr = [];
        for (const enumMember in EnumType) {
            // eslint-disable-next-line no-prototype-builtins
            if (!EnumType.hasOwnProperty(enumMember)) {
                continue;
            }
            const key = parseInt(enumMember, 10);
            if (key >= 0) {
                arr.push({ key, value: EnumType[enumMember] });
            }
        }
        return arr;
    }
    static findClosest(num, arr) {
        let curr = arr[0];
        let diff = Math.abs(num - curr);
        arr.forEach((value) => {
            const newDiff = Math.abs(num - value);
            if (newDiff < diff) {
                diff = newDiff;
                curr = value;
            }
        });
        return curr;
    }
    static findClosestinSorted(num, arr) {
        let curr = arr[0];
        let diff = Math.abs(num - curr);
        for (const item of arr) {
            const newDiff = Math.abs(num - item);
            if (newDiff > diff) {
                break;
            }
            diff = newDiff;
            curr = item;
        }
        return curr;
    }
    static isUInt32(value, max = 4294967295) {
        value = parseInt('' + value, 10);
        return !isNaN(value) && value >= 0 && value <= max;
    }
    static isInt32(value) {
        value = parseFloat('' + value);
        return !isNaN(value) && value >= -2147483648 && value <= 2147483647;
    }
    static isFloat32(value) {
        const E = Math.pow(10, 38);
        const nE = Math.pow(10, -38);
        return (!isNaN(value) &&
            ((value >= -3.402823466 * E && value <= -1.175494351 * nE) ||
                (value <= 3.402823466 * E && value >= 1.175494351 * nE)));
    }
    static getAnyX(num, arr, start = 0) {
        if (num <= 0 || num > arr.length || start >= arr.length) {
            return [];
        }
        if (num <= 1) {
            return arr.slice(start).map((e) => [e]);
        }
        if (num === arr.length - start) {
            return [arr.slice(start)];
        }
        const ret = [];
        for (let i = start; i < arr.length; ++i) {
            Utils.getAnyX(num - 1, arr, i + 1).forEach((a) => {
                a.push(arr[i]);
                ret.push(a);
            });
        }
        return ret;
    }
}
exports.Utils = Utils;
class LRU {
    constructor(size) {
        this.size = size;
        this.data = {};
    }
    set(key, value) {
        this.data[key] = { usage: Date.now(), value };
        if (Object.keys(this.data).length > this.size) {
            let oldestK = key;
            let oldest = this.data[oldestK].usage;
            for (const k in this.data) {
                if (this.data[k].usage < oldest) {
                    oldestK = k;
                    oldest = this.data[oldestK].usage;
                }
            }
            delete this.data[oldestK];
        }
    }
    get(key) {
        if (!this.data[key]) {
            return;
        }
        return this.data[key].value;
    }
}
exports.LRU = LRU;
