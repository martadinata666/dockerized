"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AutoCompleteItem = void 0;
class AutoCompleteItem {
    constructor(text, type = null) {
        this.text = text;
        this.type = type;
    }
    equals(other) {
        return this.text === other.text && this.type === other.type;
    }
}
exports.AutoCompleteItem = AutoCompleteItem;
