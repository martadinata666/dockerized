"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JobProgressStates = void 0;
var JobProgressStates;
(function (JobProgressStates) {
    JobProgressStates[JobProgressStates["running"] = 1] = "running";
    JobProgressStates[JobProgressStates["cancelling"] = 2] = "cancelling";
    JobProgressStates[JobProgressStates["interrupted"] = 3] = "interrupted";
    JobProgressStates[JobProgressStates["canceled"] = 4] = "canceled";
    JobProgressStates[JobProgressStates["finished"] = 5] = "finished";
    JobProgressStates[JobProgressStates["failed"] = 6] = "failed";
})(JobProgressStates = exports.JobProgressStates || (exports.JobProgressStates = {}));
