"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JobDTOUtils = exports.DefaultsJobs = void 0;
var DefaultsJobs;
(function (DefaultsJobs) {
    DefaultsJobs[DefaultsJobs["Indexing"] = 1] = "Indexing";
    DefaultsJobs[DefaultsJobs["Gallery Reset"] = 2] = "Gallery Reset";
    DefaultsJobs[DefaultsJobs["Video Converting"] = 3] = "Video Converting";
    DefaultsJobs[DefaultsJobs["Photo Converting"] = 4] = "Photo Converting";
    DefaultsJobs[DefaultsJobs["Thumbnail Generation"] = 5] = "Thumbnail Generation";
    DefaultsJobs[DefaultsJobs["Temp Folder Cleaning"] = 6] = "Temp Folder Cleaning";
    DefaultsJobs[DefaultsJobs["Album Cover Filling"] = 7] = "Album Cover Filling";
    DefaultsJobs[DefaultsJobs["Album Cover Reset"] = 8] = "Album Cover Reset";
    DefaultsJobs[DefaultsJobs["GPX Compression"] = 9] = "GPX Compression";
    DefaultsJobs[DefaultsJobs["Album Reset"] = 10] = "Album Reset";
    DefaultsJobs[DefaultsJobs["Delete Compressed GPX"] = 11] = "Delete Compressed GPX";
    DefaultsJobs[DefaultsJobs["Top Pick Sending"] = 12] = "Top Pick Sending";
})(DefaultsJobs = exports.DefaultsJobs || (exports.DefaultsJobs = {}));
exports.JobDTOUtils = {
    getHashName: (jobName, config = {}) => {
        const sorted = Object.keys(config).sort().reduce((ret, key) => `${ret},${key}:${JSON.stringify(config[key])}`, '');
        return jobName + '-' + JSON.stringify(sorted);
    },
};
