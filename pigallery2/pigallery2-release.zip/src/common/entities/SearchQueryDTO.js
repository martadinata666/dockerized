"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatePatternFrequency = exports.SearchQueryDTOUtils = exports.TextSearchQueryMatchTypes = exports.rangedTypePairs = exports.MetadataSearchQueryTypes = exports.RangeSearchQueryTypes = exports.MaxRangeSearchQueryTypes = exports.MinRangeSearchQueryTypes = exports.TextSearchQueryTypes = exports.ListSearchQueryTypes = exports.SearchQueryTypes = void 0;
var SearchQueryTypes;
(function (SearchQueryTypes) {
    SearchQueryTypes[SearchQueryTypes["AND"] = 1] = "AND";
    SearchQueryTypes[SearchQueryTypes["OR"] = 2] = "OR";
    SearchQueryTypes[SearchQueryTypes["SOME_OF"] = 3] = "SOME_OF";
    SearchQueryTypes[SearchQueryTypes["UNKNOWN_RELATION"] = 99999] = "UNKNOWN_RELATION";
    // non-text metadata
    // |- range types
    SearchQueryTypes[SearchQueryTypes["from_date"] = 10] = "from_date";
    SearchQueryTypes[SearchQueryTypes["to_date"] = 11] = "to_date";
    SearchQueryTypes[SearchQueryTypes["min_rating"] = 12] = "min_rating";
    SearchQueryTypes[SearchQueryTypes["max_rating"] = 13] = "max_rating";
    SearchQueryTypes[SearchQueryTypes["min_resolution"] = 14] = "min_resolution";
    SearchQueryTypes[SearchQueryTypes["max_resolution"] = 15] = "max_resolution";
    SearchQueryTypes[SearchQueryTypes["min_person_count"] = 16] = "min_person_count";
    SearchQueryTypes[SearchQueryTypes["max_person_count"] = 17] = "max_person_count";
    SearchQueryTypes[SearchQueryTypes["distance"] = 50] = "distance";
    SearchQueryTypes[SearchQueryTypes["orientation"] = 51] = "orientation";
    SearchQueryTypes[SearchQueryTypes["date_pattern"] = 60] = "date_pattern";
    // TEXT search types
    SearchQueryTypes[SearchQueryTypes["any_text"] = 100] = "any_text";
    SearchQueryTypes[SearchQueryTypes["caption"] = 101] = "caption";
    SearchQueryTypes[SearchQueryTypes["directory"] = 102] = "directory";
    SearchQueryTypes[SearchQueryTypes["file_name"] = 103] = "file_name";
    SearchQueryTypes[SearchQueryTypes["keyword"] = 104] = "keyword";
    SearchQueryTypes[SearchQueryTypes["person"] = 105] = "person";
    SearchQueryTypes[SearchQueryTypes["position"] = 106] = "position";
})(SearchQueryTypes = exports.SearchQueryTypes || (exports.SearchQueryTypes = {}));
exports.ListSearchQueryTypes = [
    SearchQueryTypes.AND,
    SearchQueryTypes.OR,
    SearchQueryTypes.SOME_OF,
];
exports.TextSearchQueryTypes = [
    SearchQueryTypes.any_text,
    SearchQueryTypes.caption,
    SearchQueryTypes.directory,
    SearchQueryTypes.file_name,
    SearchQueryTypes.keyword,
    SearchQueryTypes.person,
    SearchQueryTypes.position,
];
exports.MinRangeSearchQueryTypes = [
    SearchQueryTypes.from_date,
    SearchQueryTypes.min_rating,
    SearchQueryTypes.min_resolution,
];
exports.MaxRangeSearchQueryTypes = [
    SearchQueryTypes.to_date,
    SearchQueryTypes.max_rating,
    SearchQueryTypes.max_resolution,
];
exports.RangeSearchQueryTypes = exports.MinRangeSearchQueryTypes.concat(exports.MaxRangeSearchQueryTypes);
exports.MetadataSearchQueryTypes = [
    SearchQueryTypes.distance,
    SearchQueryTypes.orientation,
]
    .concat(exports.RangeSearchQueryTypes)
    .concat(exports.TextSearchQueryTypes);
exports.rangedTypePairs = {};
exports.rangedTypePairs[SearchQueryTypes.from_date] = SearchQueryTypes.to_date;
exports.rangedTypePairs[SearchQueryTypes.min_rating] = SearchQueryTypes.max_rating;
exports.rangedTypePairs[SearchQueryTypes.min_resolution] =
    SearchQueryTypes.max_resolution;
// add the other direction too
for (const key of Object.keys(exports.rangedTypePairs)) {
    exports.rangedTypePairs[exports.rangedTypePairs[key]] = key;
}
var TextSearchQueryMatchTypes;
(function (TextSearchQueryMatchTypes) {
    TextSearchQueryMatchTypes[TextSearchQueryMatchTypes["exact_match"] = 1] = "exact_match";
    TextSearchQueryMatchTypes[TextSearchQueryMatchTypes["like"] = 2] = "like";
})(TextSearchQueryMatchTypes = exports.TextSearchQueryMatchTypes || (exports.TextSearchQueryMatchTypes = {}));
exports.SearchQueryDTOUtils = {
    getRangedQueryPair: (type) => {
        if (exports.rangedTypePairs[type]) {
            return exports.rangedTypePairs[type];
        }
        throw new Error('Unknown ranged type');
    },
    negate: (query) => {
        switch (query.type) {
            case SearchQueryTypes.AND:
                query.type = SearchQueryTypes.OR;
                query.list = query.list.map((q) => exports.SearchQueryDTOUtils.negate(q));
                return query;
            case SearchQueryTypes.OR:
                query.type = SearchQueryTypes.AND;
                query.list = query.list.map((q) => exports.SearchQueryDTOUtils.negate(q));
                return query;
            case SearchQueryTypes.orientation:
                query.landscape = !query
                    .landscape;
                return query;
            case SearchQueryTypes.from_date:
            case SearchQueryTypes.to_date:
            case SearchQueryTypes.min_rating:
            case SearchQueryTypes.max_rating:
            case SearchQueryTypes.min_resolution:
            case SearchQueryTypes.max_resolution:
            case SearchQueryTypes.distance:
            case SearchQueryTypes.any_text:
            case SearchQueryTypes.person:
            case SearchQueryTypes.position:
            case SearchQueryTypes.keyword:
            case SearchQueryTypes.caption:
            case SearchQueryTypes.file_name:
            case SearchQueryTypes.directory:
                query.negate = !query.negate;
                return query;
            case SearchQueryTypes.SOME_OF:
                throw new Error('Some of not supported');
            default:
                throw new Error('Unknown type' + query.type);
        }
    },
};
var DatePatternFrequency;
(function (DatePatternFrequency) {
    DatePatternFrequency[DatePatternFrequency["every_week"] = 1] = "every_week";
    DatePatternFrequency[DatePatternFrequency["every_month"] = 2] = "every_month";
    DatePatternFrequency[DatePatternFrequency["every_year"] = 3] = "every_year";
    DatePatternFrequency[DatePatternFrequency["days_ago"] = 10] = "days_ago";
    DatePatternFrequency[DatePatternFrequency["weeks_ago"] = 11] = "weeks_ago";
    DatePatternFrequency[DatePatternFrequency["months_ago"] = 12] = "months_ago";
    DatePatternFrequency[DatePatternFrequency["years_ago"] = 13] = "years_ago";
})(DatePatternFrequency = exports.DatePatternFrequency || (exports.DatePatternFrequency = {}));
