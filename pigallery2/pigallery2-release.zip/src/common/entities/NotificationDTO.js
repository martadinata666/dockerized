"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationType = void 0;
var NotificationType;
(function (NotificationType) {
    NotificationType[NotificationType["error"] = 1] = "error";
    NotificationType[NotificationType["warning"] = 2] = "warning";
    NotificationType[NotificationType["info"] = 3] = "info";
})(NotificationType = exports.NotificationType || (exports.NotificationType = {}));
