"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserModificationRequest = void 0;
class UserModificationRequest {
    constructor(id) {
        this.id = id;
    }
}
exports.UserModificationRequest = UserModificationRequest;
