"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Message = void 0;
class Message {
    constructor(error, result) {
        this.error = null;
        this.result = null;
        this.error = error;
        this.result = result;
    }
}
exports.Message = Message;
