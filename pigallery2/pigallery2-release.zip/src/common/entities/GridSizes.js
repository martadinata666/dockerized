"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GridSizes = void 0;
var GridSizes;
(function (GridSizes) {
    GridSizes[GridSizes["extraSmall"] = 10] = "extraSmall";
    GridSizes[GridSizes["small"] = 20] = "small";
    GridSizes[GridSizes["medium"] = 30] = "medium";
    GridSizes[GridSizes["large"] = 40] = "large";
    GridSizes[GridSizes["extraLarge"] = 50] = "extraLarge";
})(GridSizes = exports.GridSizes || (exports.GridSizes = {}));
