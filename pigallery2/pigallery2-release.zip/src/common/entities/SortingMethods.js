"use strict";
/**
 * Warning: Enum Values in this file should be unique within the file!
 * */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GroupSortByTypes = exports.GroupByTypes = exports.SortByTypes = exports.GroupByBasicTypes = exports.SortByBasicTypes = exports.SortByDirectionalTypes = void 0;
var SortByDirectionalTypes;
(function (SortByDirectionalTypes) {
    SortByDirectionalTypes[SortByDirectionalTypes["Name"] = 10] = "Name";
    SortByDirectionalTypes[SortByDirectionalTypes["Date"] = 20] = "Date";
    SortByDirectionalTypes[SortByDirectionalTypes["Rating"] = 30] = "Rating";
    SortByDirectionalTypes[SortByDirectionalTypes["PersonCount"] = 40] = "PersonCount";
    SortByDirectionalTypes[SortByDirectionalTypes["FileSize"] = 50] = "FileSize";
})(SortByDirectionalTypes = exports.SortByDirectionalTypes || (exports.SortByDirectionalTypes = {}));
// These cant be set asc or desc
var SortByBasicTypes;
(function (SortByBasicTypes) {
    SortByBasicTypes[SortByBasicTypes["Random"] = 100] = "Random";
})(SortByBasicTypes = exports.SortByBasicTypes || (exports.SortByBasicTypes = {}));
// These cant be set asc or desc
var GroupByBasicTypes;
(function (GroupByBasicTypes) {
    GroupByBasicTypes[GroupByBasicTypes["NoGrouping"] = 200] = "NoGrouping";
})(GroupByBasicTypes = exports.GroupByBasicTypes || (exports.GroupByBasicTypes = {}));
/**
 * Order of these enums determines the order in the UI.
 * Keep spaces between the values, so new value can be added in between without changing the existing ones
 */
exports.SortByTypes = {
    ...SortByDirectionalTypes,
    ...SortByBasicTypes
};
exports.GroupByTypes = {
    ...SortByDirectionalTypes,
    ...GroupByBasicTypes
};
exports.GroupSortByTypes = {
    ...SortByDirectionalTypes,
    ...SortByBasicTypes,
    ...GroupByBasicTypes
};
