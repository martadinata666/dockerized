"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DirectoryDTOUtils = void 0;
const Utils_1 = require("../Utils");
exports.DirectoryDTOUtils = {
    addReferences: (dir) => {
        dir.media.forEach((media) => {
            media.directory = dir;
        });
        if (dir.metaFile) {
            dir.metaFile.forEach((file) => {
                file.directory = dir;
            });
        }
        if (dir.directories) {
            dir.directories.forEach((directory) => {
                exports.DirectoryDTOUtils.addReferences(directory);
                directory.parent = dir;
            });
        }
    },
    removeReferences: (dir) => {
        if (dir.cover) {
            dir.cover.directory = {
                path: dir.cover.directory.path,
                name: dir.cover.directory.name,
            };
            // make sure that it is not a same object as one of the photo in the media[]
            // as the next foreach would remove the directory
            dir.cover = Utils_1.Utils.clone(dir.cover);
        }
        if (dir.media) {
            dir.media.forEach((media) => {
                media.directory = null;
            });
        }
        if (dir.metaFile) {
            dir.metaFile.forEach((file) => {
                file.directory = null;
            });
        }
        if (dir.directories) {
            dir.directories.forEach((directory) => {
                exports.DirectoryDTOUtils.removeReferences(directory);
                directory.parent = null;
            });
        }
        delete dir.validCover; // should not go to the client side;
        return dir;
    },
};
