"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentWrapper = void 0;
const Utils_1 = require("../Utils");
const MediaDTO_1 = require("./MediaDTO");
class ContentWrapper {
    constructor(directory = null, searchResult = null, notModified) {
        if (directory) {
            this.directory = directory;
        }
        if (searchResult) {
            this.searchResult = searchResult;
        }
        if (notModified) {
            this.notModified = notModified;
        }
    }
    static mapify(cw, media, isSearchResult) {
        if (isSearchResult) {
            const k = JSON.stringify(media.directory);
            if (!cw.reverseMap.directories.has(k)) {
                cw.reverseMap.directories.set(k, cw.map.directories.length);
                cw.map.directories.push(media.directory);
            }
            // @ts-ignore
            media.d = cw.reverseMap.directories.get(k);
            delete media.directory;
        }
        // @ts-ignore
        media['n'] = media.name;
        delete media.name;
        if (typeof media.missingThumbnails !== 'undefined') {
            // @ts-ignore
            media['t'] = media.missingThumbnails;
            delete media.missingThumbnails;
        }
        if (media.metadata) {
            // @ts-ignore
            media.metadata['d'] = [media.metadata.size.width, media.metadata.size.height];
            delete media.metadata.size;
            // @ts-ignore
            media.metadata['s'] = media.metadata.fileSize;
            delete media.metadata.fileSize;
            // @ts-ignore
            media.metadata['t'] = media.metadata.creationDate / 1000; // skip millies
            delete media.metadata.creationDate;
            if (media.metadata.rating) {
                // @ts-ignore
                media.metadata['r'] = media.metadata.rating;
                delete media.metadata.rating;
            }
            if (media.metadata.caption) {
                // @ts-ignore
                media.metadata['a'] = media.metadata.caption;
                delete media.metadata.caption;
            }
            if (media.metadata.faces) {
                for (let i = 0; i < media.metadata.faces.length; ++i) {
                    const name = media.metadata.faces[i].name;
                    if (!cw.reverseMap.faces.has(name)) {
                        cw.reverseMap.faces.set(name, cw.map.faces.length);
                        cw.map.faces.push(name);
                    }
                    // @ts-ignore
                    media.metadata.faces[i] = [...media.metadata.faces[i].b, cw.reverseMap.faces.get(name)];
                }
                // @ts-ignore
                media.metadata['f'] = media.metadata.faces;
                delete media.metadata.faces;
            }
            if (media.metadata.keywords) {
                for (let i = 0; i < media.metadata.keywords.length; ++i) {
                    const k = media.metadata.keywords[i];
                    if (!cw.reverseMap.keywords.has(k)) {
                        cw.reverseMap.keywords.set(k, cw.map.keywords.length);
                        cw.map.keywords.push(k);
                    }
                    // @ts-ignore
                    media.metadata.keywords[i] = cw.reverseMap.keywords.get(k);
                }
                // @ts-ignore
                media.metadata['k'] = media.metadata.keywords;
                delete media.metadata.keywords;
            }
            const mapifyOne = (map, reverseMap, obj, key, mappedKey) => {
                // @ts-ignore
                const k = obj[key];
                if (!reverseMap.has(k)) {
                    reverseMap.set(k, map.length);
                    map.push(k);
                }
                // @ts-ignore
                obj[mappedKey] = reverseMap.get(k);
                delete obj[key];
            };
            if (media.metadata.cameraData) {
                if (media.metadata.cameraData.lens) {
                    mapifyOne(cw.map.lens, cw.reverseMap.lens, media.metadata.cameraData, 'lens', 'l');
                }
                if (media.metadata.cameraData.make) {
                    mapifyOne(cw.map.camera, cw.reverseMap.camera, media.metadata.cameraData, 'make', 'm');
                }
                if (media.metadata.cameraData.model) {
                    mapifyOne(cw.map.camera, cw.reverseMap.camera, media.metadata.cameraData, 'model', 'o');
                }
                if (media.metadata.cameraData.ISO) {
                    // @ts-ignore
                    media.metadata.cameraData['i'] = media.metadata.cameraData.ISO;
                    delete media.metadata.cameraData.ISO;
                }
                if (media.metadata.cameraData.fStop) {
                    // @ts-ignore
                    media.metadata.cameraData['s'] = media.metadata.cameraData.fStop;
                    delete media.metadata.cameraData.fStop;
                }
                if (media.metadata.cameraData.exposure) {
                    // @ts-ignore
                    media.metadata.cameraData['e'] = media.metadata.cameraData.exposure;
                    delete media.metadata.cameraData.exposure;
                }
                if (media.metadata.cameraData.focalLength) {
                    // @ts-ignore
                    media.metadata.cameraData['a'] = media.metadata.cameraData.focalLength;
                    delete media.metadata.cameraData.focalLength;
                }
                // @ts-ignore
                media.metadata['c'] = media.metadata.cameraData;
                delete media.metadata.cameraData;
            }
            if (media.metadata.positionData) {
                if (media.metadata.positionData.country) {
                    mapifyOne(cw.map.keywords, cw.reverseMap.keywords, media.metadata.positionData, 'country', 'c');
                }
                if (media.metadata.positionData.city) {
                    mapifyOne(cw.map.keywords, cw.reverseMap.keywords, media.metadata.positionData, 'city', 'cy');
                }
                if (media.metadata.positionData.state) {
                    mapifyOne(cw.map.keywords, cw.reverseMap.keywords, media.metadata.positionData, 'state', 's');
                }
                if (media.metadata.positionData.GPSData) {
                    // @ts-ignore
                    media.metadata.positionData['g'] = [media.metadata.positionData.GPSData.latitude, media.metadata.positionData.GPSData.longitude];
                    delete media.metadata.positionData.GPSData;
                }
                // @ts-ignore
                media.metadata['p'] = media.metadata.positionData;
                delete media.metadata.positionData;
            }
            // @ts-ignore
            media['m'] = media.metadata;
            delete media.metadata;
        }
    }
    static packMedia(cw, media, isSearchResult) {
        // clean up media
        for (let i = 0; i < media.length; ++i) {
            const m = media[i];
            delete m.id;
            if (m.directory) {
                if (isSearchResult) {
                    // keep the directory for search result
                    delete m.directory.id;
                }
                else {
                    // for gallery listing, photos belong to one directory,
                    // this can be deleted as the directory know its child
                    delete m.directory;
                }
            }
            if (MediaDTO_1.MediaDTOUtils.isPhoto(m)) {
                delete m.metadata.bitRate;
                delete m.metadata.duration;
                // compress faces
                if (m.metadata.faces) {
                    for (let j = 0; j < m.metadata.faces.length; ++j) {
                        const f = m.metadata.faces[j];
                        // @ts-ignore
                        f['b'] = [f.box.top, f.box.left, f.box.height, f.box.width];
                        delete f.box;
                    }
                }
                ContentWrapper.mapify(cw, m, isSearchResult);
            }
            else if (MediaDTO_1.MediaDTOUtils.isVideo(m)) {
                delete m.metadata.rating;
                delete m.metadata.caption;
                delete m.metadata.cameraData;
                delete m.metadata.keywords;
                delete m.metadata.faces;
                delete m.metadata.positionData;
                ContentWrapper.mapify(cw, m, isSearchResult);
            }
            Utils_1.Utils.removeNullOrEmptyObj(m);
        }
    }
    static packDirectory(cw, dir, isSearchResult = false) {
        if (dir.cover) {
            dir.cover.directory = {
                path: dir.cover.directory.path,
                name: dir.cover.directory.name,
            };
            // make sure that it is not a same object as one of the photo in the media[]
            // as the next foreach would remove the directory
            dir.cover = Utils_1.Utils.clone(dir.cover);
        }
        if (dir.media) {
            ContentWrapper.packMedia(cw, dir.media, isSearchResult);
        }
        if (dir.metaFile) {
            for (let i = 0; i < dir.metaFile.length; ++i) {
                if (isSearchResult) {
                    delete dir.metaFile[i].directory.id;
                }
                else {
                    delete dir.metaFile[i].directory;
                }
                delete dir.metaFile[i].id;
                ContentWrapper.mapify(cw, dir.metaFile[i], isSearchResult);
            }
        }
        if (dir.directories) {
            for (let i = 0; i < dir.directories.length; ++i) {
                ContentWrapper.packDirectory(cw, dir.directories[i]);
                delete dir.directories[i].parent;
            }
        }
        delete dir.validCover; // should not go to the client side;
    }
    static deMapify(cw, media, isSearchResult) {
        const deMapifyOne = (map, obj, key, mappedKey) => {
            // @ts-ignore
            obj[key] = map[obj[mappedKey]];
            // @ts-ignore
            delete obj[mappedKey];
        };
        if (isSearchResult) {
            deMapifyOne(cw.map.directories, media, 'directory', 'd');
        }
        // @ts-ignore
        if (media['n']) {
            // @ts-ignore
            media.name = media['n'];
            // @ts-ignore
            delete media['n'];
        }
        // @ts-ignore
        if (media['t']) {
            // @ts-ignore
            media.missingThumbnails = media['t'];
            // @ts-ignore
            delete media['t'];
        }
        // @ts-ignore
        if (media['m']) {
            // @ts-ignore
            media.metadata = media['m'];
            // @ts-ignore
            delete media['m'];
            media.metadata.size = {
                // @ts-ignore
                width: media.metadata['d'][0],
                // @ts-ignore
                height: media.metadata['d'][1],
            };
            // @ts-ignore
            delete media.metadata['d'];
            // @ts-ignore
            if (typeof media.metadata['t'] !== 'undefined') {
                // @ts-ignore
                media.metadata.creationDate = media.metadata['t'] * 1000;
                // @ts-ignore
                delete media.metadata['t'];
            }
            // @ts-ignore
            if (typeof media.metadata['r'] !== 'undefined') {
                // @ts-ignore
                media.metadata.rating = media.metadata['r'];
                // @ts-ignore
                delete media.metadata['r'];
            }
            // @ts-ignore
            if (typeof media.metadata['a'] !== 'undefined') {
                // @ts-ignore
                media.metadata.caption = media.metadata['a'];
                // @ts-ignore
                delete media.metadata['a'];
            }
            // @ts-ignore
            media.metadata.fileSize = media.metadata['s'];
            // @ts-ignore
            delete media.metadata['s'];
            // @ts-ignore
            if (media.metadata['f']) {
                // @ts-ignore
                media.metadata.faces = media.metadata['f'];
                // @ts-ignore
                delete media.metadata['f'];
                for (let j = 0; j < media.metadata.faces.length; ++j) {
                    // @ts-ignore
                    const boxArr = media.metadata.faces[j];
                    media.metadata.faces[j] = {
                        box: {
                            top: boxArr[0],
                            left: boxArr[1],
                            height: boxArr[2],
                            width: boxArr[3],
                        },
                        // @ts-ignore
                        name: boxArr[4]
                    };
                }
                for (let i = 0; i < media.metadata.faces.length; ++i) {
                    // @ts-ignore
                    media.metadata.faces[i].name = cw.map.faces[media.metadata.faces[i].name];
                }
            }
            // @ts-ignore
            if (media.metadata['k']) {
                // @ts-ignore
                media.metadata.keywords = media.metadata['k'];
                // @ts-ignore
                delete media.metadata['k'];
                for (let i = 0; i < media.metadata.keywords.length; ++i) {
                    // @ts-ignore
                    media.metadata.keywords[i] = cw.map.keywords[media.metadata.keywords[i]];
                }
            }
            // @ts-ignore
            if (media.metadata['c']) {
                // @ts-ignore
                media.metadata.cameraData = media.metadata.c;
                // @ts-ignore
                delete media.metadata.c;
                // @ts-ignore
                if (typeof media.metadata.cameraData.l !== 'undefined') {
                    deMapifyOne(cw.map.lens, media.metadata.cameraData, 'lens', 'l');
                }
                // @ts-ignore
                if (typeof media.metadata.cameraData.m !== 'undefined') {
                    deMapifyOne(cw.map.camera, media.metadata.cameraData, 'make', 'm');
                }
                // @ts-ignore
                if (typeof media.metadata.cameraData['o'] !== 'undefined') {
                    deMapifyOne(cw.map.camera, media.metadata.cameraData, 'model', 'o');
                }
                // @ts-ignore
                if (typeof media.metadata.cameraData['i'] !== 'undefined') {
                    // @ts-ignore
                    media.metadata.cameraData.ISO = media.metadata.cameraData['i'];
                    // @ts-ignore
                    delete media.metadata.cameraData['i'];
                }
                // @ts-ignore
                if (typeof media.metadata.cameraData['a'] !== 'undefined') {
                    // @ts-ignore
                    media.metadata.cameraData.focalLength = media.metadata.cameraData['a'];
                    // @ts-ignore
                    delete media.metadata.cameraData['a'];
                }
                // @ts-ignore
                if (typeof media.metadata.cameraData['e'] !== 'undefined') {
                    // @ts-ignore
                    media.metadata.cameraData.exposure = media.metadata.cameraData['e'];
                    // @ts-ignore
                    delete media.metadata.cameraData['e'];
                }
                // @ts-ignore
                if (typeof media.metadata.cameraData['s'] !== 'undefined') {
                    // @ts-ignore
                    media.metadata.cameraData.fStop = media.metadata.cameraData['s'];
                    // @ts-ignore
                    delete media.metadata.cameraData['s'];
                }
            }
            // @ts-ignore
            if (media.metadata['p']) {
                // @ts-ignore
                media.metadata.positionData = media.metadata.p;
                // @ts-ignore
                delete media.metadata.p;
                // @ts-ignore
                if (typeof media.metadata.positionData.c !== 'undefined') {
                    deMapifyOne(cw.map.keywords, media.metadata.positionData, 'country', 'c');
                }
                // @ts-ignore
                if (typeof media.metadata.positionData.cy !== 'undefined') {
                    deMapifyOne(cw.map.keywords, media.metadata.positionData, 'city', 'cy');
                }
                // @ts-ignore
                if (typeof media.metadata.positionData.s !== 'undefined') {
                    deMapifyOne(cw.map.keywords, media.metadata.positionData, 'state', 's');
                }
                // @ts-ignore
                if (media.metadata.positionData['g']) {
                    media.metadata.positionData.GPSData =
                        {
                            // @ts-ignore
                            latitude: media.metadata.positionData['g'][0],
                            // @ts-ignore
                            longitude: media.metadata.positionData['g'][1]
                        };
                    // @ts-ignore
                    delete media.metadata.positionData['g'];
                }
            }
        }
    }
    static unPackMedia(cw, dir, media, isSearchResult) {
        // clean up media
        for (let i = 0; i < media.length; ++i) {
            const m = media[i];
            ContentWrapper.deMapify(cw, m, isSearchResult);
            if (!isSearchResult) {
                m.directory = dir;
            }
        }
    }
    static unPackDirectory(cw, dir, isSearchResult = false) {
        if (dir.media) {
            ContentWrapper.unPackMedia(cw, dir, dir.media, isSearchResult);
        }
        if (dir.metaFile) {
            for (let i = 0; i < dir.metaFile.length; ++i) {
                if (!isSearchResult) {
                    dir.metaFile[i].directory = dir;
                }
                ContentWrapper.deMapify(cw, dir.metaFile[i], isSearchResult);
            }
        }
        if (dir.directories) {
            for (let i = 0; i < dir.directories.length; ++i) {
                ContentWrapper.unPackDirectory(cw, dir.directories[i]);
                if (!isSearchResult) {
                    dir.directories[i].parent = dir;
                }
            }
        }
    }
    static pack(cw) {
        // init CW for packing
        cw.map = {
            faces: [], keywords: [], lens: [],
            camera: [], directories: []
        };
        cw.reverseMap = {
            faces: new Map(), keywords: new Map(),
            lens: new Map(), camera: new Map(), directories: new Map()
        };
        if (cw.directory) {
            ContentWrapper.packDirectory(cw, cw.directory);
        }
        else if (cw.searchResult) {
            ContentWrapper.packDirectory(cw, cw.searchResult, true);
        }
        // remove empty maps
        for (const k in cw.map) {
            // @ts-ignore
            if (cw.map[k].length === 0) {
                // @ts-ignore
                delete cw.map[k];
            }
        }
        delete cw.reverseMap;
        return cw;
    }
    static unpack(cw) {
        if (!cw || cw.notModified) {
            return cw;
        }
        if (cw.directory) {
            ContentWrapper.unPackDirectory(cw, cw.directory);
        }
        else if (cw.searchResult) {
            ContentWrapper.unPackDirectory(cw, cw.searchResult, true);
        }
        delete cw.map;
        return cw;
    }
}
exports.ContentWrapper = ContentWrapper;
