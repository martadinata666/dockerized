"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaDTOUtils = void 0;
const SupportedFormats_1 = require("../SupportedFormats");
exports.MediaDTOUtils = {
    hasPositionData: (media) => {
        return (!!media.metadata.positionData &&
            !!(media.metadata.positionData.city ||
                media.metadata.positionData.state ||
                media.metadata.positionData.country ||
                (media.metadata.positionData.GPSData &&
                    media.metadata.positionData.GPSData.latitude &&
                    media.metadata.positionData.GPSData.longitude)));
    },
    isPhoto: (media) => {
        return !exports.MediaDTOUtils.isVideo(media);
    },
    isVideo: (media) => {
        const lower = media.name.toLowerCase();
        for (const ext of SupportedFormats_1.SupportedFormats.WithDots.Videos) {
            if (lower.endsWith(ext)) {
                return true;
            }
        }
        return false;
    },
    isVideoPath: (path) => {
        const lower = path.toLowerCase();
        for (const ext of SupportedFormats_1.SupportedFormats.WithDots.Videos) {
            if (lower.endsWith(ext)) {
                return true;
            }
        }
        return false;
    },
    isVideoTranscodingNeeded: (media) => {
        const lower = media.name.toLowerCase();
        for (const ext of SupportedFormats_1.SupportedFormats.WithDots.TranscodeNeed.Videos) {
            if (lower.endsWith(ext)) {
                return true;
            }
        }
        return false;
    },
    calcAspectRatio: (photo) => {
        return (photo.metadata.size.width / photo.metadata.size.height) || 1; // NaN should be treated as square photo
    },
    equals: (a, b) => {
        return a.directory.path === b.directory.path &&
            a.directory.name === b.directory.name &&
            a.name === b.name;
    }
};
