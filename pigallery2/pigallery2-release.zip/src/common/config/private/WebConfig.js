"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebConfig = void 0;
const tslib_1 = require("tslib");
/* eslint-disable @typescript-eslint/no-inferrable-types */
require("reflect-metadata");
const PrivateConfig_1 = require("./PrivateConfig");
const web_1 = require("typeconfig/web");
const common_1 = require("typeconfig/common");
let WebConfig = class WebConfig extends PrivateConfig_1.ServerConfig {
};
tslib_1.__decorate([
    (0, common_1.ConfigState)(),
    tslib_1.__metadata("design:type", Object)
], WebConfig.prototype, "State", void 0);
WebConfig = tslib_1.__decorate([
    (0, web_1.WebConfigClass)({ softReadonly: true })
], WebConfig);
exports.WebConfig = WebConfig;
