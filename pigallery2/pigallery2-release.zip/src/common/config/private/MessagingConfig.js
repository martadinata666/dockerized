"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessagingConfig = exports.EmailMessagingConfig = exports.EmailSMTPMessagingConfig = void 0;
const tslib_1 = require("tslib");
/* eslint-disable @typescript-eslint/no-inferrable-types */
const SubConfigClass_1 = require("../../../../node_modules/typeconfig/src/decorators/class/SubConfigClass");
const ClientConfig_1 = require("../public/ClientConfig");
const ConfigPropoerty_1 = require("../../../../node_modules/typeconfig/src/decorators/property/ConfigPropoerty");
if (typeof $localize === 'undefined') {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    global.$localize = (s) => s;
}
let EmailSMTPMessagingConfig = class EmailSMTPMessagingConfig {
    constructor() {
        this.host = '';
        this.port = 587;
        this.secure = false;
        this.requireTLS = true;
        this.user = '';
        this.password = '';
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Host`,
            priority: ClientConfig_1.ConfigPriority.advanced,
            hint: 'smtp.example.com'
        },
        description: $localize `SMTP host server`
    }),
    tslib_1.__metadata("design:type", String)
], EmailSMTPMessagingConfig.prototype, "host", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Port`,
            priority: ClientConfig_1.ConfigPriority.advanced,
        },
        description: $localize `SMTP server's port`
    }),
    tslib_1.__metadata("design:type", Number)
], EmailSMTPMessagingConfig.prototype, "port", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `isSecure`,
            priority: ClientConfig_1.ConfigPriority.advanced,
        },
        description: $localize `Is the connection secure. See https://nodemailer.com/smtp/#tls-options for more details`
    }),
    tslib_1.__metadata("design:type", Boolean)
], EmailSMTPMessagingConfig.prototype, "secure", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `TLS required`,
            priority: ClientConfig_1.ConfigPriority.advanced,
        },
        description: $localize `if this is true and secure is false then Nodemailer (used library in the background) tries to use STARTTLS. See https://nodemailer.com/smtp/#tls-options for more details`
    }),
    tslib_1.__metadata("design:type", Boolean)
], EmailSMTPMessagingConfig.prototype, "requireTLS", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `User`,
            priority: ClientConfig_1.ConfigPriority.advanced,
        },
        description: $localize `User to connect to the SMTP server.`
    }),
    tslib_1.__metadata("design:type", String)
], EmailSMTPMessagingConfig.prototype, "user", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Password`,
            priority: ClientConfig_1.ConfigPriority.advanced,
        },
        type: 'password',
        description: $localize `Password to connect to the SMTP server.`
    }),
    tslib_1.__metadata("design:type", String)
], EmailSMTPMessagingConfig.prototype, "password", void 0);
EmailSMTPMessagingConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], EmailSMTPMessagingConfig);
exports.EmailSMTPMessagingConfig = EmailSMTPMessagingConfig;
let EmailMessagingConfig = class EmailMessagingConfig {
    constructor() {
        this.emailFrom = 'noreply@pigallery2.com';
        this.smtp = new EmailSMTPMessagingConfig();
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Sender email`,
            priority: ClientConfig_1.ConfigPriority.advanced,
        },
        description: $localize `Some services do not allow sending from random e-mail addresses. Set this accordingly.`
    }),
    tslib_1.__metadata("design:type", String)
], EmailMessagingConfig.prototype, "emailFrom", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `SMTP`,
        }
    }),
    tslib_1.__metadata("design:type", EmailSMTPMessagingConfig)
], EmailMessagingConfig.prototype, "smtp", void 0);
EmailMessagingConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], EmailMessagingConfig);
exports.EmailMessagingConfig = EmailMessagingConfig;
let MessagingConfig = class MessagingConfig {
    constructor() {
        this.Email = new EmailMessagingConfig();
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Email`,
        },
        description: $localize `The app uses Nodemailer in the background for sending e-mails. Refer to https://nodemailer.com/usage/ if some options are not clear.`
    }),
    tslib_1.__metadata("design:type", EmailMessagingConfig)
], MessagingConfig.prototype, "Email", void 0);
MessagingConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], MessagingConfig);
exports.MessagingConfig = MessagingConfig;
