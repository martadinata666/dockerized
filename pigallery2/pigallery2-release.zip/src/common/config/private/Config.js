"use strict";
var PrivateConfigClass_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.Config = exports.PrivateConfigClass = void 0;
const tslib_1 = require("tslib");
/* eslint-disable @typescript-eslint/no-var-requires */
const PrivateConfig_1 = require("./PrivateConfig");
const crypto = require("crypto");
const path = require("path");
const node_1 = require("typeconfig/node");
const PasswordHelper_1 = require("../../../backend/model/PasswordHelper");
const NotifocationManager_1 = require("../../../backend/model/NotifocationManager");
const upTime = new Date().toISOString();
// TODO: Refactor Config to be injectable globally.
// This is a bad habit to let the Config know if its in a testing env.
const isTesting = process.env['NODE_ENV'] == true || ['afterEach', 'after', 'beforeEach', 'before', 'describe', 'it']
    .every((fn) => global[fn] instanceof Function);
let PrivateConfigClass = PrivateConfigClass_1 = class PrivateConfigClass extends PrivateConfig_1.ServerConfig {
    constructor() {
        super();
        if (!this.Server.sessionSecret || this.Server.sessionSecret.length === 0) {
            this.Server.sessionSecret = [
                crypto.randomBytes(256).toString('hex'),
                crypto.randomBytes(256).toString('hex'),
                crypto.randomBytes(256).toString('hex'),
            ];
        }
        this.Environment.appVersion =
            require('../../../../package.json').version;
        this.Environment.buildTime =
            require('../../../../package.json').buildTime;
        this.Environment.buildCommitHash =
            require('../../../../package.json').buildCommitHash;
        this.Environment.upTime = upTime;
        this.Environment.isDocker = !!process.env.PI_DOCKER;
    }
    async original() {
        const pc = node_1.ConfigClassBuilder.attachPrivateInterface(new PrivateConfigClass_1());
        try {
            await pc.load();
        }
        catch (e) {
            console.error('Error during loading original config. Reverting to defaults.');
            console.error(e);
        }
        return pc;
    }
};
PrivateConfigClass = PrivateConfigClass_1 = tslib_1.__decorate([
    (0, node_1.ConfigClass)({
        configPath: path.join(__dirname, !isTesting ? './../../../../config.json' : './../../../../test/backend/tmp/config.json'),
        crateConfigPathIfNotExists: isTesting,
        saveIfNotExist: true,
        attachDescription: true,
        enumsAsString: true,
        softReadonly: true,
        cli: {
            enable: {
                configPath: true,
                attachState: true,
                attachDescription: true,
                rewriteCLIConfig: true,
                rewriteENVConfig: true,
                enumsAsString: true,
                saveIfNotExist: true,
                exitOnConfig: true,
            },
            defaults: {
                enabled: true,
            },
        },
        onLoadedSync: async (config) => {
            let changed = false;
            for (let i = 0; i < config.Users.enforcedUsers.length; ++i) {
                const uc = config.Users.enforcedUsers[i];
                // encrypt password and save back to the config
                if (uc.password) {
                    if (!uc.encryptedPassword) {
                        uc.encryptedPassword = PasswordHelper_1.PasswordHelper.cryptPassword(uc.password);
                    }
                    uc.password = '';
                    changed = true;
                }
                if (!uc.encrypted) {
                    uc.encrypted = !!uc.encryptedPassword;
                    changed = true;
                }
                if (!uc.encrypted && !uc.password) {
                    throw new Error('Password error for enforced user: ' + uc.name);
                }
            }
            if (changed) {
                config.saveSync();
            }
        }
    }),
    tslib_1.__metadata("design:paramtypes", [])
], PrivateConfigClass);
exports.PrivateConfigClass = PrivateConfigClass;
exports.Config = node_1.ConfigClassBuilder.attachInterface(new PrivateConfigClass());
try {
    exports.Config.loadSync();
}
catch (e) {
    console.error('Error during loading config. Reverting to defaults.');
    console.error('This is most likely due to: 1) you added a bad configuration in the server.json OR 2) The configuration changed in the latest release.');
    console.error(e);
    NotifocationManager_1.NotificationManager.error('Cant load config. Reverting to default. This is most likely due to: 1) you added a bad configuration in the server.json OR 2) The configuration changed in the latest release.', (e.toString ? e.toString() : JSON.stringify(e)));
}
