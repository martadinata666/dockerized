"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServerConfig = exports.ServerEnvironmentConfig = exports.ServerServiceConfig = exports.ServerMediaConfig = exports.ServerAlbumCoverConfig = exports.ServerPhotoConfig = exports.PhotoConvertingConfig = exports.ServerVideoConfig = exports.VideoTranscodingConfig = exports.ServerJobConfig = exports.JobScheduleConfig = exports.AfterJobTriggerConfig = exports.PeriodicJobTriggerConfig = exports.ScheduledJobTriggerConfig = exports.NeverJobTriggerConfig = exports.ServerLogConfig = exports.ServerDuplicatesConfig = exports.ServerThreadingConfig = exports.ServerIndexingConfig = exports.ServerSharingConfig = exports.ServerMetaFileConfig = exports.ServerGPXCompressingConfig = exports.ServerThumbnailConfig = exports.ServerUserConfig = exports.ServerDataBaseConfig = exports.UserConfig = exports.SQLiteConfig = exports.MySQLConfig = exports.FFmpegPresets = exports.ReIndexingSensitivity = exports.SQLLogLevel = exports.LogLevel = exports.DatabaseType = void 0;
const tslib_1 = require("tslib");
/* eslint-disable @typescript-eslint/no-inferrable-types */
require("reflect-metadata");
const JobScheduleDTO_1 = require("../../entities/job/JobScheduleDTO");
const ClientConfig_1 = require("../public/ClientConfig");
const SubConfigClass_1 = require("typeconfig/src/decorators/class/SubConfigClass");
const ConfigPropoerty_1 = require("typeconfig/src/decorators/property/ConfigPropoerty");
const JobDTO_1 = require("../../entities/job/JobDTO");
const SearchQueryDTO_1 = require("../../entities/SearchQueryDTO");
const SortingMethods_1 = require("../../entities/SortingMethods");
const UserDTO_1 = require("../../entities/UserDTO");
const MessagingConfig_1 = require("./MessagingConfig");
if (typeof $localize === 'undefined') {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    global.$localize = (s) => s;
}
var DatabaseType;
(function (DatabaseType) {
    DatabaseType[DatabaseType["mysql"] = 2] = "mysql";
    DatabaseType[DatabaseType["sqlite"] = 3] = "sqlite";
})(DatabaseType = exports.DatabaseType || (exports.DatabaseType = {}));
var LogLevel;
(function (LogLevel) {
    LogLevel[LogLevel["error"] = 1] = "error";
    LogLevel[LogLevel["warn"] = 2] = "warn";
    LogLevel[LogLevel["info"] = 3] = "info";
    LogLevel[LogLevel["verbose"] = 4] = "verbose";
    LogLevel[LogLevel["debug"] = 5] = "debug";
    LogLevel[LogLevel["silly"] = 6] = "silly";
})(LogLevel = exports.LogLevel || (exports.LogLevel = {}));
var SQLLogLevel;
(function (SQLLogLevel) {
    SQLLogLevel[SQLLogLevel["none"] = 1] = "none";
    SQLLogLevel[SQLLogLevel["error"] = 2] = "error";
    SQLLogLevel[SQLLogLevel["all"] = 3] = "all";
})(SQLLogLevel = exports.SQLLogLevel || (exports.SQLLogLevel = {}));
var ReIndexingSensitivity;
(function (ReIndexingSensitivity) {
    // Order is important. It also used to do relative comparison.
    // Keep space between items for future
    ReIndexingSensitivity[ReIndexingSensitivity["never"] = 10] = "never";
    ReIndexingSensitivity[ReIndexingSensitivity["low"] = 20] = "low";
    ReIndexingSensitivity[ReIndexingSensitivity["medium"] = 30] = "medium";
    ReIndexingSensitivity[ReIndexingSensitivity["high"] = 40] = "high";
})(ReIndexingSensitivity = exports.ReIndexingSensitivity || (exports.ReIndexingSensitivity = {}));
var FFmpegPresets;
(function (FFmpegPresets) {
    FFmpegPresets[FFmpegPresets["ultrafast"] = 1] = "ultrafast";
    FFmpegPresets[FFmpegPresets["superfast"] = 2] = "superfast";
    FFmpegPresets[FFmpegPresets["veryfast"] = 3] = "veryfast";
    FFmpegPresets[FFmpegPresets["faster"] = 4] = "faster";
    FFmpegPresets[FFmpegPresets["fast"] = 5] = "fast";
    FFmpegPresets[FFmpegPresets["medium"] = 6] = "medium";
    FFmpegPresets[FFmpegPresets["slow"] = 7] = "slow";
    FFmpegPresets[FFmpegPresets["slower"] = 8] = "slower";
    FFmpegPresets[FFmpegPresets["veryslow"] = 9] = "veryslow";
    FFmpegPresets[FFmpegPresets["placebo"] = 10] = "placebo";
})(FFmpegPresets = exports.FFmpegPresets || (exports.FFmpegPresets = {}));
let MySQLConfig = class MySQLConfig {
    constructor() {
        this.host = 'localhost';
        this.port = 3306;
        this.database = 'pigallery2';
        this.username = '';
        this.password = '';
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        envAlias: 'MYSQL_HOST',
        tags: {
            name: $localize `Host`,
            uiResetNeeded: { server: true },
            priority: ClientConfig_1.ConfigPriority.advanced
        },
    }),
    tslib_1.__metadata("design:type", String)
], MySQLConfig.prototype, "host", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        envAlias: 'MYSQL_PORT', min: 0, max: 65535,
        tags: {
            name: $localize `Port`,
            uiResetNeeded: { server: true },
            priority: ClientConfig_1.ConfigPriority.advanced
        },
    }),
    tslib_1.__metadata("design:type", Number)
], MySQLConfig.prototype, "port", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        envAlias: 'MYSQL_DATABASE',
        tags: {
            name: $localize `Database`,
            uiResetNeeded: { server: true },
            priority: ClientConfig_1.ConfigPriority.advanced
        },
    }),
    tslib_1.__metadata("design:type", String)
], MySQLConfig.prototype, "database", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        envAlias: 'MYSQL_USERNAME',
        tags: {
            name: $localize `Username`,
            uiResetNeeded: { server: true },
            priority: ClientConfig_1.ConfigPriority.advanced
        },
    }),
    tslib_1.__metadata("design:type", String)
], MySQLConfig.prototype, "username", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        envAlias: 'MYSQL_PASSWORD', type: 'password',
        tags: {
            name: $localize `Password`,
            uiResetNeeded: { server: true },
            priority: ClientConfig_1.ConfigPriority.advanced
        }
    }),
    tslib_1.__metadata("design:type", String)
], MySQLConfig.prototype, "password", void 0);
MySQLConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], MySQLConfig);
exports.MySQLConfig = MySQLConfig;
let SQLiteConfig = class SQLiteConfig {
    constructor() {
        this.DBFileName = 'sqlite.db';
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Sqlite db filename`,
            uiResetNeeded: { server: true },
            priority: ClientConfig_1.ConfigPriority.underTheHood
        },
        description: $localize `Sqlite will save the db with this filename.`,
    }),
    tslib_1.__metadata("design:type", String)
], SQLiteConfig.prototype, "DBFileName", void 0);
SQLiteConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], SQLiteConfig);
exports.SQLiteConfig = SQLiteConfig;
let UserConfig = class UserConfig {
    constructor(name, password, role) {
        this.role = UserDTO_1.UserRoles.User;
        if (name) {
            this.name = name;
        }
        if (typeof role !== 'undefined') {
            this.role = role;
        }
        if (password) {
            this.password = password;
        }
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Name`,
            priority: ClientConfig_1.ConfigPriority.underTheHood
        }
    }),
    tslib_1.__metadata("design:type", String)
], UserConfig.prototype, "name", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: UserDTO_1.UserRoles,
        tags: {
            name: $localize `Role`,
            priority: ClientConfig_1.ConfigPriority.underTheHood
        },
    }),
    tslib_1.__metadata("design:type", Number)
], UserConfig.prototype, "role", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: 'string',
        tags: {
            name: $localize `Password`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
            relevant: (c) => !c.encrypted
        },
        description: $localize `Unencrypted, temporary password. App will encrypt it and delete this.`
    }),
    tslib_1.__metadata("design:type", String)
], UserConfig.prototype, "password", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Encrypted password`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
            secret: true
        },
    }),
    tslib_1.__metadata("design:type", String)
], UserConfig.prototype, "encryptedPassword", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            priority: ClientConfig_1.ConfigPriority.underTheHood,
            relevant: () => false // never render this on UI. Only used to indicate that encryption is done.
        },
    }),
    tslib_1.__metadata("design:type", Boolean)
], UserConfig.prototype, "encrypted", void 0);
UserConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true }),
    tslib_1.__metadata("design:paramtypes", [String, String, Number])
], UserConfig);
exports.UserConfig = UserConfig;
let ServerDataBaseConfig = class ServerDataBaseConfig {
    constructor() {
        this.type = DatabaseType.sqlite;
        this.dbFolder = 'db';
        this.sqlite = new SQLiteConfig();
        this.mysql = new MySQLConfig();
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: DatabaseType,
        tags: {
            name: $localize `Type`,
            priority: ClientConfig_1.ConfigPriority.advanced,
            uiResetNeeded: { db: true },
            githubIssue: 573
        },
        description: $localize `SQLite is recommended.`
    }),
    tslib_1.__metadata("design:type", Number)
], ServerDataBaseConfig.prototype, "type", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Database folder`,
            uiResetNeeded: { server: true },
            priority: ClientConfig_1.ConfigPriority.advanced
        },
        description: $localize `All file-based data will be stored here (sqlite database, job history data).`,
    }),
    tslib_1.__metadata("design:type", String)
], ServerDataBaseConfig.prototype, "dbFolder", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `SQLite`,
            uiResetNeeded: { db: true },
            relevant: (c) => c.type === DatabaseType.sqlite,
        }
    }),
    tslib_1.__metadata("design:type", SQLiteConfig)
], ServerDataBaseConfig.prototype, "sqlite", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `MySQL`,
            uiResetNeeded: { db: true },
            relevant: (c) => c.type === DatabaseType.mysql,
        }
    }),
    tslib_1.__metadata("design:type", MySQLConfig)
], ServerDataBaseConfig.prototype, "mysql", void 0);
ServerDataBaseConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], ServerDataBaseConfig);
exports.ServerDataBaseConfig = ServerDataBaseConfig;
let ServerUserConfig = class ServerUserConfig extends ClientConfig_1.ClientUserConfig {
    constructor() {
        super(...arguments);
        this.enforcedUsers = [];
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        arrayType: UserConfig,
        tags: {
            name: $localize `Enforced users`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
            uiResetNeeded: { server: true },
            uiOptional: true,
            githubIssue: 575
        },
        description: $localize `Creates these users in the DB during startup if they do not exist. If a user with this name exist, it won't be overwritten, even if the role is different.`,
    }),
    tslib_1.__metadata("design:type", Array)
], ServerUserConfig.prototype, "enforcedUsers", void 0);
ServerUserConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], ServerUserConfig);
exports.ServerUserConfig = ServerUserConfig;
let ServerThumbnailConfig = class ServerThumbnailConfig extends ClientConfig_1.ClientThumbnailConfig {
    constructor() {
        super(...arguments);
        this.useLanczos3 = true;
        this.quality = 80;
        this.smartSubsample = true;
        this.personFaceMargin = 0.7; // in ratio [0-1]
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `High quality resampling`,
            priority: ClientConfig_1.ConfigPriority.underTheHood
        },
        description: $localize `if true, 'lanczos3' will used to scale photos, otherwise faster but lower quality 'nearest'.`
    }),
    tslib_1.__metadata("design:type", Boolean)
], ServerThumbnailConfig.prototype, "useLanczos3", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        max: 100, min: 1, type: 'unsignedInt',
        tags: {
            name: $localize `Converted photo and thumbnail quality`,
            priority: ClientConfig_1.ConfigPriority.underTheHood
        },
        description: $localize `Between 0-100.`
    }),
    tslib_1.__metadata("design:type", Object)
], ServerThumbnailConfig.prototype, "quality", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: 'boolean',
        tags: {
            name: $localize `Use chroma subsampling`,
            priority: ClientConfig_1.ConfigPriority.underTheHood
        },
        description: $localize `Use high quality chroma subsampling in webp. See: https://sharp.pixelplumbing.com/api-output#webp.`
    }),
    tslib_1.__metadata("design:type", Object)
], ServerThumbnailConfig.prototype, "smartSubsample", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: 'float',
        tags: {
            name: $localize `Person face margin`,
            priority: ClientConfig_1.ConfigPriority.underTheHood
        },
        description: $localize `This ratio of the face bounding box will be added to the face as a margin. Higher number add more margin.`
    }),
    tslib_1.__metadata("design:type", Number)
], ServerThumbnailConfig.prototype, "personFaceMargin", void 0);
ServerThumbnailConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], ServerThumbnailConfig);
exports.ServerThumbnailConfig = ServerThumbnailConfig;
let ServerGPXCompressingConfig = class ServerGPXCompressingConfig extends ClientConfig_1.ClientGPXCompressingConfig {
    constructor() {
        super(...arguments);
        this.onTheFly = true;
        this.minDistance = 5;
        this.maxMiddleDeviance = 5;
        this.minTimeDistance = 5000;
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `OnTheFly *.gpx compression`,
            priority: ClientConfig_1.ConfigPriority.advanced,
            uiDisabled: (sc, c) => !c.Map.enabled || !sc.enabled || !c.MetaFile.gpx
        },
        description: $localize `Enables on the fly *.gpx compression.`,
    }),
    tslib_1.__metadata("design:type", Boolean)
], ServerGPXCompressingConfig.prototype, "onTheFly", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: 'unsignedInt',
        tags: {
            name: $localize `Min distance`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
            unit: 'm',
            uiDisabled: (sc, c) => !c.Map.enabled || !sc.enabled || !c.MetaFile.gpx
        },
        description: $localize `Filters out entry that are closer than this to each other in meters.`
    }),
    tslib_1.__metadata("design:type", Number)
], ServerGPXCompressingConfig.prototype, "minDistance", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: 'unsignedInt',
        tags: {
            name: $localize `Max middle point deviance`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
            unit: 'm',
            uiDisabled: (sc, c) => !c.Map.enabled || !sc.enabled || !c.MetaFile.gpx
        },
        description: $localize `Filters out entry that would fall on the line if we would just connect the previous and the next points. This setting sets the sensitivity for that (higher number, more points are filtered).`
    }),
    tslib_1.__metadata("design:type", Number)
], ServerGPXCompressingConfig.prototype, "maxMiddleDeviance", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: 'unsignedInt',
        tags: {
            name: $localize `Min time delta`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
            unit: 'ms',
            uiDisabled: (sc, c) => !c.Map.enabled || !sc.enabled || !c.MetaFile.gpx
        },
        description: $localize `Filters out entry that are closer than this in time in milliseconds.`
    }),
    tslib_1.__metadata("design:type", Number)
], ServerGPXCompressingConfig.prototype, "minTimeDistance", void 0);
ServerGPXCompressingConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], ServerGPXCompressingConfig);
exports.ServerGPXCompressingConfig = ServerGPXCompressingConfig;
let ServerMetaFileConfig = class ServerMetaFileConfig extends ClientConfig_1.ClientMetaFileConfig {
    constructor() {
        super(...arguments);
        this.GPXCompressing = new ServerGPXCompressingConfig();
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `GPX compression`,
            priority: ClientConfig_1.ConfigPriority.advanced,
            uiJob: [{
                    job: JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['GPX Compression']],
                    relevant: (c) => c.MetaFile.GPXCompressing.enabled
                }, {
                    job: JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Delete Compressed GPX']],
                    relevant: (c) => c.MetaFile.GPXCompressing.enabled
                }]
        }
    }),
    tslib_1.__metadata("design:type", ServerGPXCompressingConfig)
], ServerMetaFileConfig.prototype, "GPXCompressing", void 0);
ServerMetaFileConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], ServerMetaFileConfig);
exports.ServerMetaFileConfig = ServerMetaFileConfig;
let ServerSharingConfig = class ServerSharingConfig extends ClientConfig_1.ClientSharingConfig {
    constructor() {
        super(...arguments);
        this.updateTimeout = 1000 * 60 * 5;
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: 'unsignedInt',
        tags: {
            name: $localize `Update timeout`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
            unit: 'ms'
        },
        description: $localize `After creating a sharing link, it can be updated for this long.`
    }),
    tslib_1.__metadata("design:type", Number)
], ServerSharingConfig.prototype, "updateTimeout", void 0);
ServerSharingConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], ServerSharingConfig);
exports.ServerSharingConfig = ServerSharingConfig;
let ServerIndexingConfig = class ServerIndexingConfig {
    constructor() {
        this.cachedFolderTimeout = 1000 * 60 * 60; // Do not rescans the folder if seems ok
        this.reIndexingSensitivity = ReIndexingSensitivity.low;
        this.excludeFolderList = ['.Trash-1000', '.dtrash', '$RECYCLE.BIN'];
        this.excludeFileList = [];
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: 'unsignedInt',
        tags: {
            name: $localize `Index cache timeout`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
            unit: 'ms'
        },
        description: $localize `If there was no indexing in this time, it reindexes. (skipped if indexes are in DB and sensitivity is low).`
    }),
    tslib_1.__metadata("design:type", Number)
], ServerIndexingConfig.prototype, "cachedFolderTimeout", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: ReIndexingSensitivity,
        tags: {
            name: $localize `Folder reindexing sensitivity`,
            priority: ClientConfig_1.ConfigPriority.advanced
        },
        description: $localize `Set the reindexing sensitivity. High value check the folders for change more often.  Setting to never only indexes if never indexed or explicit running the Indexing Job.`
    }),
    tslib_1.__metadata("design:type", Number)
], ServerIndexingConfig.prototype, "reIndexingSensitivity", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        arrayType: 'string',
        tags: {
            name: $localize `Exclude Folder List`,
            priority: ClientConfig_1.ConfigPriority.advanced,
            uiResetNeeded: { server: true, db: true },
            uiOptional: true,
            uiAllowSpaces: true
        },
        description: $localize `Folders to exclude from indexing. If an entry starts with '/' it is treated as an absolute path. If it doesn't start with '/' but contains a '/', the path is relative to the image directory. If it doesn't contain a '/', any folder with this name will be excluded.`,
    }),
    tslib_1.__metadata("design:type", Array)
], ServerIndexingConfig.prototype, "excludeFolderList", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        arrayType: 'string',
        tags: {
            name: $localize `Exclude File List`,
            priority: ClientConfig_1.ConfigPriority.advanced,
            uiResetNeeded: { server: true, db: true },
            uiOptional: true,
            hint: $localize `.ignore;.pg2ignore`
        },
        description: $localize `Files that mark a folder to be excluded from indexing. Any folder that contains a file with this name will be excluded from indexing.`,
    }),
    tslib_1.__metadata("design:type", Array)
], ServerIndexingConfig.prototype, "excludeFileList", void 0);
ServerIndexingConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], ServerIndexingConfig);
exports.ServerIndexingConfig = ServerIndexingConfig;
let ServerThreadingConfig = class ServerThreadingConfig {
    constructor() {
        this.enabled = false;
        this.thumbnailThreads = 0; // if zero-> CPU count -1
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Threading`,
            uiResetNeeded: { server: true },
            priority: ClientConfig_1.ConfigPriority.underTheHood,
        },
        description: $localize `[Deprecated, will be removed in the next release] Runs directory scanning and thumbnail generation in a different thread.`
    }),
    tslib_1.__metadata("design:type", Boolean)
], ServerThreadingConfig.prototype, "enabled", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Thumbnail threads`,
            uiResetNeeded: { server: true },
            priority: ClientConfig_1.ConfigPriority.underTheHood
        },
        description: $localize `Number of threads that are used to generate thumbnails. If 0, number of 'CPU cores -1' threads will be used.`,
    }),
    tslib_1.__metadata("design:type", Number)
], ServerThreadingConfig.prototype, "thumbnailThreads", void 0);
ServerThreadingConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], ServerThreadingConfig);
exports.ServerThreadingConfig = ServerThreadingConfig;
let ServerDuplicatesConfig = class ServerDuplicatesConfig {
    constructor() {
        this.listingLimit = 1000;
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: 'unsignedInt',
        tags: {
            name: $localize `Max duplicates`,
            priority: ClientConfig_1.ConfigPriority.underTheHood
        },
        description: $localize `Maximum number of duplicates to list.`
    }),
    tslib_1.__metadata("design:type", Number)
], ServerDuplicatesConfig.prototype, "listingLimit", void 0);
ServerDuplicatesConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], ServerDuplicatesConfig);
exports.ServerDuplicatesConfig = ServerDuplicatesConfig;
let ServerLogConfig = class ServerLogConfig {
    constructor() {
        this.level = LogLevel.info;
        this.sqlLevel = SQLLogLevel.error;
        this.logServerTiming = false;
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: LogLevel,
        tags: {
            name: $localize `Level`,
            priority: ClientConfig_1.ConfigPriority.advanced,
        },
        description: $localize `Logging level.`
    }),
    tslib_1.__metadata("design:type", Number)
], ServerLogConfig.prototype, "level", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: SQLLogLevel,
        tags: {
            name: $localize `Sql Level`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
        },
        description: $localize `Logging level for SQL queries.`
    }),
    tslib_1.__metadata("design:type", Number)
], ServerLogConfig.prototype, "sqlLevel", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Server timing`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
        },
        description: $localize `If enabled, the app ads "Server-Timing" http header to the response.`
    }),
    tslib_1.__metadata("design:type", Boolean)
], ServerLogConfig.prototype, "logServerTiming", void 0);
ServerLogConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], ServerLogConfig);
exports.ServerLogConfig = ServerLogConfig;
let NeverJobTriggerConfig = class NeverJobTriggerConfig {
    constructor() {
        this.type = JobScheduleDTO_1.JobTriggerType.never;
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({ type: JobScheduleDTO_1.JobTriggerType }),
    tslib_1.__metadata("design:type", Object)
], NeverJobTriggerConfig.prototype, "type", void 0);
NeverJobTriggerConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], NeverJobTriggerConfig);
exports.NeverJobTriggerConfig = NeverJobTriggerConfig;
let ScheduledJobTriggerConfig = class ScheduledJobTriggerConfig {
    constructor() {
        this.type = JobScheduleDTO_1.JobTriggerType.scheduled;
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({ type: JobScheduleDTO_1.JobTriggerType }),
    tslib_1.__metadata("design:type", Object)
], ScheduledJobTriggerConfig.prototype, "type", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({ type: 'unsignedInt' }),
    tslib_1.__metadata("design:type", Number)
], ScheduledJobTriggerConfig.prototype, "time", void 0);
ScheduledJobTriggerConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], ScheduledJobTriggerConfig);
exports.ScheduledJobTriggerConfig = ScheduledJobTriggerConfig;
let PeriodicJobTriggerConfig = class PeriodicJobTriggerConfig {
    constructor() {
        this.type = JobScheduleDTO_1.JobTriggerType.periodic;
        this.periodicity = 7; // 0-6: week days 7 every day
        this.atTime = 0; // day time
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({ type: JobScheduleDTO_1.JobTriggerType }),
    tslib_1.__metadata("design:type", Object)
], PeriodicJobTriggerConfig.prototype, "type", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({ type: 'unsignedInt', max: 7 }),
    tslib_1.__metadata("design:type", Number)
], PeriodicJobTriggerConfig.prototype, "periodicity", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({ type: 'unsignedInt', max: 23 * 60 + 59 }),
    tslib_1.__metadata("design:type", Number)
], PeriodicJobTriggerConfig.prototype, "atTime", void 0);
PeriodicJobTriggerConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], PeriodicJobTriggerConfig);
exports.PeriodicJobTriggerConfig = PeriodicJobTriggerConfig;
let AfterJobTriggerConfig = class AfterJobTriggerConfig {
    constructor(afterScheduleName) {
        this.type = JobScheduleDTO_1.JobTriggerType.after;
        this.afterScheduleName = afterScheduleName;
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({ type: JobScheduleDTO_1.JobTriggerType }),
    tslib_1.__metadata("design:type", Object)
], AfterJobTriggerConfig.prototype, "type", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)(),
    tslib_1.__metadata("design:type", String)
], AfterJobTriggerConfig.prototype, "afterScheduleName", void 0);
AfterJobTriggerConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true }),
    tslib_1.__metadata("design:paramtypes", [String])
], AfterJobTriggerConfig);
exports.AfterJobTriggerConfig = AfterJobTriggerConfig;
let JobScheduleConfig = class JobScheduleConfig {
    constructor(name, jobName, trigger, config = {}, allowParallelRun = false) {
        this.config = {};
        this.allowParallelRun = false;
        this.name = name;
        this.jobName = jobName;
        this.config = config;
        this.allowParallelRun = allowParallelRun;
        this.trigger = trigger;
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)(),
    tslib_1.__metadata("design:type", String)
], JobScheduleConfig.prototype, "name", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)(),
    tslib_1.__metadata("design:type", String)
], JobScheduleConfig.prototype, "jobName", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)(),
    tslib_1.__metadata("design:type", Object)
], JobScheduleConfig.prototype, "config", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)(),
    tslib_1.__metadata("design:type", Boolean)
], JobScheduleConfig.prototype, "allowParallelRun", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: NeverJobTriggerConfig,
        typeBuilder: (v) => {
            const type = typeof v.type === 'number' ? v.type : JobScheduleDTO_1.JobTriggerType[v.type];
            switch (type) {
                case JobScheduleDTO_1.JobTriggerType.after:
                    return AfterJobTriggerConfig;
                case JobScheduleDTO_1.JobTriggerType.never:
                    return NeverJobTriggerConfig;
                case JobScheduleDTO_1.JobTriggerType.scheduled:
                    return ScheduledJobTriggerConfig;
                case JobScheduleDTO_1.JobTriggerType.periodic:
                    return PeriodicJobTriggerConfig;
            }
            return null;
        },
    }),
    tslib_1.__metadata("design:type", Object)
], JobScheduleConfig.prototype, "trigger", void 0);
JobScheduleConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true }),
    tslib_1.__metadata("design:paramtypes", [String, String, Object, Object, Boolean])
], JobScheduleConfig);
exports.JobScheduleConfig = JobScheduleConfig;
let ServerJobConfig = class ServerJobConfig {
    constructor() {
        this.maxSavedProgress = 20;
        this.mediaProcessingBatchSize = 1000;
        this.scheduled = [
            new JobScheduleConfig(JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs.Indexing], JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs.Indexing], new NeverJobTriggerConfig(), { indexChangesOnly: true } // set config explicitly, so it is not undefined on the UI
            ),
            new JobScheduleConfig(JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Album Cover Filling']], JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Album Cover Filling']], new AfterJobTriggerConfig(JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Indexing']]), {}),
            new JobScheduleConfig(JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Thumbnail Generation']], JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Thumbnail Generation']], new AfterJobTriggerConfig(JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Album Cover Filling']]), { sizes: [240], indexedOnly: true }),
            new JobScheduleConfig(JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Photo Converting']], JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Photo Converting']], new AfterJobTriggerConfig(JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Thumbnail Generation']]), { indexedOnly: true }),
            new JobScheduleConfig(JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Video Converting']], JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Video Converting']], new AfterJobTriggerConfig(JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Photo Converting']]), { indexedOnly: true }),
            new JobScheduleConfig(JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['GPX Compression']], JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['GPX Compression']], new AfterJobTriggerConfig(JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Video Converting']]), { indexedOnly: true }),
            new JobScheduleConfig(JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Temp Folder Cleaning']], JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Temp Folder Cleaning']], new AfterJobTriggerConfig(JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['GPX Compression']]), { indexedOnly: true }),
        ];
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: 'unsignedInt',
        tags: {
            name: $localize `Max saved progress`,
            priority: ClientConfig_1.ConfigPriority.underTheHood
        },
        description: $localize `Job history size.`
    }),
    tslib_1.__metadata("design:type", Number)
], ServerJobConfig.prototype, "maxSavedProgress", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: 'unsignedInt',
        tags: {
            name: $localize `Processing batch size`,
            priority: ClientConfig_1.ConfigPriority.underTheHood
        },
        description: $localize `Jobs load this many photos or videos form the DB for processing at once.`
    }),
    tslib_1.__metadata("design:type", Number)
], ServerJobConfig.prototype, "mediaProcessingBatchSize", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        arrayType: JobScheduleConfig,
        tags: {
            name: $localize `Scheduled jobs`,
            priority: ClientConfig_1.ConfigPriority.advanced
        }
    }),
    tslib_1.__metadata("design:type", Array)
], ServerJobConfig.prototype, "scheduled", void 0);
ServerJobConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], ServerJobConfig);
exports.ServerJobConfig = ServerJobConfig;
let VideoTranscodingConfig = class VideoTranscodingConfig {
    constructor() {
        this.bitRate = 5 * 1024 * 1024;
        this.resolution = 720;
        this.fps = 25;
        this.format = 'mp4';
        this.mp4Codec = 'libx264';
        this.webmCodec = 'libvpx';
        this.crf = 23;
        this.preset = FFmpegPresets.medium;
        this.customOutputOptions = [];
        this.customInputOptions = [];
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: 'unsignedInt',
        tags: {
            name: $localize `Bit rate`,
            priority: ClientConfig_1.ConfigPriority.advanced,
            unit: 'bps'
        },
        description: $localize `Target bit rate of the output video will be scaled down this this. This should be less than the upload rate of your home server.`
    }),
    tslib_1.__metadata("design:type", Number)
], VideoTranscodingConfig.prototype, "bitRate", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: 'unsignedInt',
        tags: {
            name: $localize `Resolution`,
            priority: ClientConfig_1.ConfigPriority.advanced,
            uiOptions: [720, 1080, 1440, 2160, 4320],
            unit: 'px'
        },
        description: $localize `The height of the output video will be scaled down to this, while keeping the aspect ratio.`
    }),
    tslib_1.__metadata("design:type", Number)
], VideoTranscodingConfig.prototype, "resolution", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: 'positiveFloat',
        tags: {
            name: $localize `FPS`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
            uiOptions: [24, 25, 30, 48, 50, 60]
        },
        description: $localize `Target frame per second (fps) of the output video will be scaled down this this.`
    }),
    tslib_1.__metadata("design:type", Number)
], VideoTranscodingConfig.prototype, "fps", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Format`,
            priority: ClientConfig_1.ConfigPriority.advanced,
            uiOptions: ['mp4', 'webm']
        }
    }),
    tslib_1.__metadata("design:type", String)
], VideoTranscodingConfig.prototype, "format", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `MP4 codec`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
            uiOptions: ['libx264', 'libx265'],
            relevant: (c) => c.format === 'mp4'
        }
    }),
    tslib_1.__metadata("design:type", String)
], VideoTranscodingConfig.prototype, "mp4Codec", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Webm Codec`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
            uiOptions: ['libvpx', 'libvpx-vp9'],
            relevant: (c) => c.format === 'webm'
        }
    }),
    tslib_1.__metadata("design:type", String)
], VideoTranscodingConfig.prototype, "webmCodec", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: 'unsignedInt', max: 51,
        tags: {
            name: $localize `CRF`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
        },
        description: $localize `The range of the Constant Rate Factor (CRF) scale is 0–51, where 0 is lossless, 23 is the default, and 51 is worst quality possible.`,
    }),
    tslib_1.__metadata("design:type", Number)
], VideoTranscodingConfig.prototype, "crf", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: FFmpegPresets,
        tags: {
            name: $localize `Preset`,
            priority: ClientConfig_1.ConfigPriority.advanced,
        },
        description: $localize `A preset is a collection of options that will provide a certain encoding speed to compression ratio. A slower preset will provide better compression (compression is quality per filesize).`,
    }),
    tslib_1.__metadata("design:type", Number)
], VideoTranscodingConfig.prototype, "preset", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        arrayType: 'string',
        tags: {
            name: $localize `Custom Output Options`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
            hint: '-pass 2;-minrate 1M;-maxrate 1M;-bufsize 2M',
            uiAllowSpaces: true
        },
        description: $localize `It will be sent to ffmpeg as it is, as custom output options.`,
    }),
    tslib_1.__metadata("design:type", Array)
], VideoTranscodingConfig.prototype, "customOutputOptions", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        arrayType: 'string',
        tags: {
            name: $localize `Custom Input Options`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
            hint: '-option1; -option2 param2; -option3; -option4 param4',
            githubIssue: 592,
            uiAllowSpaces: true
        },
        description: $localize `It will be sent to ffmpeg as it is, as custom input options.`,
    }),
    tslib_1.__metadata("design:type", Array)
], VideoTranscodingConfig.prototype, "customInputOptions", void 0);
VideoTranscodingConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], VideoTranscodingConfig);
exports.VideoTranscodingConfig = VideoTranscodingConfig;
let ServerVideoConfig = class ServerVideoConfig extends ClientConfig_1.ClientVideoConfig {
    constructor() {
        super(...arguments);
        this.transcoding = new VideoTranscodingConfig();
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Video transcoding`,
            priority: ClientConfig_1.ConfigPriority.advanced,
            uiDisabled: (sb) => !sb.enabled
        },
        description: $localize `To ensure smooth video playback, video transcoding is recommended to a lower bit rate than the server's upload rate.   The transcoded videos will be save to the thumbnail folder.  You can trigger the transcoding manually, but you can also create an automatic encoding job in advanced settings mode.`
    }),
    tslib_1.__metadata("design:type", VideoTranscodingConfig)
], ServerVideoConfig.prototype, "transcoding", void 0);
ServerVideoConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], ServerVideoConfig);
exports.ServerVideoConfig = ServerVideoConfig;
let PhotoConvertingConfig = class PhotoConvertingConfig extends ClientConfig_1.ClientPhotoConvertingConfig {
    constructor() {
        super(...arguments);
        this.onTheFly = true;
        this.resolution = 1080;
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `On the fly converting`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
            uiDisabled: (sc) => !sc.enabled
        },
        description: $localize `Converts photos on the fly, when they are requested.`,
    }),
    tslib_1.__metadata("design:type", Boolean)
], PhotoConvertingConfig.prototype, "onTheFly", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: 'unsignedInt',
        tags: {
            name: $localize `Resolution`,
            priority: ClientConfig_1.ConfigPriority.advanced,
            uiOptions: [720, 1080, 1440, 2160, 4320],
            unit: 'px',
            uiDisabled: (sc) => !sc.enabled
        },
        description: $localize `The shorter edge of the converted photo will be scaled down to this, while keeping the aspect ratio.`,
    }),
    tslib_1.__metadata("design:type", Number)
], PhotoConvertingConfig.prototype, "resolution", void 0);
PhotoConvertingConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], PhotoConvertingConfig);
exports.PhotoConvertingConfig = PhotoConvertingConfig;
let ServerPhotoConfig = class ServerPhotoConfig extends ClientConfig_1.ClientPhotoConfig {
    constructor() {
        super(...arguments);
        this.Converting = new PhotoConvertingConfig();
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Photo resizing`,
            priority: ClientConfig_1.ConfigPriority.advanced,
        }
    }),
    tslib_1.__metadata("design:type", PhotoConvertingConfig)
], ServerPhotoConfig.prototype, "Converting", void 0);
ServerPhotoConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], ServerPhotoConfig);
exports.ServerPhotoConfig = ServerPhotoConfig;
let ServerAlbumCoverConfig = class ServerAlbumCoverConfig {
    constructor() {
        this.SearchQuery = {
            type: SearchQueryDTO_1.SearchQueryTypes.any_text,
            text: '',
        };
        this.Sorting = [
            new ClientConfig_1.ClientSortingConfig(SortingMethods_1.SortByTypes.Rating, false),
            new ClientConfig_1.ClientSortingConfig(SortingMethods_1.SortByTypes.Date, false),
            new ClientConfig_1.ClientSortingConfig(SortingMethods_1.SortByTypes.PersonCount, false)
        ];
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: 'object',
        tags: {
            name: $localize `Cover Filter query`,
            uiResetNeeded: { db: true },
            priority: ClientConfig_1.ConfigPriority.advanced,
            uiType: 'SearchQuery'
        },
        description: $localize `Filters the sub-folders with this search query. If filter results no photo, the app will search again without the filter.`,
    }),
    tslib_1.__metadata("design:type", Object)
], ServerAlbumCoverConfig.prototype, "SearchQuery", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        arrayType: ClientConfig_1.ClientSortingConfig,
        tags: {
            name: $localize `Cover Sorting`,
            uiResetNeeded: { db: true },
            priority: ClientConfig_1.ConfigPriority.advanced
        },
        description: $localize `If multiple cover is available sorts them by these methods and selects the first one.`,
    }),
    tslib_1.__metadata("design:type", Array)
], ServerAlbumCoverConfig.prototype, "Sorting", void 0);
ServerAlbumCoverConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], ServerAlbumCoverConfig);
exports.ServerAlbumCoverConfig = ServerAlbumCoverConfig;
let ServerMediaConfig = class ServerMediaConfig extends ClientConfig_1.ClientMediaConfig {
    constructor() {
        super(...arguments);
        this.folder = 'demo/images';
        this.tempFolder = 'demo/tmp';
        this.photoMetadataSize = 512 * 1024; // only this many bites will be loaded when scanning photo for metadata
        this.Video = new ServerVideoConfig();
        this.Photo = new ServerPhotoConfig();
        this.Thumbnail = new ServerThumbnailConfig();
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Images folder`,
            priority: ClientConfig_1.ConfigPriority.basic,
            uiResetNeeded: { server: true },
            dockerSensitive: true
        },
        description: $localize `Images are loaded from this folder (read permission required)`,
    }),
    tslib_1.__metadata("design:type", String)
], ServerMediaConfig.prototype, "folder", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Temp folder`,
            uiResetNeeded: { server: true },
            priority: ClientConfig_1.ConfigPriority.basic,
            dockerSensitive: true
        },
        description: $localize `Thumbnails, converted photos, videos will be stored here (write permission required)`,
    }),
    tslib_1.__metadata("design:type", String)
], ServerMediaConfig.prototype, "tempFolder", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: 'unsignedInt',
        tags: {
            name: $localize `Metadata read buffer`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
            uiResetNeeded: { db: true, server: true },
            githubIssue: 398,
            unit: 'bytes'
        },
        description: $localize `Only this many bites will be loaded when scanning photo/video for metadata. Increase this number if your photos shows up as square.`,
    }),
    tslib_1.__metadata("design:type", Number)
], ServerMediaConfig.prototype, "photoMetadataSize", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Video`,
            uiIcon: 'ionVideocamOutline',
            priority: ClientConfig_1.ConfigPriority.advanced,
            uiJob: [
                {
                    job: JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Video Converting']],
                    relevant: (c) => c.Media.Video.enabled
                }
            ]
        },
        description: $localize `Video support uses ffmpeg. ffmpeg and ffprobe binaries need to be available in the PATH or the @ffmpeg-installer/ffmpeg and @ffprobe-installer/ffprobe optional node packages need to be installed.`
    }),
    tslib_1.__metadata("design:type", ServerVideoConfig)
], ServerMediaConfig.prototype, "Video", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Photo`,
            uiIcon: 'ionCameraOutline',
            priority: ClientConfig_1.ConfigPriority.advanced,
            uiJob: [
                {
                    job: JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Photo Converting']],
                    relevant: (c) => c.Media.Photo.Converting.enabled
                }
            ]
        }
    }),
    tslib_1.__metadata("design:type", ServerPhotoConfig)
], ServerMediaConfig.prototype, "Photo", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Thumbnail`,
            uiIcon: 'ionImageOutline',
            priority: ClientConfig_1.ConfigPriority.advanced,
            uiJob: [{ job: JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Thumbnail Generation']] }]
        }
    }),
    tslib_1.__metadata("design:type", ServerThumbnailConfig)
], ServerMediaConfig.prototype, "Thumbnail", void 0);
ServerMediaConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], ServerMediaConfig);
exports.ServerMediaConfig = ServerMediaConfig;
let ServerServiceConfig = class ServerServiceConfig extends ClientConfig_1.ClientServiceConfig {
    constructor() {
        super(...arguments);
        this.sessionSecret = [];
        this.sessionTimeout = 1000 * 60 * 60 * 24 * 7; // in ms
        this.port = 80;
        this.host = '0.0.0.0';
        this.Threading = new ServerThreadingConfig();
        this.Log = new ServerLogConfig();
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        arrayType: 'string',
        tags: {
            secret: true,
            name: 'sessionSecret'
        }
    }),
    tslib_1.__metadata("design:type", Array)
], ServerServiceConfig.prototype, "sessionSecret", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        type: 'unsignedInt',
        tags: {
            name: $localize `Session Timeout`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
            unit: 'ms'
        },
        description: $localize `Users kept logged in for this long time.`,
    }),
    tslib_1.__metadata("design:type", Number)
], ServerServiceConfig.prototype, "sessionTimeout", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Port`,
            priority: ClientConfig_1.ConfigPriority.advanced,
            uiResetNeeded: { server: true },
            dockerSensitive: true
        },
        description: $localize `Port number. Port 80 is usually what you need.`,
        type: 'unsignedInt', envAlias: 'PORT', min: 0, max: 65535
    }),
    tslib_1.__metadata("design:type", Number)
], ServerServiceConfig.prototype, "port", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Host`,
            priority: ClientConfig_1.ConfigPriority.advanced,
            uiResetNeeded: { server: true },
            dockerSensitive: true
        },
        description: $localize `Server will accept connections from this IPv6 or IPv4 address.`,
    }),
    tslib_1.__metadata("design:type", String)
], ServerServiceConfig.prototype, "host", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Threading`,
            priority: ClientConfig_1.ConfigPriority.underTheHood,
        }
    }),
    tslib_1.__metadata("design:type", ServerThreadingConfig)
], ServerServiceConfig.prototype, "Threading", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Logs`,
            priority: ClientConfig_1.ConfigPriority.advanced,
        }
    }),
    tslib_1.__metadata("design:type", ServerLogConfig)
], ServerServiceConfig.prototype, "Log", void 0);
ServerServiceConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], ServerServiceConfig);
exports.ServerServiceConfig = ServerServiceConfig;
let ServerEnvironmentConfig = class ServerEnvironmentConfig {
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({ volatile: true }),
    tslib_1.__metadata("design:type", String)
], ServerEnvironmentConfig.prototype, "upTime", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({ volatile: true }),
    tslib_1.__metadata("design:type", String)
], ServerEnvironmentConfig.prototype, "appVersion", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({ volatile: true }),
    tslib_1.__metadata("design:type", String)
], ServerEnvironmentConfig.prototype, "buildTime", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({ volatile: true }),
    tslib_1.__metadata("design:type", String)
], ServerEnvironmentConfig.prototype, "buildCommitHash", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({ volatile: true }),
    tslib_1.__metadata("design:type", Boolean)
], ServerEnvironmentConfig.prototype, "isDocker", void 0);
ServerEnvironmentConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], ServerEnvironmentConfig);
exports.ServerEnvironmentConfig = ServerEnvironmentConfig;
let ServerConfig = class ServerConfig extends ClientConfig_1.ClientConfig {
    constructor() {
        super(...arguments);
        this.Environment = new ServerEnvironmentConfig();
        this.Server = new ServerServiceConfig();
        this.Database = new ServerDataBaseConfig();
        this.Users = new ServerUserConfig();
        this.Indexing = new ServerIndexingConfig();
        this.Media = new ServerMediaConfig();
        this.MetaFile = new ServerMetaFileConfig();
        this.AlbumCover = new ServerAlbumCoverConfig();
        this.Sharing = new ServerSharingConfig();
        this.Duplicates = new ServerDuplicatesConfig();
        this.Messaging = new MessagingConfig_1.MessagingConfig();
        this.Jobs = new ServerJobConfig();
    }
};
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({ volatile: true }),
    tslib_1.__metadata("design:type", ServerEnvironmentConfig)
], ServerConfig.prototype, "Environment", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Server`,
            uiIcon: 'ionCloudOutline'
        },
    }),
    tslib_1.__metadata("design:type", ServerServiceConfig)
], ServerConfig.prototype, "Server", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Database`,
            uiIcon: 'ionServerOutline'
        }
    }),
    tslib_1.__metadata("design:type", ServerDataBaseConfig)
], ServerConfig.prototype, "Database", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Users`,
            uiIcon: 'ionPersonOutline'
        },
    }),
    tslib_1.__metadata("design:type", ServerUserConfig)
], ServerConfig.prototype, "Users", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Indexing`,
            uiIcon: 'ionFileTrayFullOutline',
            uiJob: [
                {
                    job: JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs.Indexing],
                    description: $localize `If you add a new folder to your gallery, the site indexes it automatically.  If you would like to trigger indexing manually, click index button. (Note: search only works among the indexed directories.)`
                }, {
                    job: JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Gallery Reset']],
                    hideProgress: true
                }
            ]
        }
    }),
    tslib_1.__metadata("design:type", ServerIndexingConfig)
], ServerConfig.prototype, "Indexing", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Media`,
            uiIcon: 'ionImagesOutline'
        },
    }),
    tslib_1.__metadata("design:type", ServerMediaConfig)
], ServerConfig.prototype, "Media", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Meta file`,
            uiIcon: 'ionDocumentOutline'
        },
    }),
    tslib_1.__metadata("design:type", ServerMetaFileConfig)
], ServerConfig.prototype, "MetaFile", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Album cover`,
            uiIcon: 'ionImageOutline',
            githubIssue: 679,
            uiJob: [
                {
                    job: JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Album Cover Filling']],
                }, {
                    job: JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Album Cover Reset']],
                    hideProgress: true
                }
            ]
        },
        description: $localize `Specify a search query and sorting that the app can use to pick the best photo for an album and folder cover. There is no way to manually pick folder and album cover in the app. You can tag some of your photos with 'cover' and set that as search query or rate them to 5 and set sorting to descending by rating.`
    }),
    tslib_1.__metadata("design:type", ServerAlbumCoverConfig)
], ServerConfig.prototype, "AlbumCover", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Sharing`,
            uiIcon: 'ionShareSocialOutline'
        },
    }),
    tslib_1.__metadata("design:type", ServerSharingConfig)
], ServerConfig.prototype, "Sharing", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Duplicates`,
            uiIcon: 'ionCopyOutline'
        }
    }),
    tslib_1.__metadata("design:type", ServerDuplicatesConfig)
], ServerConfig.prototype, "Duplicates", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Messaging`,
            uiIcon: 'ionChatboxOutline',
            githubIssue: 683
        },
        description: $localize `The App can send messages (like photos on the same day a year ago. aka: "Top Pick"). Here you can configure the delivery method.`
    }),
    tslib_1.__metadata("design:type", MessagingConfig_1.MessagingConfig)
], ServerConfig.prototype, "Messaging", void 0);
tslib_1.__decorate([
    (0, ConfigPropoerty_1.ConfigProperty)({
        tags: {
            name: $localize `Jobs`,
            uiIcon: 'ionPlayOutline'
        }
    }),
    tslib_1.__metadata("design:type", ServerJobConfig)
], ServerConfig.prototype, "Jobs", void 0);
ServerConfig = tslib_1.__decorate([
    (0, SubConfigClass_1.SubConfigClass)({ softReadonly: true })
], ServerConfig);
exports.ServerConfig = ServerConfig;
