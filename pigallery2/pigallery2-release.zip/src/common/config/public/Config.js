"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Config = exports.ClientClass = void 0;
const tslib_1 = require("tslib");
const ClientConfig_1 = require("./ClientConfig");
const WebConfigClass_1 = require("typeconfig/src/decorators/class/WebConfigClass");
const WebConfigClassBuilder_1 = require("typeconfig/src/decorators/builders/WebConfigClassBuilder");
/**
 * These configuration will be available at frontend and backend too
 */
let ClientClass = class ClientClass extends ClientConfig_1.ClientConfig {
};
ClientClass = tslib_1.__decorate([
    (0, WebConfigClass_1.WebConfigClass)()
], ClientClass);
exports.ClientClass = ClientClass;
exports.Config = WebConfigClassBuilder_1.WebConfigClassBuilder.attachInterface(new ClientClass());
if (typeof ServerInject !== 'undefined' &&
    typeof ServerInject.ConfigInject !== 'undefined') {
    exports.Config.load(ServerInject.ConfigInject);
}
if (exports.Config.Server.publicUrl === '') {
    exports.Config.Server.publicUrl = location.origin;
}
