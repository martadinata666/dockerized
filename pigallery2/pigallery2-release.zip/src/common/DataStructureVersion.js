"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DataStructureVersion = void 0;
/**
 * This version indicates that the sql/entities/*Entity.ts files got changed and the db needs to be recreated
 */
exports.DataStructureVersion = 34;
