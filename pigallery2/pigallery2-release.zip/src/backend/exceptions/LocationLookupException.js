"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocationLookupException = void 0;
class LocationLookupException extends Error {
    constructor(message, location) {
        super(message);
        this.location = location;
    }
}
exports.LocationLookupException = LocationLookupException;
