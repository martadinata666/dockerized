"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const cluster = require("cluster");
const server_1 = require("./server");
const Worker_1 = require("./model/threading/Worker");
const ConfigDiagnostics_1 = require("./model/diagnostics/ConfigDiagnostics");
if ((process.argv || []).includes('--run-diagnostics')) {
    console.log('Running diagnostics and exiting.');
    ConfigDiagnostics_1.ConfigDiagnostics.runDiagnostics().catch((e) => {
        console.error(e);
        process.exit(1);
    }).then(() => {
        process.exit(0);
    });
}
else {
    if (cluster.isMaster) {
        new server_1.Server();
    }
    else {
        Worker_1.Worker.process();
    }
}
