"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Logger = void 0;
const Config_1 = require("../common/config/private/Config");
const PrivateConfig_1 = require("../common/config/private/PrivateConfig");
const forcedDebug = process.env['NODE_ENV'] === 'debug';
if (forcedDebug === true) {
    console.log('NODE_ENV environmental variable is set to debug, forcing all logs to print');
}
class Logger {
    static silly(...args) {
        if (!forcedDebug && Config_1.Config.Server.Log.level < PrivateConfig_1.LogLevel.silly) {
            return;
        }
        Logger.log(`[\x1b[35mSILLY\x1b[0m]`, ...args);
    }
    static debug(...args) {
        if (!forcedDebug && Config_1.Config.Server.Log.level < PrivateConfig_1.LogLevel.debug) {
            return;
        }
        Logger.log(`[\x1b[34mDEBUG\x1b[0m]`, ...args);
    }
    static verbose(...args) {
        if (!forcedDebug && Config_1.Config.Server.Log.level < PrivateConfig_1.LogLevel.verbose) {
            return;
        }
        Logger.log(`[\x1b[36mVERBS\x1b[0m]`, ...args);
    }
    static info(...args) {
        if (!forcedDebug && Config_1.Config.Server.Log.level < PrivateConfig_1.LogLevel.info) {
            return;
        }
        Logger.log(`[\x1b[32mINFO_\x1b[0m]`, ...args);
    }
    static warn(...args) {
        if (!forcedDebug && Config_1.Config.Server.Log.level < PrivateConfig_1.LogLevel.warn) {
            return;
        }
        Logger.log(`[\x1b[33mWARN_\x1b[0m]`, ...args);
    }
    static error(...args) {
        Logger.log(`[\x1b[31mERROR\x1b[0m]`, ...args);
    }
    static log(tag, ...args) {
        const date = new Date().toLocaleString();
        let LOG_TAG = '';
        if (args.length > 0 &&
            typeof args[0] === 'string' &&
            args[0].startsWith('[') &&
            args[0].endsWith(']')) {
            LOG_TAG = args[0];
            args.shift();
        }
        console.log(date + tag + LOG_TAG, ...args);
    }
}
exports.Logger = Logger;
