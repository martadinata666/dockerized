"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublicRouter = void 0;
const path = require("path");
const fs = require("fs");
const ejs = require("ejs");
const Config_1 = require("../../common/config/private/Config");
const ProjectPath_1 = require("../ProjectPath");
const AuthenticationMWs_1 = require("../middlewares/user/AuthenticationMWs");
const CookieNames_1 = require("../../common/CookieNames");
const Error_1 = require("../../common/entities/Error");
const QueryParams_1 = require("../../common/QueryParams");
const PhotoProcessing_1 = require("../model/fileprocessing/PhotoProcessing");
class PublicRouter {
    static route(app) {
        const setLocale = (req, res, next) => {
            let selectedLocale = req.locale;
            if (req.cookies && req.cookies[CookieNames_1.CookieNames.lang]) {
                if (Config_1.Config.Server.languages.indexOf(req.cookies[CookieNames_1.CookieNames.lang]) !== -1) {
                    selectedLocale = req.cookies[CookieNames_1.CookieNames.lang];
                }
            }
            res.cookie(CookieNames_1.CookieNames.lang, selectedLocale);
            req.localePath = selectedLocale;
            next();
        };
        // index.html should not be cached as it contains template that can change
        const renderIndex = (req, res, next) => {
            ejs.renderFile(path.join(ProjectPath_1.ProjectPath.FrontendFolder, req.localePath, 'index.html'), res.tpl, (err, str) => {
                if (err) {
                    return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, err.message));
                }
                res.send(str);
            });
        };
        const redirectToBase = (locale) => {
            return (req, res) => {
                if (Config_1.Config.Server.languages.indexOf(locale) !== -1) {
                    res.cookie(CookieNames_1.CookieNames.lang, locale);
                }
                res.redirect('/?ln=' + locale);
            };
        };
        const addTPl = (req, res, next) => {
            res.tpl = {};
            res.tpl.user = null;
            if (req.session['user']) {
                res.tpl.user = {
                    id: req.session['user'].id,
                    name: req.session['user'].name,
                    csrfToken: req.session['user'].csrfToken,
                    role: req.session['user'].role,
                    usedSharingKey: req.session['user'].usedSharingKey,
                    permissions: req.session['user'].permissions,
                };
                if (!res.tpl.user.csrfToken && req.csrfToken) {
                    res.tpl.user.csrfToken = req.csrfToken();
                }
            }
            const confCopy = Config_1.Config.toJSON({
                attachVolatile: true,
                skipTags: { secret: true },
                keepTags: { client: true }
            });
            // Escaping html tags, like <script></script>
            confCopy.Server.customHTMLHead =
                confCopy.Server.customHTMLHead
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;')
                    .replace(/"/g, '&quot;')
                    .replace(/'/g, '&#039;');
            res.tpl.Config = confCopy;
            res.tpl.customHTMLHead = Config_1.Config.Server.customHTMLHead;
            const selectedTheme = Config_1.Config.Gallery.Themes.availableThemes.find(th => th.name === Config_1.Config.Gallery.Themes.selectedTheme)?.theme || '';
            res.tpl.usedTheme = selectedTheme;
            return next();
        };
        app.use(addTPl);
        app.get('/heartbeat', (req, res) => {
            res.sendStatus(200);
        });
        app.get('/manifest.json', (req, res) => {
            res.send({
                name: Config_1.Config.Server.applicationTitle,
                icons: [
                    {
                        src: 'icon_auto.svg',
                        sizes: 'any',
                        type: 'image/svg+xml',
                        purpose: 'any'
                    },
                    {
                        src: 'icon_padding_auto.svg',
                        sizes: 'any',
                        type: 'image/svg+xml',
                        purpose: 'maskable'
                    },
                    {
                        src: 'icon_white.png',
                        sizes: '48x48 72x72 96x96 128x128 256x256',
                    },
                ],
                display: 'standalone',
                categories: [
                    'photo'
                ],
                start_url: Config_1.Config.Server.publicUrl === '' ? '.' : Config_1.Config.Server.publicUrl,
                background_color: '#000000',
                theme_color: '#000000',
            });
        });
        const getIcon = (theme = null, paddingPercent = 0) => {
            const vBs = (Config_1.Config.Server.svgIcon.viewBox || '').split(' ').slice(0, 4).map(s => parseFloat(s));
            vBs[0] = vBs[0] || 0;
            vBs[1] = vBs[1] || 0;
            vBs[2] = vBs[2] || 512;
            vBs[3] = vBs[3] || 512;
            // make icon rectangle
            //add padding to all sides equally. ie: center icon
            const icon_size = Math.max(vBs[2], vBs[3]);
            const pw = icon_size - vBs[2];
            const ph = icon_size - vBs[3];
            vBs[0] -= pw / 2;
            vBs[1] -= ph / 2;
            vBs[2] = icon_size;
            vBs[3] = icon_size;
            const getCanvasSize = () => Math.max(vBs[2], vBs[3]);
            const addPadding = (p) => {
                if (p <= 0) {
                    return;
                }
                const size = getCanvasSize();
                vBs[0] -= size * (p / 2);
                vBs[1] -= size * (p / 2);
                vBs[2] += size * (p);
                vBs[3] += size * (p);
            };
            addPadding(paddingPercent);
            const canvasSize = getCanvasSize();
            const canvasStart = {
                x: vBs[0],
                y: vBs[1]
            };
            return '<svg ' +
                ' xmlns="http://www.w3.org/2000/svg"' +
                ' viewBox="' + vBs.join(' ') + '">' +
                (theme === 'auto' ? ('<style>' +
                    '    path, circle {' +
                    '      fill: black;' +
                    '    }' +
                    '   circle.bg,rect.bg {' +
                    '    fill: white;' +
                    '   }' +
                    '    @media (prefers-color-scheme: dark) {' +
                    '      path, circle {' +
                    '        fill: white;' +
                    '      }' +
                    '   circle.bg,rect.bg {' +
                    '    fill: black;' +
                    '   }' +
                    '    }' +
                    '  </style>') :
                    (theme != null ?
                        ('<style>' +
                            '    path, circle {' +
                            '      fill: ' + theme + ';' +
                            '    }' +
                            '   circle.bg {' +
                            '    fill: black;' +
                            '   }' +
                            '  </style>')
                        : '<style>' +
                            '   circle.bg,rect.bg {' +
                            '    fill: white;' +
                            '   }' +
                            '  </style>')) +
                `<rect class="bg" x="${canvasStart.x}" y="${canvasStart.y}" width="${canvasSize}" height="${canvasSize}" rx="15" />` +
                Config_1.Config.Server.svgIcon.items + '</svg>';
        };
        app.get('/icon.svg', (req, res) => {
            res.set('Cache-control', 'public, max-age=31536000');
            res.header('Content-Type', 'image/svg+xml');
            res.send(getIcon());
        });
        app.get('/icon_padding_auto.svg', (req, res) => {
            res.set('Cache-control', 'public, max-age=31536000');
            res.header('Content-Type', 'image/svg+xml');
            // Use 40% padding: https://w3c.github.io/manifest/#icon-masks
            res.send(getIcon('auto', 0.7));
        });
        app.get('/icon_auto.svg', (req, res) => {
            res.set('Cache-control', 'public, max-age=31536000');
            res.header('Content-Type', 'image/svg+xml');
            res.send(getIcon('auto'));
        });
        app.get('/icon_white.svg', (req, res) => {
            res.set('Cache-control', 'public, max-age=31536000');
            res.header('Content-Type', 'image/svg+xml');
            res.send(getIcon('white'));
        });
        app.get('/icon.png', async (req, res, next) => {
            try {
                const p = path.join(ProjectPath_1.ProjectPath.TempFolder, '/icon.png');
                await PhotoProcessing_1.PhotoProcessing.renderSVG(Config_1.Config.Server.svgIcon, p);
                res.sendFile(p, {
                    maxAge: 31536000,
                    dotfiles: 'allow',
                });
            }
            catch (e) {
                return next(e);
            }
        });
        app.get('/icon_white.png', async (req, res, next) => {
            try {
                const p = path.join(ProjectPath_1.ProjectPath.TempFolder, '/icon_inv.png');
                await PhotoProcessing_1.PhotoProcessing.renderSVG(Config_1.Config.Server.svgIcon, p, 'white');
                res.sendFile(p, {
                    maxAge: 31536000,
                    dotfiles: 'allow',
                });
            }
            catch (e) {
                return next(e);
            }
        });
        app.get([
            '/',
            '/login',
            '/gallery*',
            '/share/:' + QueryParams_1.QueryParams.gallery.sharingKey_params,
            '/shareLogin',
            '/admin',
            '/duplicates',
            '/faces',
            '/albums',
            '/search*',
        ], AuthenticationMWs_1.AuthenticationMWs.tryAuthenticate, addTPl, // add template after authentication was successful
        setLocale, renderIndex);
        Config_1.Config.Server.languages.forEach((l) => {
            app.get([
                '/' + l + '/',
                '/' + l + '/login',
                '/' + l + '/gallery*',
                '/' + l + '/share*',
                '/' + l + '/admin',
                '/' + l + '/search*',
            ], redirectToBase(l));
        });
        const renderFile = (subDir = '') => {
            return (req, res) => {
                const file = path.join(ProjectPath_1.ProjectPath.FrontendFolder, req.localePath, subDir, req.params.file);
                if (!fs.existsSync(file)) {
                    return res.sendStatus(404);
                }
                res.sendFile(file, {
                    maxAge: 31536000,
                    dotfiles: 'allow',
                });
            };
        };
        app.get('/assets/:file(*)', setLocale, AuthenticationMWs_1.AuthenticationMWs.normalizePathParam('file'), renderFile('assets'));
        app.get('/:file', setLocale, AuthenticationMWs_1.AuthenticationMWs.normalizePathParam('file'), renderFile());
    }
}
exports.PublicRouter = PublicRouter;
