"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SharingRouter = void 0;
const AuthenticationMWs_1 = require("../middlewares/user/AuthenticationMWs");
const UserDTO_1 = require("../../common/entities/UserDTO");
const RenderingMWs_1 = require("../middlewares/RenderingMWs");
const SharingMWs_1 = require("../middlewares/SharingMWs");
const QueryParams_1 = require("../../common/QueryParams");
const ServerTimingMWs_1 = require("../middlewares/ServerTimingMWs");
const Config_1 = require("../../common/config/private/Config");
class SharingRouter {
    static route(app) {
        this.addShareLogin(app);
        this.addGetSharing(app);
        this.addCreateSharing(app);
        this.addUpdateSharing(app);
        this.addListSharing(app);
        this.addListSharingForDir(app);
        this.addDeleteSharing(app);
    }
    static addShareLogin(app) {
        app.post(Config_1.Config.Server.apiPath + '/share/login', AuthenticationMWs_1.AuthenticationMWs.inverseAuthenticate, AuthenticationMWs_1.AuthenticationMWs.shareLogin, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderSessionUser);
    }
    static addGetSharing(app) {
        app.get(Config_1.Config.Server.apiPath + '/share/:' + QueryParams_1.QueryParams.gallery.sharingKey_params, AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.LimitedGuest), SharingMWs_1.SharingMWs.getSharing, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderSharing);
    }
    static addCreateSharing(app) {
        app.post([Config_1.Config.Server.apiPath + '/share/:directory(*)', Config_1.Config.Server.apiPath + '/share/', Config_1.Config.Server.apiPath + '/share//'], AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.User), SharingMWs_1.SharingMWs.createSharing, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderSharing);
    }
    static addUpdateSharing(app) {
        app.put([Config_1.Config.Server.apiPath + '/share/:directory(*)', Config_1.Config.Server.apiPath + '/share/', Config_1.Config.Server.apiPath + '/share//'], AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.User), SharingMWs_1.SharingMWs.updateSharing, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderSharing);
    }
    static addDeleteSharing(app) {
        app.delete([Config_1.Config.Server.apiPath + '/share/:' + QueryParams_1.QueryParams.gallery.sharingKey_params], AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.User), SharingMWs_1.SharingMWs.deleteSharing, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderResult);
    }
    static addListSharing(app) {
        app.get([Config_1.Config.Server.apiPath + '/share/listAll'], AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.Admin), SharingMWs_1.SharingMWs.listSharing, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderSharingList);
    }
    static addListSharingForDir(app) {
        app.get([Config_1.Config.Server.apiPath + '/share/list/:directory(*)',
            Config_1.Config.Server.apiPath + '/share/list//',
            Config_1.Config.Server.apiPath + '/share/list'], AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.User), SharingMWs_1.SharingMWs.listSharingForDir, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderSharingList);
    }
}
exports.SharingRouter = SharingRouter;
