"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationRouter = void 0;
const UserDTO_1 = require("../../common/entities/UserDTO");
const AuthenticationMWs_1 = require("../middlewares/user/AuthenticationMWs");
const RenderingMWs_1 = require("../middlewares/RenderingMWs");
const NotificationMWs_1 = require("../middlewares/NotificationMWs");
const VersionMWs_1 = require("../middlewares/VersionMWs");
const ServerTimingMWs_1 = require("../middlewares/ServerTimingMWs");
const Config_1 = require("../../common/config/private/Config");
class NotificationRouter {
    static route(app) {
        this.addGetNotifications(app);
    }
    static addGetNotifications(app) {
        app.get(Config_1.Config.Server.apiPath + '/notifications', AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.Guest), VersionMWs_1.VersionMWs.injectGalleryVersion, NotificationMWs_1.NotificationMWs.list, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderResult);
    }
}
exports.NotificationRouter = NotificationRouter;
