"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Router = void 0;
const PublicRouter_1 = require("./PublicRouter");
const UserRouter_1 = require("./UserRouter");
const GalleryRouter_1 = require("./GalleryRouter");
const PersonRouter_1 = require("./PersonRouter");
const SharingRouter_1 = require("./SharingRouter");
const AdminRouter_1 = require("./admin/AdminRouter");
const SettingsRouter_1 = require("./admin/SettingsRouter");
const NotificationRouter_1 = require("./NotificationRouter");
const ErrorRouter_1 = require("./ErrorRouter");
const AlbumRouter_1 = require("./AlbumRouter");
class Router {
    static route(app) {
        PublicRouter_1.PublicRouter.route(app);
        AdminRouter_1.AdminRouter.route(app);
        AlbumRouter_1.AlbumRouter.route(app);
        GalleryRouter_1.GalleryRouter.route(app);
        NotificationRouter_1.NotificationRouter.route(app);
        PersonRouter_1.PersonRouter.route(app);
        SettingsRouter_1.SettingsRouter.route(app);
        SharingRouter_1.SharingRouter.route(app);
        UserRouter_1.UserRouter.route(app);
        ErrorRouter_1.ErrorRouter.route(app);
    }
}
exports.Router = Router;
