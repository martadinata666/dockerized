"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserRouter = void 0;
const UserMWs_1 = require("../middlewares/user/UserMWs");
const UserDTO_1 = require("../../common/entities/UserDTO");
const AuthenticationMWs_1 = require("../middlewares/user/AuthenticationMWs");
const UserRequestConstrainsMWs_1 = require("../middlewares/user/UserRequestConstrainsMWs");
const RenderingMWs_1 = require("../middlewares/RenderingMWs");
const ServerTimingMWs_1 = require("../middlewares/ServerTimingMWs");
const Config_1 = require("../../common/config/private/Config");
class UserRouter {
    static route(app) {
        this.addLogin(app);
        this.addLogout(app);
        this.addGetSessionUser(app);
        this.addCreateUser(app);
        this.addDeleteUser(app);
        this.addListUsers(app);
        this.addChangeRole(app);
    }
    static addLogin(app) {
        app.post(Config_1.Config.Server.apiPath + '/user/login', AuthenticationMWs_1.AuthenticationMWs.inverseAuthenticate, AuthenticationMWs_1.AuthenticationMWs.login, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderSessionUser);
    }
    static addLogout(app) {
        app.post(Config_1.Config.Server.apiPath + '/user/logout', AuthenticationMWs_1.AuthenticationMWs.logout, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderOK);
    }
    static addGetSessionUser(app) {
        app.get(Config_1.Config.Server.apiPath + '/user/me', AuthenticationMWs_1.AuthenticationMWs.authenticate, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderSessionUser);
    }
    static addCreateUser(app) {
        app.put(Config_1.Config.Server.apiPath + '/user', AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.Admin), UserMWs_1.UserMWs.createUser, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderOK);
    }
    static addDeleteUser(app) {
        app.delete(Config_1.Config.Server.apiPath + '/user/:id', AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.Admin), UserRequestConstrainsMWs_1.UserRequestConstrainsMWs.notSelfRequest, UserMWs_1.UserMWs.deleteUser, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderOK);
    }
    static addListUsers(app) {
        app.get(Config_1.Config.Server.apiPath + '/user/list', AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.Admin), UserMWs_1.UserMWs.listUsers, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderResult);
    }
    static addChangeRole(app) {
        app.post(Config_1.Config.Server.apiPath + '/user/:id/role', AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.Admin), UserRequestConstrainsMWs_1.UserRequestConstrainsMWs.notSelfRequestOr2Admins, UserMWs_1.UserMWs.changeRole, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderOK);
    }
}
exports.UserRouter = UserRouter;
