"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SettingsRouter = void 0;
const AuthenticationMWs_1 = require("../../middlewares/user/AuthenticationMWs");
const UserDTO_1 = require("../../../common/entities/UserDTO");
const RenderingMWs_1 = require("../../middlewares/RenderingMWs");
const SettingsMWs_1 = require("../../middlewares/admin/SettingsMWs");
const Config_1 = require("../../../common/config/private/Config");
class SettingsRouter {
    static route(app) {
        this.addSettings(app);
    }
    static addSettings(app) {
        app.get(Config_1.Config.Server.apiPath + '/settings', AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.Admin), RenderingMWs_1.RenderingMWs.renderConfig);
        app.put(Config_1.Config.Server.apiPath + '/settings', AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.Admin), SettingsMWs_1.SettingsMWs.updateSettings, RenderingMWs_1.RenderingMWs.renderOK);
    }
}
exports.SettingsRouter = SettingsRouter;
