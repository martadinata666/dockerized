"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumRouter = void 0;
const AuthenticationMWs_1 = require("../middlewares/user/AuthenticationMWs");
const RenderingMWs_1 = require("../middlewares/RenderingMWs");
const UserDTO_1 = require("../../common/entities/UserDTO");
const VersionMWs_1 = require("../middlewares/VersionMWs");
const AlbumMWs_1 = require("../middlewares/AlbumMWs");
const ServerTimingMWs_1 = require("../middlewares/ServerTimingMWs");
const Config_1 = require("../../common/config/private/Config");
class AlbumRouter {
    static route(app) {
        this.addListAlbums(app);
        this.addAddSavedSearch(app);
        this.addDeleteAlbum(app);
    }
    static addListAlbums(app) {
        app.get([Config_1.Config.Server.apiPath + '/albums'], 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.User), VersionMWs_1.VersionMWs.injectGalleryVersion, 
        // specific part
        AlbumMWs_1.AlbumMWs.listAlbums, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderResult);
    }
    static addDeleteAlbum(app) {
        app.delete([Config_1.Config.Server.apiPath + '/albums/:id'], 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.Admin), VersionMWs_1.VersionMWs.injectGalleryVersion, 
        // specific part
        AlbumMWs_1.AlbumMWs.deleteAlbum, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderResult);
    }
    static addAddSavedSearch(app) {
        app.put([Config_1.Config.Server.apiPath + '/albums/saved-searches'], 
        // common part
        AuthenticationMWs_1.AuthenticationMWs.authenticate, AuthenticationMWs_1.AuthenticationMWs.authorise(UserDTO_1.UserRoles.Admin), VersionMWs_1.VersionMWs.injectGalleryVersion, 
        // specific part
        AlbumMWs_1.AlbumMWs.createSavedSearch, ServerTimingMWs_1.ServerTimingMWs.addServerTiming, RenderingMWs_1.RenderingMWs.renderResult);
    }
}
exports.AlbumRouter = AlbumRouter;
