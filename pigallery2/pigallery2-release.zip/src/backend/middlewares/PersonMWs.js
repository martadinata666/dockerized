"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PersonMWs = void 0;
const Error_1 = require("../../common/entities/Error");
const ObjectManagers_1 = require("../model/ObjectManagers");
const Utils_1 = require("../../common/Utils");
class PersonMWs {
    static async updatePerson(req, res, next) {
        if (!req.params['name']) {
            return next();
        }
        try {
            req.resultPipe =
                await ObjectManagers_1.ObjectManagers.getInstance().PersonManager.updatePerson(req.params['name'], req.body);
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.PERSON_ERROR, 'Error during updating a person', err));
        }
    }
    static async getPerson(req, res, next) {
        if (!req.params['name']) {
            return next();
        }
        try {
            req.resultPipe = await ObjectManagers_1.ObjectManagers.getInstance().PersonManager.get(req.params['name']);
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.PERSON_ERROR, 'Error during updating a person', err));
        }
    }
    static async listPersons(req, res, next) {
        try {
            req.resultPipe =
                await ObjectManagers_1.ObjectManagers.getInstance().PersonManager.getAll();
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.PERSON_ERROR, 'Error during listing persons', err));
        }
    }
    static async cleanUpPersonResults(req, res, next) {
        if (!req.resultPipe) {
            return next();
        }
        try {
            const persons = Utils_1.Utils.clone(req.resultPipe);
            for (const item of persons) {
                delete item.sampleRegion;
            }
            req.resultPipe = persons;
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.PERSON_ERROR, 'Error during removing sample photo from all persons', err));
        }
    }
}
exports.PersonMWs = PersonMWs;
