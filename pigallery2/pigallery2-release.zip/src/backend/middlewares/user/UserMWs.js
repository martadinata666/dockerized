"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserMWs = void 0;
const Error_1 = require("../../../common/entities/Error");
const ObjectManagers_1 = require("../../model/ObjectManagers");
const Utils_1 = require("../../../common/Utils");
const Config_1 = require("../../../common/config/private/Config");
class UserMWs {
    static async createUser(req, res, next) {
        if (Config_1.Config.Users.authenticationRequired === false) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.USER_MANAGEMENT_DISABLED));
        }
        if (typeof req.body === 'undefined' ||
            typeof req.body.newUser === 'undefined') {
            return next();
        }
        try {
            await ObjectManagers_1.ObjectManagers.getInstance().UserManager.createUser(req.body.newUser);
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.USER_CREATION_ERROR, null, err));
        }
    }
    static async deleteUser(req, res, next) {
        if (Config_1.Config.Users.authenticationRequired === false) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.USER_MANAGEMENT_DISABLED));
        }
        if (typeof req.params === 'undefined' ||
            typeof req.params.id === 'undefined') {
            return next();
        }
        try {
            await ObjectManagers_1.ObjectManagers.getInstance().UserManager.deleteUser(parseInt(req.params.id, 10));
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, null, err));
        }
    }
    static async changeRole(req, res, next) {
        if (Config_1.Config.Users.authenticationRequired === false) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.USER_MANAGEMENT_DISABLED));
        }
        if (typeof req.params === 'undefined' ||
            typeof req.params.id === 'undefined' ||
            typeof req.body === 'undefined' ||
            typeof req.body.newRole === 'undefined') {
            return next();
        }
        try {
            await ObjectManagers_1.ObjectManagers.getInstance().UserManager.changeRole(parseInt(req.params.id, 10), req.body.newRole);
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, null, err));
        }
    }
    static async listUsers(req, res, next) {
        if (Config_1.Config.Users.authenticationRequired === false) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.USER_MANAGEMENT_DISABLED));
        }
        try {
            let result = await ObjectManagers_1.ObjectManagers.getInstance().UserManager.find({});
            result = Utils_1.Utils.clone(result);
            for (const item of result) {
                item.password = '';
            }
            req.resultPipe = result;
            next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, null, err));
        }
    }
}
exports.UserMWs = UserMWs;
