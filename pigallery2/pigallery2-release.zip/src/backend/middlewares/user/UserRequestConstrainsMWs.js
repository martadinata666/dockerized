"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserRequestConstrainsMWs = void 0;
const typeorm_1 = require("typeorm");
const Error_1 = require("../../../common/entities/Error");
const UserDTO_1 = require("../../../common/entities/UserDTO");
const ObjectManagers_1 = require("../../model/ObjectManagers");
class UserRequestConstrainsMWs {
    static forceSelfRequest(req, res, next) {
        if (typeof req.params === 'undefined' ||
            typeof req.params.id === 'undefined') {
            return next();
        }
        if (req.session['user'].id !== parseInt(req.params.id, 10)) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.NOT_AUTHORISED));
        }
        return next();
    }
    static notSelfRequest(req, res, next) {
        if (typeof req.params === 'undefined' ||
            typeof req.params.id === 'undefined') {
            return next();
        }
        if (req.session['user'].id === parseInt(req.params.id, 10)) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.NOT_AUTHORISED));
        }
        return next();
    }
    static async notSelfRequestOr2Admins(req, res, next) {
        if (typeof req.params === 'undefined' ||
            typeof req.params.id === 'undefined') {
            return next();
        }
        if (req.session['user'].id !== parseInt(req.params.id, 10)) {
            return next();
        }
        // TODO: fix it!
        try {
            const result = await ObjectManagers_1.ObjectManagers.getInstance().UserManager.find({
                role: (0, typeorm_1.MoreThanOrEqual)(UserDTO_1.UserRoles.Admin),
            });
            if (result.length <= 1) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR));
            }
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR));
        }
    }
}
exports.UserRequestConstrainsMWs = UserRequestConstrainsMWs;
