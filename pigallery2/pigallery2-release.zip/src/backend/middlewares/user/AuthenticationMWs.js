"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthenticationMWs = void 0;
const Error_1 = require("../../../common/entities/Error");
const UserDTO_1 = require("../../../common/entities/UserDTO");
const ObjectManagers_1 = require("../../model/ObjectManagers");
const Config_1 = require("../../../common/config/private/Config");
const PasswordHelper_1 = require("../../model/PasswordHelper");
const Utils_1 = require("../../../common/Utils");
const QueryParams_1 = require("../../../common/QueryParams");
const path = require("path");
const Logger_1 = require("../../Logger");
const LOG_TAG = 'AuthenticationMWs';
class AuthenticationMWs {
    static async tryAuthenticate(req, res, next) {
        if (Config_1.Config.Users.authenticationRequired === false) {
            req.session['user'] = {
                name: UserDTO_1.UserRoles[Config_1.Config.Users.unAuthenticatedUserRole],
                role: Config_1.Config.Users.unAuthenticatedUserRole,
            };
            return next();
        }
        try {
            const user = await AuthenticationMWs.getSharingUser(req);
            if (user) {
                req.session['user'] = user;
                return next();
            }
            // eslint-disable-next-line no-empty
        }
        catch (err) {
        }
        return next();
    }
    static async authenticate(req, res, next) {
        if (Config_1.Config.Users.authenticationRequired === false) {
            req.session['user'] = {
                name: UserDTO_1.UserRoles[Config_1.Config.Users.unAuthenticatedUserRole],
                role: Config_1.Config.Users.unAuthenticatedUserRole,
            };
            return next();
        }
        // if already authenticated, do not try to use sharing authentication
        if (typeof req.session['user'] !== 'undefined') {
            return next();
        }
        try {
            const user = await AuthenticationMWs.getSharingUser(req);
            if (user) {
                req.session['user'] = user;
                return next();
            }
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.CREDENTIAL_NOT_FOUND, null, err));
        }
        if (typeof req.session['user'] === 'undefined') {
            res.status(401);
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.NOT_AUTHENTICATED, 'Not authenticated'));
        }
        return next();
    }
    static normalizePathParam(paramName) {
        return function normalizePathParam(req, res, next) {
            req.params[paramName] = path
                .normalize(req.params[paramName] || path.sep)
                // eslint-disable-next-line no-useless-escape
                .replace(/^(\.\.[\/\\])+/, '');
            return next();
        };
    }
    static authorisePath(paramName, isDirectory) {
        return function authorisePath(req, res, next) {
            let p = req.params[paramName];
            if (!isDirectory) {
                p = path.dirname(p);
            }
            if (!UserDTO_1.UserDTOUtils.isDirectoryPathAvailable(p, req.session['user'].permissions)) {
                return res.sendStatus(403);
            }
            return next();
        };
    }
    static authorise(role) {
        return function authorise(req, res, next) {
            if (req.session['user'].role < role) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.NOT_AUTHORISED));
            }
            return next();
        };
    }
    static async shareLogin(req, res, next) {
        if (Config_1.Config.Sharing.enabled === false) {
            return next();
        }
        // not enough parameter
        if (!req.query[QueryParams_1.QueryParams.gallery.sharingKey_query] &&
            !req.params[QueryParams_1.QueryParams.gallery.sharingKey_params]) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.INPUT_ERROR, 'no sharing key provided'));
        }
        try {
            const password = (req.body ? req.body.password : null) || null;
            const sharingKey = req.query[QueryParams_1.QueryParams.gallery.sharingKey_query] ||
                req.params[QueryParams_1.QueryParams.gallery.sharingKey_params];
            const sharing = await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.findOne(sharingKey);
            if (!sharing ||
                sharing.expires < Date.now() ||
                (Config_1.Config.Sharing.passwordProtected === true &&
                    sharing.password &&
                    !PasswordHelper_1.PasswordHelper.comparePassword(password, sharing.password))) {
                Logger_1.Logger.warn(LOG_TAG, 'Failed login with sharing:' + sharing.sharingKey + ', bad password');
                res.status(401);
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.CREDENTIAL_NOT_FOUND));
            }
            let sharingPath = sharing.path;
            if (sharing.includeSubfolders === true) {
                sharingPath += '*';
            }
            req.session['user'] = {
                name: 'Guest',
                role: UserDTO_1.UserRoles.LimitedGuest,
                permissions: [sharingPath],
                usedSharingKey: sharing.sharingKey,
            };
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, null, err));
        }
    }
    static inverseAuthenticate(req, res, next) {
        if (typeof req.session['user'] !== 'undefined') {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.ALREADY_AUTHENTICATED));
        }
        return next();
    }
    static async login(req, res, next) {
        if (Config_1.Config.Users.authenticationRequired === false) {
            return res.sendStatus(404);
        }
        // not enough parameter
        if (typeof req.body === 'undefined' ||
            typeof req.body.loginCredential === 'undefined' ||
            typeof req.body.loginCredential.username === 'undefined' ||
            typeof req.body.loginCredential.password === 'undefined') {
            Logger_1.Logger.warn(LOG_TAG, 'Failed login no user or password provided');
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.INPUT_ERROR, 'not all parameters are included for loginCredential'));
        }
        try {
            // let's find the user
            const user = Utils_1.Utils.clone(await ObjectManagers_1.ObjectManagers.getInstance().UserManager.findOne({
                name: req.body.loginCredential.username,
                password: req.body.loginCredential.password,
            }));
            delete user.password;
            req.session['user'] = user;
            if (req.body.loginCredential.rememberMe) {
                req.sessionOptions.expires = new Date(Date.now() + Config_1.Config.Server.sessionTimeout);
            }
            return next();
        }
        catch (err) {
            Logger_1.Logger.warn(LOG_TAG, 'Failed login for user:' + req.body.loginCredential.username
                + ', bad password');
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.CREDENTIAL_NOT_FOUND, 'credentials not found during login', err));
        }
    }
    static logout(req, res, next) {
        delete req.session['user'];
        return next();
    }
    static async getSharingUser(req) {
        if (Config_1.Config.Sharing.enabled === true &&
            (!!req.query[QueryParams_1.QueryParams.gallery.sharingKey_query] ||
                !!req.params[QueryParams_1.QueryParams.gallery.sharingKey_params])) {
            const sharingKey = req.query[QueryParams_1.QueryParams.gallery.sharingKey_query] ||
                req.params[QueryParams_1.QueryParams.gallery.sharingKey_params];
            const sharing = await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.findOne(sharingKey);
            if (!sharing || sharing.expires < Date.now()) {
                return null;
            }
            if (Config_1.Config.Sharing.passwordProtected === true &&
                sharing.password) {
                return null;
            }
            let sharingPath = sharing.path;
            if (sharing.includeSubfolders === true) {
                sharingPath += '*';
            }
            return {
                name: 'Guest',
                role: UserDTO_1.UserRoles.LimitedGuest,
                permissions: [sharingPath],
                usedSharingKey: sharing.sharingKey,
            };
        }
        return null;
    }
}
exports.AuthenticationMWs = AuthenticationMWs;
