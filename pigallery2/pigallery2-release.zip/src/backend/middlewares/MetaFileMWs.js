"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MetaFileMWs = void 0;
const fs = require("fs");
const Config_1 = require("../../common/config/private/Config");
const GPXProcessing_1 = require("../model/fileprocessing/GPXProcessing");
const Logger_1 = require("../Logger");
const LOG_TAG = 'MetaFileMWs';
class MetaFileMWs {
    static async compressGPX(req, res, next) {
        if (!req.resultPipe) {
            return next();
        }
        // if conversion is not enabled redirect, so browser can cache the full
        if (Config_1.Config.MetaFile.GPXCompressing.enabled === false) {
            return res.redirect(req.originalUrl.slice(0, -1 * '\\bestFit'.length));
        }
        const fullPath = req.resultPipe;
        try {
            const compressedGPX = GPXProcessing_1.GPXProcessing.generateConvertedPath(fullPath);
            // check if converted photo exist
            if (fs.existsSync(compressedGPX) === true) {
                req.resultPipe = compressedGPX;
                return next();
            }
            if (Config_1.Config.MetaFile.GPXCompressing.onTheFly === true) {
                req.resultPipe = await GPXProcessing_1.GPXProcessing.compressGPX(fullPath);
                return next();
            }
        }
        catch (err) {
            // Graceful degradation if compression fails
            Logger_1.Logger.warn(LOG_TAG, 'Error during compressingGPX, using original file: ' + fullPath);
            return res.redirect(req.originalUrl.slice(0, -1 * '\\bestFit'.length));
        }
        // not converted and won't be now
        return res.redirect(req.originalUrl.slice(0, -1 * '\\bestFit'.length));
    }
}
exports.MetaFileMWs = MetaFileMWs;
