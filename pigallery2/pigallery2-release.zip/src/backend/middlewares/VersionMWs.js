"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VersionMWs = void 0;
const ObjectManagers_1 = require("../model/ObjectManagers");
const Error_1 = require("../../common/entities/Error");
const CustomHeaders_1 = require("../../common/CustomHeaders");
class VersionMWs {
    /**
     * This version data is mainly used on the client side to invalidate the cache
     */
    static async injectGalleryVersion(req, res, next) {
        try {
            res.header(CustomHeaders_1.CustomHeaders.dataVersion, await ObjectManagers_1.ObjectManagers.getInstance().VersionManager.getDataVersion());
            next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Can not get data version', err.toString()));
        }
    }
}
exports.VersionMWs = VersionMWs;
