"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumMWs = void 0;
const Error_1 = require("../../common/entities/Error");
const ObjectManagers_1 = require("../model/ObjectManagers");
const Utils_1 = require("../../common/Utils");
const Config_1 = require("../../common/config/private/Config");
class AlbumMWs {
    static async listAlbums(req, res, next) {
        if (Config_1.Config.Album.enabled === false) {
            return next();
        }
        try {
            req.resultPipe =
                await ObjectManagers_1.ObjectManagers.getInstance().AlbumManager.getAlbums();
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.ALBUM_ERROR, 'Error during listing albums', err));
        }
    }
    static async deleteAlbum(req, res, next) {
        if (Config_1.Config.Album.enabled === false) {
            return next();
        }
        if (!req.params['id'] || !Utils_1.Utils.isUInt32(parseInt(req.params['id'], 10))) {
            return next();
        }
        try {
            await ObjectManagers_1.ObjectManagers.getInstance().AlbumManager.deleteAlbum(parseInt(req.params['id'], 10));
            req.resultPipe = 'ok';
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.ALBUM_ERROR, 'Error during deleting albums', err));
        }
    }
    static async createSavedSearch(req, res, next) {
        if (Config_1.Config.Album.enabled === false) {
            return next();
        }
        if (typeof req.body === 'undefined' ||
            typeof req.body.name !== 'string' ||
            typeof req.body.searchQuery !== 'object') {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.INPUT_ERROR, 'updateSharing filed is missing'));
        }
        try {
            await ObjectManagers_1.ObjectManagers.getInstance().AlbumManager.addSavedSearch(req.body.name, req.body.searchQuery);
            req.resultPipe = 'ok';
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.ALBUM_ERROR, 'Error during creating saved search albums', err));
        }
    }
}
exports.AlbumMWs = AlbumMWs;
