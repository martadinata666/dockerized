"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SharingMWs = void 0;
const ObjectManagers_1 = require("../model/ObjectManagers");
const Error_1 = require("../../common/entities/Error");
const Config_1 = require("../../common/config/private/Config");
const QueryParams_1 = require("../../common/QueryParams");
const path = require("path");
const UserDTO_1 = require("../../common/entities/UserDTO");
class SharingMWs {
    static async getSharing(req, res, next) {
        if (Config_1.Config.Sharing.enabled === false) {
            return next();
        }
        const sharingKey = req.params[QueryParams_1.QueryParams.gallery.sharingKey_params];
        try {
            req.resultPipe =
                await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.findOne(sharingKey);
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error during retrieving sharing link', err));
        }
    }
    static async createSharing(req, res, next) {
        if (Config_1.Config.Sharing.enabled === false) {
            return next();
        }
        if (typeof req.body === 'undefined' ||
            typeof req.body.createSharing === 'undefined') {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.INPUT_ERROR, 'createSharing filed is missing'));
        }
        const createSharing = req.body.createSharing;
        let sharingKey = SharingMWs.generateKey();
        // create one not yet used
        // eslint-disable-next-line no-constant-condition
        while (true) {
            try {
                await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.findOne(sharingKey);
                sharingKey = this.generateKey();
            }
            catch (err) {
                break;
            }
        }
        const directoryName = path.normalize(req.params['directory'] || '/');
        const sharing = {
            id: null,
            sharingKey,
            path: directoryName,
            password: createSharing.password,
            creator: req.session['user'],
            expires: createSharing.valid >= 0 // if === -1 its forever
                ? Date.now() + createSharing.valid
                : new Date(9999, 0, 1).getTime(),
            includeSubfolders: createSharing.includeSubfolders,
            timeStamp: Date.now(),
        };
        try {
            req.resultPipe =
                await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.createSharing(sharing);
            return next();
        }
        catch (err) {
            console.warn(err);
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error during creating sharing link', err));
        }
    }
    static async updateSharing(req, res, next) {
        if (Config_1.Config.Sharing.enabled === false) {
            return next();
        }
        if (typeof req.body === 'undefined' ||
            typeof req.body.updateSharing === 'undefined') {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.INPUT_ERROR, 'updateSharing filed is missing'));
        }
        const updateSharing = req.body.updateSharing;
        const directoryName = path.normalize(req.params['directory'] || '/');
        const sharing = {
            id: updateSharing.id,
            path: directoryName,
            sharingKey: '',
            password: updateSharing.password && updateSharing.password !== ''
                ? updateSharing.password
                : null,
            creator: req.session['user'],
            expires: updateSharing.valid >= 0 // if === -1 its forever
                ? Date.now() + updateSharing.valid
                : new Date(9999, 0, 1).getTime(),
            includeSubfolders: updateSharing.includeSubfolders,
            timeStamp: Date.now(),
        };
        try {
            const forceUpdate = req.session['user'].role >= UserDTO_1.UserRoles.Admin;
            req.resultPipe =
                await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.updateSharing(sharing, forceUpdate);
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error during updating sharing link', err));
        }
    }
    static async deleteSharing(req, res, next) {
        if (Config_1.Config.Sharing.enabled === false) {
            return next();
        }
        if (typeof req.params === 'undefined' ||
            typeof req.params['sharingKey'] === 'undefined') {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.INPUT_ERROR, 'sharingKey is missing'));
        }
        const sharingKey = req.params['sharingKey'];
        try {
            // Check if user has the right to delete sharing.
            if (req.session['user'].role < UserDTO_1.UserRoles.Admin) {
                const s = await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.findOne(sharingKey);
                if (s.creator.id !== req.session['user'].id) {
                    return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.NOT_AUTHORISED, 'Can\'t delete sharing.'));
                }
            }
            req.resultPipe =
                await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.deleteSharing(sharingKey);
            req.resultPipe = 'ok';
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error during deleting sharing', err));
        }
    }
    static async listSharing(req, res, next) {
        if (Config_1.Config.Sharing.enabled === false) {
            return next();
        }
        try {
            req.resultPipe =
                await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.listAll();
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error during listing shares', err));
        }
    }
    static async listSharingForDir(req, res, next) {
        if (Config_1.Config.Sharing.enabled === false) {
            return next();
        }
        const dir = path.normalize(req.params['directory'] || '/');
        try {
            if (req.session['user'].role >= UserDTO_1.UserRoles.Admin) {
                req.resultPipe =
                    await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.listAllForDir(dir);
            }
            else {
                req.resultPipe =
                    await ObjectManagers_1.ObjectManagers.getInstance().SharingManager.listAllForDir(dir, req.session['user']);
            }
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error during listing shares', err));
        }
    }
    static generateKey() {
        function s4() {
            return Math.floor((1 + Math.random()) * 0x10000)
                .toString(16)
                .substring(1);
        }
        return s4() + s4();
    }
}
exports.SharingMWs = SharingMWs;
