"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServerTimingMWs = exports.ServerTime = exports.ServerTimeEntry = void 0;
const Config_1 = require("../../common/config/private/Config");
class ServerTimeEntry {
    constructor(name) {
        this.endTime = null;
        this.name = name;
    }
    start() {
        this.startHR = process.hrtime();
    }
    end() {
        const duration = process.hrtime(this.startHR);
        this.endTime = duration[0] * 1e3 + duration[1] * 1e-6;
    }
}
exports.ServerTimeEntry = ServerTimeEntry;
const ServerTime = (id, name) => {
    return (target, propertyName, descriptor) => {
        if (Config_1.Config.Server.Log.logServerTiming === false) {
            return;
        }
        const m = descriptor.value;
        const customAction = (req, res, next) => {
            req.timing = req.timing || {};
            req.timing[id] = new ServerTimeEntry(name);
            req.timing[id].start();
            m(req, res, (err) => {
                req.timing[id].end();
                next(err);
            });
        };
        descriptor.value = new Function('action', 'return function ' + m.name + '(...args){ action(...args) };')(customAction);
    };
};
exports.ServerTime = ServerTime;
const forcedDebug = process.env['NODE_ENV'] === 'debug';
class ServerTimingMWs {
    /**
     * Add server timing
     */
    static async addServerTiming(req, res, next) {
        if ((Config_1.Config.Server.Log.logServerTiming === false && !forcedDebug) ||
            !req.timing) {
            return next();
        }
        const l = Object.entries(req.timing)
            .filter((e) => e[1].endTime)
            .map((e) => `${e[0]};dur=${e[1].endTime};desc="${e[1].name}"`);
        res.header('Server-Timing', l.join(', '));
        next();
    }
}
exports.ServerTimingMWs = ServerTimingMWs;
