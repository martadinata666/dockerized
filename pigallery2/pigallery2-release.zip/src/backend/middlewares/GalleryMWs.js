"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GalleryMWs = void 0;
const tslib_1 = require("tslib");
const path = require("path");
const fs_1 = require("fs");
const archiver = require("archiver");
const Error_1 = require("../../common/entities/Error");
const ObjectManagers_1 = require("../model/ObjectManagers");
const ConentWrapper_1 = require("../../common/entities/ConentWrapper");
const ProjectPath_1 = require("../ProjectPath");
const Config_1 = require("../../common/config/private/Config");
const UserDTO_1 = require("../../common/entities/UserDTO");
const MediaDTO_1 = require("../../common/entities/MediaDTO");
const QueryParams_1 = require("../../common/QueryParams");
const VideoProcessing_1 = require("../model/fileprocessing/VideoProcessing");
const SearchQueryDTO_1 = require("../../common/entities/SearchQueryDTO");
const LocationLookupException_1 = require("../exceptions/LocationLookupException");
const SupportedFormats_1 = require("../../common/SupportedFormats");
const ServerTimingMWs_1 = require("./ServerTimingMWs");
const SortingMethods_1 = require("../../common/entities/SortingMethods");
class GalleryMWs {
    static async listDirectory(req, res, next) {
        const directoryName = req.params['directory'] || '/';
        const absoluteDirectoryName = path.join(ProjectPath_1.ProjectPath.ImageFolder, directoryName);
        try {
            if ((await fs_1.promises.stat(absoluteDirectoryName)).isDirectory() === false) {
                return next();
            }
        }
        catch (e) {
            return next();
        }
        try {
            const directory = await ObjectManagers_1.ObjectManagers.getInstance().GalleryManager.listDirectory(directoryName, parseInt(req.query[QueryParams_1.QueryParams.gallery.knownLastModified], 10), parseInt(req.query[QueryParams_1.QueryParams.gallery.knownLastScanned], 10));
            if (directory == null) {
                req.resultPipe = new ConentWrapper_1.ContentWrapper(null, null, true);
                return next();
            }
            if (req.session['user'].permissions &&
                req.session['user'].permissions.length > 0 &&
                req.session['user'].permissions[0] !== '/*') {
                directory.directories = directory.directories.filter((d) => UserDTO_1.UserDTOUtils.isDirectoryAvailable(d, req.session['user'].permissions));
            }
            req.resultPipe = new ConentWrapper_1.ContentWrapper(directory, null);
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error during listing the directory', err));
        }
    }
    static async zipDirectory(req, res, next) {
        if (Config_1.Config.Gallery.NavBar.enableDownloadZip === false) {
            return next();
        }
        const directoryName = req.params['directory'] || '/';
        const absoluteDirectoryName = path.join(ProjectPath_1.ProjectPath.ImageFolder, directoryName);
        try {
            if ((await fs_1.promises.stat(absoluteDirectoryName)).isDirectory() === false) {
                return next();
            }
        }
        catch (e) {
            return next();
        }
        try {
            res.set('Content-Type', 'application/zip');
            res.set('Content-Disposition', 'attachment; filename=Gallery.zip');
            const archive = archiver('zip', {
                store: true, // disable compression
            });
            res.on('close', () => {
                console.log('zip ' + archive.pointer() + ' bytes');
            });
            archive.on('error', (err) => {
                throw err;
            });
            archive.pipe(res);
            // append photos in absoluteDirectoryName
            // using case-insensitive glob of extensions
            for (const ext of SupportedFormats_1.SupportedFormats.WithDots.Photos) {
                archive.glob(`*${ext}`, { cwd: absoluteDirectoryName, nocase: true });
            }
            // append videos in absoluteDirectoryName
            // using case-insensitive glob of extensions
            for (const ext of SupportedFormats_1.SupportedFormats.WithDots.Videos) {
                archive.glob(`*${ext}`, { cwd: absoluteDirectoryName, nocase: true });
            }
            await archive.finalize();
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error creating zip', err));
        }
    }
    static cleanUpGalleryResults(req, res, next) {
        if (!req.resultPipe) {
            return next();
        }
        const cw = req.resultPipe;
        if (cw.notModified === true) {
            return next();
        }
        if (Config_1.Config.Media.Video.enabled === false) {
            if (cw.directory) {
                const removeVideos = (dir) => {
                    dir.media = dir.media.filter((m) => !MediaDTO_1.MediaDTOUtils.isVideo(m));
                };
                removeVideos(cw.directory);
            }
            if (cw.searchResult) {
                cw.searchResult.media = cw.searchResult.media.filter((m) => !MediaDTO_1.MediaDTOUtils.isVideo(m));
            }
        }
        ConentWrapper_1.ContentWrapper.pack(cw);
        return next();
    }
    static async loadFile(req, res, next) {
        if (!req.params['mediaPath']) {
            return next();
        }
        const fullMediaPath = path.join(ProjectPath_1.ProjectPath.ImageFolder, req.params['mediaPath']);
        // check if file exist
        try {
            if ((await fs_1.promises.stat(fullMediaPath)).isDirectory()) {
                return next();
            }
        }
        catch (e) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'no such file:' + req.params['mediaPath'], 'can\'t find file: ' + fullMediaPath));
        }
        req.resultPipe = fullMediaPath;
        return next();
    }
    static async loadBestFitVideo(req, res, next) {
        if (!req.resultPipe) {
            return next();
        }
        const fullMediaPath = req.resultPipe;
        const convertedVideo = VideoProcessing_1.VideoProcessing.generateConvertedFilePath(fullMediaPath);
        // check if transcoded video exist
        try {
            await fs_1.promises.access(convertedVideo);
            req.resultPipe = convertedVideo;
            // eslint-disable-next-line no-empty
        }
        catch (e) {
        }
        return next();
    }
    static async search(req, res, next) {
        if (Config_1.Config.Search.enabled === false ||
            !req.params['searchQueryDTO']) {
            return next();
        }
        const query = JSON.parse(req.params['searchQueryDTO']);
        try {
            const result = await ObjectManagers_1.ObjectManagers.getInstance().SearchManager.search(query);
            result.directories.forEach((dir) => (dir.media = dir.media || []));
            req.resultPipe = new ConentWrapper_1.ContentWrapper(null, result);
            return next();
        }
        catch (err) {
            if (err instanceof LocationLookupException_1.LocationLookupException) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.LocationLookUp_ERROR, 'Cannot find location: ' + err.location, err));
            }
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error during searching', err));
        }
    }
    static async autocomplete(req, res, next) {
        if (Config_1.Config.Search.AutoComplete.enabled === false) {
            return next();
        }
        if (!req.params['text']) {
            return next();
        }
        let type = SearchQueryDTO_1.SearchQueryTypes.any_text;
        if (req.query[QueryParams_1.QueryParams.gallery.search.type]) {
            type = parseInt(req.query[QueryParams_1.QueryParams.gallery.search.type], 10);
        }
        try {
            req.resultPipe =
                await ObjectManagers_1.ObjectManagers.getInstance().SearchManager.autocomplete(req.params['text'], type);
            return next();
        }
        catch (err) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Error during searching', err));
        }
    }
    static async getRandomImage(req, res, next) {
        if (Config_1.Config.RandomPhoto.enabled === false ||
            !req.params['searchQueryDTO']) {
            return next();
        }
        try {
            const query = JSON.parse(req.params['searchQueryDTO']);
            const photos = await ObjectManagers_1.ObjectManagers.getInstance().SearchManager.getNMedia(query, [{ method: SortingMethods_1.SortByTypes.Random, ascending: null }], 1, true);
            if (!photos || photos.length !== 1) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.INPUT_ERROR, 'No photo found'));
            }
            req.params['mediaPath'] = path.join(photos[0].directory.path, photos[0].directory.name, photos[0].name);
            return next();
        }
        catch (e) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.GENERAL_ERROR, 'Can\'t get random photo: ' + e.toString()));
        }
    }
}
tslib_1.__decorate([
    (0, ServerTimingMWs_1.ServerTime)('1.db', 'List Directory'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, Object, Function]),
    tslib_1.__metadata("design:returntype", Promise)
], GalleryMWs, "listDirectory", null);
tslib_1.__decorate([
    (0, ServerTimingMWs_1.ServerTime)('1.zip', 'Zip Directory'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, Object, Function]),
    tslib_1.__metadata("design:returntype", Promise)
], GalleryMWs, "zipDirectory", null);
tslib_1.__decorate([
    (0, ServerTimingMWs_1.ServerTime)('3.pack', 'pack result'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, Object, Function]),
    tslib_1.__metadata("design:returntype", void 0)
], GalleryMWs, "cleanUpGalleryResults", null);
tslib_1.__decorate([
    (0, ServerTimingMWs_1.ServerTime)('1.db', 'Search'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, Object, Function]),
    tslib_1.__metadata("design:returntype", Promise)
], GalleryMWs, "search", null);
tslib_1.__decorate([
    (0, ServerTimingMWs_1.ServerTime)('1.db', 'Autocomplete'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, Object, Function]),
    tslib_1.__metadata("design:returntype", Promise)
], GalleryMWs, "autocomplete", null);
exports.GalleryMWs = GalleryMWs;
