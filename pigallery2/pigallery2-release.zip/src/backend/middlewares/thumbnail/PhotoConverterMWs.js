"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PhotoConverterMWs = void 0;
const fs = require("fs");
const PhotoProcessing_1 = require("../../model/fileprocessing/PhotoProcessing");
const Config_1 = require("../../../common/config/private/Config");
const Error_1 = require("../../../common/entities/Error");
class PhotoConverterMWs {
    static async convertPhoto(req, res, next) {
        if (!req.resultPipe) {
            return next();
        }
        // if conversion is not enabled redirect, so browser can cache the full
        if (Config_1.Config.Media.Photo.Converting.enabled === false) {
            return res.redirect(req.originalUrl.slice(0, -1 * '\\bestFit'.length));
        }
        const fullMediaPath = req.resultPipe;
        const convertedVideo = PhotoProcessing_1.PhotoProcessing.generateConvertedPath(fullMediaPath, Config_1.Config.Media.Photo.Converting.resolution);
        // check if converted photo exist
        if (fs.existsSync(convertedVideo) === true) {
            req.resultPipe = convertedVideo;
            return next();
        }
        if (Config_1.Config.Media.Photo.Converting.onTheFly === true) {
            try {
                req.resultPipe = await PhotoProcessing_1.PhotoProcessing.convertPhoto(fullMediaPath);
            }
            catch (err) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.PHOTO_GENERATION_ERROR, err.message));
            }
            return next();
        }
        // not converted and won't be now
        return res.redirect(req.originalUrl.slice(0, -1 * '\\bestFit'.length));
    }
}
exports.PhotoConverterMWs = PhotoConverterMWs;
