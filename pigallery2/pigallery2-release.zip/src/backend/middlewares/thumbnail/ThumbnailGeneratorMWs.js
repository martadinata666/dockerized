"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ThumbnailGeneratorMWs = void 0;
const tslib_1 = require("tslib");
const path = require("path");
const fs = require("fs");
const Error_1 = require("../../../common/entities/Error");
const ProjectPath_1 = require("../../ProjectPath");
const Config_1 = require("../../../common/config/private/Config");
const PhotoProcessing_1 = require("../../model/fileprocessing/PhotoProcessing");
const ServerTimingMWs_1 = require("../ServerTimingMWs");
class ThumbnailGeneratorMWs {
    static { this.ThumbnailMapEntries = Config_1.Config.Media.Thumbnail.generateThumbnailMapEntries(); }
    static async addThumbnailInformation(req, res, next) {
        if (!req.resultPipe) {
            return next();
        }
        try {
            const cw = req.resultPipe;
            if (cw.notModified === true) {
                return next();
            }
            // regenerate in case the list change since startup
            ThumbnailGeneratorMWs.ThumbnailMapEntries =
                Config_1.Config.Media.Thumbnail.generateThumbnailMapEntries();
            if (cw.directory) {
                ThumbnailGeneratorMWs.addThInfoTODir(cw.directory);
            }
            if (cw.searchResult && cw.searchResult.media) {
                ThumbnailGeneratorMWs.addThInfoToPhotos(cw.searchResult.media);
            }
        }
        catch (error) {
            console.error(error);
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.SERVER_ERROR, 'error during postprocessing result (adding thumbnail info)', error.toString()));
        }
        return next();
    }
    // eslint-disable-next-line @typescript-eslint/typedef, @typescript-eslint/explicit-function-return-type, @typescript-eslint/explicit-module-boundary-types
    static addThumbnailInfoForPersons(req, res, next) {
        if (!req.resultPipe) {
            return next();
        }
        let erroredItem = null;
        try {
            const size = Config_1.Config.Media.Thumbnail.personThumbnailSize;
            const persons = req.resultPipe;
            for (const item of persons) {
                erroredItem = item;
                if (!item.sampleRegion) {
                    item.missingThumbnail = true;
                    continue;
                }
                // load parameters
                const mediaPath = path.join(ProjectPath_1.ProjectPath.ImageFolder, item.sampleRegion.media.directory.path, item.sampleRegion.media.directory.name, item.sampleRegion.media.name);
                // generate thumbnail path
                const thPath = PhotoProcessing_1.PhotoProcessing.generatePersonThumbnailPath(mediaPath, item.sampleRegion.media.metadata.faces.find(f => f.name === item.name), size);
                item.missingThumbnail = !fs.existsSync(thPath);
            }
        }
        catch (error) {
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.SERVER_ERROR, `Error during postprocessing result: adding thumbnail info for persons. Failed on: person ${erroredItem?.name}, at ${erroredItem?.sampleRegion?.media?.name} `, error.toString()));
        }
        return next();
    }
    static async generatePersonThumbnail(req, res, next) {
        if (!req.resultPipe) {
            return next();
        }
        const person = req.resultPipe;
        try {
            req.resultPipe = await PhotoProcessing_1.PhotoProcessing.generatePersonThumbnail(person);
            return next();
        }
        catch (error) {
            console.error(error);
            return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.THUMBNAIL_GENERATION_ERROR, 'Error during generating face thumbnail: ' + person.name, error.toString()));
        }
    }
    static generateThumbnailFactory(sourceType) {
        return async (req, res, next) => {
            if (!req.resultPipe) {
                return next();
            }
            // load parameters
            const mediaPath = req.resultPipe;
            let size = parseInt(req.params.size, 10) ||
                Config_1.Config.Media.Thumbnail.thumbnailSizes[0];
            // validate size
            if (Config_1.Config.Media.Thumbnail.thumbnailSizes.indexOf(size) === -1) {
                size = Config_1.Config.Media.Thumbnail.thumbnailSizes[0];
            }
            try {
                req.resultPipe = await PhotoProcessing_1.PhotoProcessing.generateThumbnail(mediaPath, size, sourceType, false);
                return next();
            }
            catch (error) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.THUMBNAIL_GENERATION_ERROR, 'Error during generating thumbnail: ' + mediaPath, error.toString()));
            }
        };
    }
    static generateIconFactory(sourceType) {
        return async (req, res, next) => {
            if (!req.resultPipe) {
                return next();
            }
            // load parameters
            const mediaPath = req.resultPipe;
            const size = Config_1.Config.Media.Thumbnail.iconSize;
            try {
                req.resultPipe = await PhotoProcessing_1.PhotoProcessing.generateThumbnail(mediaPath, size, sourceType, true);
                return next();
            }
            catch (error) {
                return next(new Error_1.ErrorDTO(Error_1.ErrorCodes.THUMBNAIL_GENERATION_ERROR, 'Error during generating thumbnail: ' + mediaPath, error.toString()));
            }
        };
    }
    static addThInfoTODir(directory) {
        if (typeof directory.media !== 'undefined') {
            ThumbnailGeneratorMWs.addThInfoToPhotos(directory.media, directory);
        }
        if (directory.cover) {
            ThumbnailGeneratorMWs.addThInfoToAPhoto(directory.cover, directory);
        }
    }
    static addThInfoToPhotos(photos, directory) {
        for (let i = 0; i < photos.length; ++i) {
            this.addThInfoToAPhoto(photos[i], directory ? directory : photos[i].directory);
        }
    }
    static addThInfoToAPhoto(photo, directory) {
        const fullMediaPath = path.join(ProjectPath_1.ProjectPath.ImageFolder, directory.path, directory.name, photo.name);
        for (let i = 0; i < ThumbnailGeneratorMWs.ThumbnailMapEntries.length; ++i) {
            const entry = ThumbnailGeneratorMWs.ThumbnailMapEntries[i];
            const thPath = PhotoProcessing_1.PhotoProcessing.generateConvertedPath(fullMediaPath, entry.size);
            if (fs.existsSync(thPath) !== true) {
                if (typeof photo.missingThumbnails === 'undefined') {
                    photo.missingThumbnails = 0;
                }
                // this is a bitwise operation
                photo.missingThumbnails += entry.bit;
            }
        }
    }
}
tslib_1.__decorate([
    (0, ServerTimingMWs_1.ServerTime)('2.th', 'Thumbnail decoration'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, Object, Function]),
    tslib_1.__metadata("design:returntype", Promise)
], ThumbnailGeneratorMWs, "addThumbnailInformation", null);
exports.ThumbnailGeneratorMWs = ThumbnailGeneratorMWs;
