"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DiskManager = void 0;
const Logger_1 = require("../Logger");
const Config_1 = require("../../common/config/private/Config");
const ThreadPool_1 = require("./threading/ThreadPool");
const DiskMangerWorker_1 = require("./threading/DiskMangerWorker");
const LOG_TAG = '[DiskManager]';
class DiskManager {
    static { this.threadPool = null; }
    static init() {
        if (Config_1.Config.Server.Threading.enabled === true) {
            DiskManager.threadPool = new ThreadPool_1.DiskManagerTH(1);
        }
    }
    /**
     * List all files in a folder as fast as possible
     */
    static async scanDirectoryNoMetadata(relativeDirectoryName, settings = {}) {
        settings.noMetadata = true;
        return this.scanDirectory(relativeDirectoryName, settings);
    }
    static async scanDirectory(relativeDirectoryName, settings = {}) {
        Logger_1.Logger.silly(LOG_TAG, 'scanning directory:', relativeDirectoryName);
        let directory;
        if (Config_1.Config.Server.Threading.enabled === true) {
            directory = await DiskManager.threadPool.execute(relativeDirectoryName, settings);
        }
        else {
            directory = (await DiskMangerWorker_1.DiskMangerWorker.scanDirectory(relativeDirectoryName, settings));
        }
        return directory;
    }
}
exports.DiskManager = DiskManager;
