"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PasswordHelper = void 0;
const bcrypt = require("bcrypt");
class PasswordHelper {
    static cryptPassword(password) {
        const salt = bcrypt.genSaltSync(9);
        return bcrypt.hashSync(password, salt);
    }
    static comparePassword(password, encryptedPassword) {
        try {
            return bcrypt.compareSync(password, encryptedPassword);
            // eslint-disable-next-line no-empty
        }
        catch (e) {
        }
        return false;
    }
}
exports.PasswordHelper = PasswordHelper;
