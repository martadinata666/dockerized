"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationManager = void 0;
const NotificationDTO_1 = require("../../common/entities/NotificationDTO");
class NotificationManager {
    static { this.notifications = []; }
    static { this.HasNotification = [
        {
            type: NotificationDTO_1.NotificationType.info,
            message: 'There are unhandled server notification. Login as Administrator to handle them.',
        },
    ]; }
    static error(message, details, req) {
        const noti = {
            type: NotificationDTO_1.NotificationType.error,
            message,
            details,
        };
        if (req) {
            noti.request = {
                method: req.method,
                url: req.url,
                statusCode: req.statusCode,
            };
        }
        NotificationManager.notifications.push(noti);
    }
    static warning(message, details, req) {
        const noti = {
            type: NotificationDTO_1.NotificationType.warning,
            message,
            details,
        };
        if (req) {
            noti.request = {
                method: req.method,
                url: req.url,
                statusCode: req.statusCode,
            };
        }
        NotificationManager.notifications.push(noti);
    }
}
exports.NotificationManager = NotificationManager;
