"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VideoProcessing = void 0;
const path = require("path");
const fs_1 = require("fs");
const TaskExecuter_1 = require("../threading/TaskExecuter");
const VideoConverterWorker_1 = require("../threading/VideoConverterWorker");
const MetadataLoader_1 = require("../threading/MetadataLoader");
const Config_1 = require("../../../common/config/private/Config");
const ProjectPath_1 = require("../../ProjectPath");
const SupportedFormats_1 = require("../../../common/SupportedFormats");
class VideoProcessing {
    static { this.taskQue = new TaskExecuter_1.TaskExecuter(1, (input) => VideoConverterWorker_1.VideoConverterWorker.convert(input)); }
    static generateConvertedFilePath(videoPath) {
        return path.join(ProjectPath_1.ProjectPath.TranscodedFolder, ProjectPath_1.ProjectPath.getRelativePathToImages(path.dirname(videoPath)), path.basename(videoPath) + '_' + this.getConvertedFilePostFix());
    }
    static async isValidConvertedPath(convertedPath) {
        const origFilePath = path.join(ProjectPath_1.ProjectPath.ImageFolder, path.relative(ProjectPath_1.ProjectPath.TranscodedFolder, convertedPath.substring(0, convertedPath.lastIndexOf('_'))));
        const postfix = convertedPath.substring(convertedPath.lastIndexOf('_') + 1, convertedPath.length);
        if (postfix !== this.getConvertedFilePostFix()) {
            return false;
        }
        try {
            await fs_1.promises.access(origFilePath, fs_1.constants.R_OK);
        }
        catch (e) {
            return false;
        }
        return true;
    }
    static async convertedVideoExist(videoPath) {
        const outPath = this.generateConvertedFilePath(videoPath);
        try {
            await fs_1.promises.access(outPath, fs_1.constants.R_OK);
            return true;
        }
        catch (e) {
            // ignoring errors
        }
        return false;
    }
    static async convertVideo(videoPath) {
        const outPath = this.generateConvertedFilePath(videoPath);
        try {
            await fs_1.promises.access(outPath, fs_1.constants.R_OK);
            return;
        }
        catch (e) {
            // ignoring errors
        }
        const metaData = await MetadataLoader_1.MetadataLoader.loadVideoMetadata(videoPath);
        const renderInput = {
            videoPath,
            input: { customOptions: Config_1.Config.Media.Video.transcoding.customInputOptions },
            output: {
                path: outPath,
                codec: Config_1.Config.Media.Video.transcoding.format === 'mp4' ?
                    Config_1.Config.Media.Video.transcoding.mp4Codec :
                    Config_1.Config.Media.Video.transcoding.webmCodec,
                format: Config_1.Config.Media.Video.transcoding.format,
                crf: Config_1.Config.Media.Video.transcoding.crf,
                preset: Config_1.Config.Media.Video.transcoding.preset,
                customOptions: Config_1.Config.Media.Video.transcoding.customOutputOptions,
            },
        };
        if (metaData.bitRate > Config_1.Config.Media.Video.transcoding.bitRate) {
            renderInput.output.bitRate =
                Config_1.Config.Media.Video.transcoding.bitRate;
        }
        if (metaData.fps > Config_1.Config.Media.Video.transcoding.fps) {
            renderInput.output.fps = Config_1.Config.Media.Video.transcoding.fps;
        }
        if (Config_1.Config.Media.Video.transcoding.resolution < metaData.size.height) {
            renderInput.output.resolution =
                Config_1.Config.Media.Video.transcoding.resolution;
        }
        const outDir = path.dirname(renderInput.output.path);
        await fs_1.promises.mkdir(outDir, { recursive: true });
        await VideoProcessing.taskQue.execute(renderInput);
    }
    static isVideo(fullPath) {
        const extension = path.extname(fullPath).toLowerCase();
        return SupportedFormats_1.SupportedFormats.WithDots.Videos.indexOf(extension) !== -1;
    }
    static getConvertedFilePostFix() {
        return (Math.round(Config_1.Config.Media.Video.transcoding.bitRate / 1024) +
            'k' +
            (Config_1.Config.Media.Video.transcoding.format === 'mp4' ?
                Config_1.Config.Media.Video.transcoding.mp4Codec :
                Config_1.Config.Media.Video.transcoding.webmCodec).toString().toLowerCase() +
            Config_1.Config.Media.Video.transcoding.resolution +
            '.' +
            Config_1.Config.Media.Video.transcoding.format.toLowerCase());
    }
}
exports.VideoProcessing = VideoProcessing;
