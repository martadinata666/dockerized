"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JobRepository = void 0;
const IndexingJob_1 = require("./jobs/IndexingJob");
const GalleryResetJob_1 = require("./jobs/GalleryResetJob");
const VideoConvertingJob_1 = require("./jobs/VideoConvertingJob");
const PhotoConvertingJob_1 = require("./jobs/PhotoConvertingJob");
const ThumbnailGenerationJob_1 = require("./jobs/ThumbnailGenerationJob");
const TempFolderCleaningJob_1 = require("./jobs/TempFolderCleaningJob");
const AlbumCoverFillingJob_1 = require("./jobs/AlbumCoverFillingJob");
const GPXCompressionJob_1 = require("./jobs/GPXCompressionJob");
const AlbumResetJob_1 = require("./jobs/AlbumResetJob");
const GPXCompressionResetJob_1 = require("./jobs/GPXCompressionResetJob");
const TopPickSendJob_1 = require("./jobs/TopPickSendJob");
const AlbumCoverResetJob_1 = require("./jobs/AlbumCoverResetJob");
class JobRepository {
    constructor() {
        this.availableJobs = {};
    }
    static { this.instance = null; }
    static get Instance() {
        if (JobRepository.instance == null) {
            JobRepository.instance = new JobRepository();
        }
        return JobRepository.instance;
    }
    getAvailableJobs() {
        return Object.values(this.availableJobs).filter((t) => t.Supported);
    }
    register(job) {
        if (typeof this.availableJobs[job.Name] !== 'undefined') {
            throw new Error('Job already exist:' + job.Name);
        }
        this.availableJobs[job.Name] = job;
    }
}
exports.JobRepository = JobRepository;
JobRepository.Instance.register(new IndexingJob_1.IndexingJob());
JobRepository.Instance.register(new GalleryResetJob_1.GalleryRestJob());
JobRepository.Instance.register(new AlbumCoverFillingJob_1.AlbumCoverFillingJob());
JobRepository.Instance.register(new AlbumCoverResetJob_1.AlbumCoverRestJob());
JobRepository.Instance.register(new VideoConvertingJob_1.VideoConvertingJob());
JobRepository.Instance.register(new PhotoConvertingJob_1.PhotoConvertingJob());
JobRepository.Instance.register(new ThumbnailGenerationJob_1.ThumbnailGenerationJob());
JobRepository.Instance.register(new GPXCompressionJob_1.GPXCompressionJob());
JobRepository.Instance.register(new TempFolderCleaningJob_1.TempFolderCleaningJob());
JobRepository.Instance.register(new AlbumResetJob_1.AlbumRestJob());
JobRepository.Instance.register(new GPXCompressionResetJob_1.GPXCompressionResetJob());
JobRepository.Instance.register(new TopPickSendJob_1.TopPickSendJob());
