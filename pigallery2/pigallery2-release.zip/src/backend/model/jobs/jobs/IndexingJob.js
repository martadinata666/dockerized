"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IndexingJob = void 0;
const ObjectManagers_1 = require("../../ObjectManagers");
const path = require("path");
const fs = require("fs");
const Job_1 = require("./Job");
const JobDTO_1 = require("../../../../common/entities/job/JobDTO");
const JobProgressDTO_1 = require("../../../../common/entities/job/JobProgressDTO");
const DiskMangerWorker_1 = require("../../threading/DiskMangerWorker");
const ProjectPath_1 = require("../../../ProjectPath");
const BackendTexts_1 = require("../../../../common/BackendTexts");
const Logger_1 = require("../../../Logger");
const LOG_TAG = '[IndexingJob]';
class IndexingJob extends Job_1.Job {
    constructor() {
        super(...arguments);
        this.Name = JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs.Indexing];
        this.directoriesToIndex = [];
        this.ConfigTemplate = [
            {
                id: 'indexChangesOnly',
                type: 'boolean',
                name: BackendTexts_1.backendTexts.indexChangesOnly.name,
                description: BackendTexts_1.backendTexts.indexChangesOnly.description,
                defaultValue: true,
            },
        ];
    }
    get Supported() {
        return true;
    }
    async init() {
        this.directoriesToIndex.push('/');
    }
    async step() {
        if (this.directoriesToIndex.length === 0) {
            if (ObjectManagers_1.ObjectManagers.getInstance().IndexingManager.IsSavingInProgress) {
                await ObjectManagers_1.ObjectManagers.getInstance().IndexingManager.SavingReady;
            }
            this.Progress.Left = 0;
            return false;
        }
        const directory = this.directoriesToIndex.shift();
        this.Progress.Left = this.directoriesToIndex.length;
        let scanned;
        let dirChanged = true;
        try {
            const absDirPath = path.join(ProjectPath_1.ProjectPath.ImageFolder, directory);
            if (!fs.existsSync(absDirPath)) {
                this.Progress.log('Skipping. Directory does not exist: ' + directory);
                this.Progress.Skipped++;
            }
            else { // dir should exist now
                // check if the folder got modified if only changes need to be indexed
                if (this.config.indexChangesOnly) {
                    const stat = fs.statSync(absDirPath);
                    const lastModified = DiskMangerWorker_1.DiskMangerWorker.calcLastModified(stat);
                    scanned = await ObjectManagers_1.ObjectManagers.getInstance().GalleryManager.selectDirStructure(directory);
                    // If not modified and it was scanned before, dir is up-to-date
                    if (scanned &&
                        scanned.lastModified === lastModified &&
                        scanned.lastScanned != null) {
                        dirChanged = false;
                    }
                }
                // reindex
                if (dirChanged || !this.config.indexChangesOnly) {
                    this.Progress.log('Indexing: ' + directory);
                    this.Progress.Processed++;
                    scanned =
                        await ObjectManagers_1.ObjectManagers.getInstance().IndexingManager.indexDirectory(directory);
                }
                else {
                    this.Progress.log('Skipping. No change for: ' + directory);
                    this.Progress.Skipped++;
                    Logger_1.Logger.silly(LOG_TAG, 'Skipping reindexing, no change for: ' + directory);
                }
            }
        }
        catch (e) {
            this.Progress.log('Skipping. Indexing failed for: ' + directory);
            this.Progress.Skipped++;
            Logger_1.Logger.warn(LOG_TAG, 'Skipping. Indexing failed for: ' + directory);
            console.error(e);
        }
        if (this.Progress.State !== JobProgressDTO_1.JobProgressStates.running) {
            return false;
        }
        for (const item of scanned.directories) {
            this.directoriesToIndex.push(path.join(item.path, item.name));
        }
        return true;
    }
}
exports.IndexingJob = IndexingJob;
