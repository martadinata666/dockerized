"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ThumbnailGenerationJob = void 0;
const Config_1 = require("../../../../common/config/private/Config");
const JobDTO_1 = require("../../../../common/entities/job/JobDTO");
const FileJob_1 = require("./FileJob");
const PhotoProcessing_1 = require("../../fileprocessing/PhotoProcessing");
const PhotoWorker_1 = require("../../threading/PhotoWorker");
const MediaDTO_1 = require("../../../../common/entities/MediaDTO");
const BackendTexts_1 = require("../../../../common/BackendTexts");
class ThumbnailGenerationJob extends FileJob_1.FileJob {
    constructor() {
        super({ noMetaFile: true });
        this.Name = JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Thumbnail Generation']];
        this.ConfigTemplate.push({
            id: 'sizes',
            type: 'number-array',
            name: BackendTexts_1.backendTexts.sizeToGenerate.name,
            description: BackendTexts_1.backendTexts.sizeToGenerate.description,
            defaultValue: [Config_1.Config.Media.Thumbnail.thumbnailSizes[0]],
        });
    }
    get Supported() {
        return true;
    }
    start(config, soloRun = false, allowParallelRun = false) {
        if (!config || !config.sizes || !Array.isArray(config.sizes) || config.sizes.length === 0) {
            config = config || {};
            config.sizes = this.ConfigTemplate.find(ct => ct.id == 'sizes').defaultValue;
        }
        for (const item of config.sizes) {
            if (Config_1.Config.Media.Thumbnail.thumbnailSizes.indexOf(item) === -1) {
                throw new Error('unknown thumbnails size: ' +
                    item +
                    '. Add it to the possible thumbnail sizes.');
            }
        }
        return super.start(config, soloRun, allowParallelRun);
    }
    async filterMediaFiles(files) {
        return files;
    }
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    async filterMetaFiles(files) {
        return undefined;
    }
    async shouldProcess(mPath) {
        for (const item of this.config.sizes) {
            if (!(await PhotoProcessing_1.PhotoProcessing.convertedPhotoExist(mPath, item))) {
                return true;
            }
        }
        return false;
    }
    async processFile(mPath) {
        for (const item of this.config.sizes) {
            await PhotoProcessing_1.PhotoProcessing.generateThumbnail(mPath, item, MediaDTO_1.MediaDTOUtils.isVideoPath(mPath)
                ? PhotoWorker_1.ThumbnailSourceType.Video
                : PhotoWorker_1.ThumbnailSourceType.Photo, false);
        }
    }
}
exports.ThumbnailGenerationJob = ThumbnailGenerationJob;
