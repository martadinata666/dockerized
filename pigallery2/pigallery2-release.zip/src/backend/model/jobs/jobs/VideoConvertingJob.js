"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VideoConvertingJob = void 0;
const Config_1 = require("../../../../common/config/private/Config");
const JobDTO_1 = require("../../../../common/entities/job/JobDTO");
const FileJob_1 = require("./FileJob");
const VideoProcessing_1 = require("../../fileprocessing/VideoProcessing");
class VideoConvertingJob extends FileJob_1.FileJob {
    constructor() {
        super({ noPhoto: true, noMetaFile: true });
        this.Name = JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Video Converting']];
    }
    get Supported() {
        return Config_1.Config.Media.Video.enabled === true;
    }
    async shouldProcess(mPath) {
        return !(await VideoProcessing_1.VideoProcessing.convertedVideoExist(mPath));
    }
    async processFile(mPath) {
        await VideoProcessing_1.VideoProcessing.convertVideo(mPath);
        if (global.gc) {
            global.gc();
        }
    }
}
exports.VideoConvertingJob = VideoConvertingJob;
