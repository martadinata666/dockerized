"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TopPickSendJob = void 0;
const JobDTO_1 = require("../../../../common/entities/job/JobDTO");
const Job_1 = require("./Job");
const BackendTexts_1 = require("../../../../common/BackendTexts");
const SortingMethods_1 = require("../../../../common/entities/SortingMethods");
const SearchQueryDTO_1 = require("../../../../common/entities/SearchQueryDTO");
const ObjectManagers_1 = require("../../ObjectManagers");
const EmailMediaMessenger_1 = require("../../mediamessengers/EmailMediaMessenger");
const MediaDTO_1 = require("../../../../common/entities/MediaDTO");
class TopPickSendJob extends Job_1.Job {
    constructor() {
        super(...arguments);
        this.Name = JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Top Pick Sending']];
        this.Supported = true;
        this.ConfigTemplate = [
            {
                id: 'mediaPick',
                type: 'MediaPickDTO-array',
                name: BackendTexts_1.backendTexts.mediaPick.name,
                description: BackendTexts_1.backendTexts.mediaPick.description,
                defaultValue: [{
                        searchQuery: {
                            type: SearchQueryDTO_1.SearchQueryTypes.date_pattern,
                            daysLength: 7,
                            frequency: SearchQueryDTO_1.DatePatternFrequency.every_year
                        },
                        sortBy: [{ method: SortingMethods_1.SortByTypes.Rating, ascending: false },
                            { method: SortingMethods_1.SortByTypes.PersonCount, ascending: false }],
                        pick: 5
                    }],
            }, {
                id: 'emailTo',
                type: 'string-array',
                name: BackendTexts_1.backendTexts.emailTo.name,
                description: BackendTexts_1.backendTexts.emailTo.description,
                defaultValue: [],
            }, {
                id: 'emailSubject',
                type: 'string',
                name: BackendTexts_1.backendTexts.emailSubject.name,
                description: BackendTexts_1.backendTexts.emailSubject.description,
                defaultValue: 'Latest photos for you',
            }, {
                id: 'emailText',
                type: 'string',
                name: BackendTexts_1.backendTexts.emailText.name,
                description: BackendTexts_1.backendTexts.emailText.description,
                defaultValue: 'I hand picked these photos just for you:',
            },
        ];
        this.status = 'Listing';
        this.mediaList = [];
    }
    async init() {
        this.status = 'Listing';
        this.mediaList = [];
        this.Progress.Left = 2;
    }
    async step() {
        switch (this.status) {
            case 'Listing':
                if (!await this.stepListing()) {
                    this.status = 'Sending';
                }
                return true;
            case 'Sending':
                await this.stepSending();
        }
        return false;
    }
    async stepListing() {
        this.Progress.log('Collecting Photos and videos to Send.');
        this.mediaList = [];
        for (let i = 0; i < this.config.mediaPick.length; ++i) {
            const media = await ObjectManagers_1.ObjectManagers.getInstance().SearchManager
                .getNMedia(this.config.mediaPick[i].searchQuery, this.config.mediaPick[i].sortBy, this.config.mediaPick[i].pick);
            this.Progress.log('Find ' + media.length + ' photos and videos from ' + (i + 1) + '. load');
            this.mediaList = this.mediaList.concat(media);
        }
        // make the list unique
        this.mediaList = this.mediaList
            .filter((value, index, arr) => arr.findIndex(m => MediaDTO_1.MediaDTOUtils.equals(m, value)) === index);
        this.Progress.Processed++;
        // console.log(this.mediaList);
        return false;
    }
    async stepSending() {
        if (this.mediaList.length <= 0) {
            this.Progress.log('No photos found skipping e-mail sending.');
            this.Progress.Skipped++;
            return false;
        }
        this.Progress.log('Sending emails of ' + this.mediaList.length + ' photos.');
        const messenger = new EmailMediaMessenger_1.EmailMediaMessenger();
        await messenger.sendMedia({
            to: this.config.emailTo,
            subject: this.config.emailSubject,
            text: this.config.emailText
        }, this.mediaList);
        this.Progress.Processed++;
        return false;
    }
}
exports.TopPickSendJob = TopPickSendJob;
