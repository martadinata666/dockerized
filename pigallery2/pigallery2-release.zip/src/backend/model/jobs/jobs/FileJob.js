"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileJob = void 0;
const Job_1 = require("./Job");
const path = require("path");
const DiskManger_1 = require("../../DiskManger");
const Logger_1 = require("../../../Logger");
const Config_1 = require("../../../../common/config/private/Config");
const SQLConnection_1 = require("../../database/SQLConnection");
const MediaEntity_1 = require("../../database/enitites/MediaEntity");
const PhotoEntity_1 = require("../../database/enitites/PhotoEntity");
const VideoEntity_1 = require("../../database/enitites/VideoEntity");
const BackendTexts_1 = require("../../../../common/BackendTexts");
const ProjectPath_1 = require("../../../ProjectPath");
const FileEntity_1 = require("../../database/enitites/FileEntity");
const DirectoryDTO_1 = require("../../../../common/entities/DirectoryDTO");
const LOG_TAG = '[FileJob]';
/**
 * Abstract class for thumbnail creation, file deleting etc.
 */
class FileJob extends Job_1.Job {
    constructor(scanFilter) {
        super();
        this.scanFilter = scanFilter;
        this.ConfigTemplate = [];
        this.directoryQueue = [];
        this.fileQueue = [];
        this.DBProcessing = {
            mediaLoaded: 0,
            hasMoreMedia: true,
            initiated: false
        };
        this.scanFilter.noChildDirPhotos = true;
        this.ConfigTemplate.push({
            id: 'indexedOnly',
            type: 'boolean',
            name: BackendTexts_1.backendTexts.indexedFilesOnly.name,
            description: BackendTexts_1.backendTexts.indexedFilesOnly.description,
            defaultValue: true,
        });
    }
    async init() {
        this.directoryQueue = [];
        this.fileQueue = [];
        this.DBProcessing = {
            mediaLoaded: 0,
            hasMoreMedia: true,
            initiated: false
        };
        this.directoryQueue.push('/');
    }
    async filterMediaFiles(files) {
        return files;
    }
    async filterMetaFiles(files) {
        return files;
    }
    async step() {
        if (this.fileQueue.length === 0 &&
            ((this.directoryQueue.length === 0 && !this.config.indexedOnly) ||
                (this.config.indexedOnly &&
                    this.DBProcessing.hasMoreMedia === false))) {
            return false;
        }
        if (!this.config.indexedOnly) {
            if (this.directoryQueue.length > 0) {
                await this.loadADirectoryFromDisk();
                return true;
            }
            else if (this.fileQueue.length > 0) {
                this.Progress.Left = this.fileQueue.length;
            }
        }
        else {
            if (!this.DBProcessing.initiated) {
                this.Progress.log('Counting files from db');
                Logger_1.Logger.silly(LOG_TAG, 'Counting files from db');
                this.Progress.All = await this.countMediaFromDB();
                this.Progress.log('Found:' + this.Progress.All);
                Logger_1.Logger.silly(LOG_TAG, 'Found:' + this.Progress.All);
                this.DBProcessing.initiated = true;
                return true;
            }
            if (this.fileQueue.length === 0) {
                await this.loadMediaFilesFromDB();
                return true;
            }
        }
        const filePath = this.fileQueue.shift();
        try {
            if ((await this.shouldProcess(filePath)) === true) {
                this.Progress.Processed++;
                this.Progress.log('processing: ' + filePath);
                await this.processFile(filePath);
            }
            else {
                this.Progress.log('skipping: ' + filePath);
                this.Progress.Skipped++;
            }
        }
        catch (e) {
            console.error(e);
            Logger_1.Logger.error(LOG_TAG, 'Error during processing file:' + filePath + ', ' + e.toString());
            this.Progress.log('Error during processing file:' + filePath + ', ' + e.toString());
        }
        return true;
    }
    async loadADirectoryFromDisk() {
        const directory = this.directoryQueue.shift();
        this.Progress.log('scanning directory: ' + directory);
        const scanned = await DiskManger_1.DiskManager.scanDirectoryNoMetadata(directory, this.scanFilter);
        for (const item of scanned.directories) {
            this.directoryQueue.push(path.join(item.path, item.name));
        }
        DirectoryDTO_1.DirectoryDTOUtils.addReferences(scanned);
        if (this.scanFilter.noPhoto !== true || this.scanFilter.noVideo !== true) {
            const scannedAndFiltered = await this.filterMediaFiles(scanned.media);
            const skipped = scanned.media.length - scannedAndFiltered.length;
            if (skipped > 0) {
                this.Progress.log('batch skipping: ' + skipped);
                this.Progress.Skipped += skipped;
            }
            for (const item of scannedAndFiltered) {
                this.fileQueue.push(path.join(ProjectPath_1.ProjectPath.ImageFolder, item.directory.path, item.directory.name, item.name));
            }
        }
        if (this.scanFilter.noMetaFile !== true) {
            const scannedAndFiltered = await this.filterMetaFiles(scanned.metaFile);
            const skipped = scanned.metaFile.length - scannedAndFiltered.length;
            if (skipped > 0) {
                this.Progress.log('batch skipping: ' + skipped);
                this.Progress.Skipped += skipped;
            }
            for (const item of scannedAndFiltered) {
                this.fileQueue.push(path.join(ProjectPath_1.ProjectPath.ImageFolder, item.directory.path, item.directory.name, item.name));
            }
        }
    }
    async loadMediaFilesFromDB() {
        if (this.scanFilter.noVideo === true &&
            this.scanFilter.noPhoto === true &&
            this.scanFilter.noMetaFile === true) {
            return;
        }
        const logStr = `Loading next batch of files from db. Skipping: ${this.DBProcessing.mediaLoaded}, looking for more: ${Config_1.Config.Jobs.mediaProcessingBatchSize}`;
        this.Progress.log(logStr);
        Logger_1.Logger.silly(LOG_TAG, logStr);
        const hasMoreFile = {
            media: false,
            metafile: false
        };
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        if (!this.scanFilter.noVideo ||
            !this.scanFilter.noPhoto) {
            let usedEntity = MediaEntity_1.MediaEntity;
            if (this.scanFilter.noVideo === true) {
                usedEntity = PhotoEntity_1.PhotoEntity;
            }
            else if (this.scanFilter.noPhoto === true) {
                usedEntity = VideoEntity_1.VideoEntity;
            }
            const result = await connection
                .getRepository(usedEntity)
                .createQueryBuilder('media')
                .select(['media.name', 'directory.name', 'directory.path'])
                .leftJoin('media.directory', 'directory')
                .offset(this.DBProcessing.mediaLoaded)
                .limit(Config_1.Config.Jobs.mediaProcessingBatchSize)
                .getMany();
            hasMoreFile.media = result.length > 0;
            this.DBProcessing.mediaLoaded += result.length;
            const scannedAndFiltered = await this.filterMediaFiles(result);
            const skipped = result.length - scannedAndFiltered.length;
            if (skipped > 0) {
                this.Progress.log('batch skipping: ' + skipped);
                this.Progress.Skipped += skipped;
            }
            for (const item of scannedAndFiltered) {
                this.fileQueue.push(path.join(ProjectPath_1.ProjectPath.ImageFolder, item.directory.path, item.directory.name, item.name));
            }
        }
        if (!this.scanFilter.noMetaFile) {
            const result = await connection
                .getRepository(FileEntity_1.FileEntity)
                .createQueryBuilder('file')
                .select(['file.name', 'directory.name', 'directory.path'])
                .leftJoin('file.directory', 'directory')
                .offset(this.DBProcessing.mediaLoaded)
                .limit(Config_1.Config.Jobs.mediaProcessingBatchSize)
                .getMany();
            hasMoreFile.metafile = result.length > 0;
            this.DBProcessing.mediaLoaded += result.length;
            const scannedAndFiltered = await this.filterMetaFiles(result);
            const skipped = result.length - scannedAndFiltered.length;
            if (skipped > 0) {
                this.Progress.log('batch skipping: ' + skipped);
                this.Progress.Skipped += skipped;
            }
            for (const item of scannedAndFiltered) {
                this.fileQueue.push(path.join(ProjectPath_1.ProjectPath.ImageFolder, item.directory.path, item.directory.name, item.name));
            }
        }
        this.DBProcessing.hasMoreMedia = hasMoreFile.media || hasMoreFile.metafile;
    }
    async countMediaFromDB() {
        if (this.scanFilter.noVideo === true &&
            this.scanFilter.noPhoto === true &&
            this.scanFilter.noMetaFile === true) {
            return;
        }
        let count = 0;
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        if (!this.scanFilter.noVideo ||
            !this.scanFilter.noPhoto) {
            let usedEntity = MediaEntity_1.MediaEntity;
            if (this.scanFilter.noVideo === true) {
                usedEntity = PhotoEntity_1.PhotoEntity;
            }
            else if (this.scanFilter.noPhoto === true) {
                usedEntity = VideoEntity_1.VideoEntity;
            }
            count += await connection
                .getRepository(usedEntity)
                .createQueryBuilder('media')
                .getCount();
        }
        if (!this.scanFilter.noMetaFile) {
            count += await connection
                .getRepository(FileEntity_1.FileEntity)
                .createQueryBuilder('file')
                .getCount();
        }
        return count;
    }
}
exports.FileJob = FileJob;
