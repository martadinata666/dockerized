"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GPXCompressionJob = void 0;
const Config_1 = require("../../../../common/config/private/Config");
const JobDTO_1 = require("../../../../common/entities/job/JobDTO");
const FileJob_1 = require("./FileJob");
const GPXProcessing_1 = require("../../fileprocessing/GPXProcessing");
const Logger_1 = require("../../../Logger");
class GPXCompressionJob extends FileJob_1.FileJob {
    constructor() {
        super({ noVideo: true, noPhoto: true, noMetaFile: false });
        this.Name = JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['GPX Compression']];
    }
    async filterMetaFiles(files) {
        return files.filter(file => file.name.toLowerCase().endsWith('.gpx'));
    }
    get Supported() {
        return Config_1.Config.MetaFile.GPXCompressing.enabled === true;
    }
    async shouldProcess(fPath) {
        return !(await GPXProcessing_1.GPXProcessing.compressedGPXExist(fPath));
    }
    async processFile(fPath) {
        try {
            await GPXProcessing_1.GPXProcessing.compressGPX(fPath);
        }
        catch (e) {
            Logger_1.Logger.warn('GPXCompressionJob', ' Could not compress gpx at: ' + fPath);
        }
    }
}
exports.GPXCompressionJob = GPXCompressionJob;
