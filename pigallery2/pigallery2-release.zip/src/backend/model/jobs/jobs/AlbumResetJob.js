"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumRestJob = void 0;
const ObjectManagers_1 = require("../../ObjectManagers");
const JobDTO_1 = require("../../../../common/entities/job/JobDTO");
const Job_1 = require("./Job");
class AlbumRestJob extends Job_1.Job {
    constructor() {
        super(...arguments);
        this.Name = JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Album Reset']];
        this.ConfigTemplate = null;
        this.IsInstant = true;
    }
    get Supported() {
        return true;
    }
    async init() {
        // abstract function
    }
    async step() {
        this.Progress.Left = 1;
        this.Progress.Processed++;
        await ObjectManagers_1.ObjectManagers.getInstance().AlbumManager.deleteAll();
        return false;
    }
}
exports.AlbumRestJob = AlbumRestJob;
