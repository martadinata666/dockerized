"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GPXCompressionResetJob = void 0;
const JobDTO_1 = require("../../../../common/entities/job/JobDTO");
const TempFolderCleaningJob_1 = require("./TempFolderCleaningJob");
const GPXProcessing_1 = require("../../fileprocessing/GPXProcessing");
/**
 * Deletes all gpx file from the tmp folder
 */
class GPXCompressionResetJob extends TempFolderCleaningJob_1.TempFolderCleaningJob {
    constructor() {
        super(...arguments);
        this.Name = JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Delete Compressed GPX']];
    }
    // returns false if the file is GPX
    async isValidFile(filePath) {
        return !GPXProcessing_1.GPXProcessing.isGPXFile(filePath);
    }
}
exports.GPXCompressionResetJob = GPXCompressionResetJob;
