"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PhotoConvertingJob = void 0;
const Config_1 = require("../../../../common/config/private/Config");
const JobDTO_1 = require("../../../../common/entities/job/JobDTO");
const FileJob_1 = require("./FileJob");
const PhotoProcessing_1 = require("../../fileprocessing/PhotoProcessing");
class PhotoConvertingJob extends FileJob_1.FileJob {
    constructor() {
        super({ noVideo: true, noMetaFile: true });
        this.Name = JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Photo Converting']];
    }
    get Supported() {
        return Config_1.Config.Media.Photo.Converting.enabled === true;
    }
    async shouldProcess(mPath) {
        return !(await PhotoProcessing_1.PhotoProcessing.convertedPhotoExist(mPath, Config_1.Config.Media.Photo.Converting.resolution));
    }
    async processFile(mPath) {
        await PhotoProcessing_1.PhotoProcessing.convertPhoto(mPath);
    }
}
exports.PhotoConvertingJob = PhotoConvertingJob;
