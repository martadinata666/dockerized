"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TempFolderCleaningJob = void 0;
const JobDTO_1 = require("../../../../common/entities/job/JobDTO");
const path = require("path");
const fs = require("fs");
const Job_1 = require("./Job");
const ProjectPath_1 = require("../../../ProjectPath");
const PhotoProcessing_1 = require("../../fileprocessing/PhotoProcessing");
const VideoProcessing_1 = require("../../fileprocessing/VideoProcessing");
const GPXProcessing_1 = require("../../fileprocessing/GPXProcessing");
class TempFolderCleaningJob extends Job_1.Job {
    constructor() {
        super(...arguments);
        this.Name = JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Temp Folder Cleaning']];
        this.ConfigTemplate = null;
        this.Supported = true;
        this.directoryQueue = [];
        this.tempRootCleaned = false;
    }
    async init() {
        this.tempRootCleaned = false;
        this.directoryQueue = [];
        this.directoryQueue.push(ProjectPath_1.ProjectPath.TranscodedFolder);
    }
    async isValidFile(filePath) {
        if (PhotoProcessing_1.PhotoProcessing.isPhoto(filePath)) {
            return PhotoProcessing_1.PhotoProcessing.isValidConvertedPath(filePath);
        }
        if (VideoProcessing_1.VideoProcessing.isVideo(filePath)) {
            return VideoProcessing_1.VideoProcessing.isValidConvertedPath(filePath);
        }
        if (GPXProcessing_1.GPXProcessing.isMetaFile(filePath)) {
            return GPXProcessing_1.GPXProcessing.isValidConvertedPath(filePath);
        }
        return false;
    }
    async isValidDirectory(filePath) {
        const originalPath = path.join(ProjectPath_1.ProjectPath.ImageFolder, path.relative(ProjectPath_1.ProjectPath.TranscodedFolder, filePath));
        try {
            await fs.promises.access(originalPath);
            return true;
        }
        catch (e) {
            // ignoring errors
        }
        return false;
    }
    async readDir(dirPath) {
        return (await fs.promises.readdir(dirPath)).map((f) => path.normalize(path.join(dirPath, f)));
    }
    async stepTempDirectory() {
        const files = await this.readDir(ProjectPath_1.ProjectPath.TempFolder);
        const validFiles = [ProjectPath_1.ProjectPath.TranscodedFolder, ProjectPath_1.ProjectPath.FacesFolder];
        for (const file of files) {
            if (validFiles.indexOf(file) === -1) {
                this.Progress.log('processing: ' + file);
                this.Progress.Processed++;
                if ((await fs.promises.stat(file)).isDirectory()) {
                    await fs.promises.rm(file, { recursive: true });
                }
                else {
                    await fs.promises.unlink(file);
                }
            }
            else {
                this.Progress.log('skipping: ' + file);
                this.Progress.Skipped++;
            }
        }
        return true;
    }
    async stepConvertedDirectory() {
        const filePath = this.directoryQueue.shift();
        const stat = await fs.promises.stat(filePath);
        this.Progress.Left = this.directoryQueue.length;
        if (stat.isDirectory()) {
            if ((await this.isValidDirectory(filePath)) === false) {
                this.Progress.log('processing: ' + filePath);
                this.Progress.Processed++;
                await fs.promises.rm(filePath, { recursive: true });
            }
            else {
                this.Progress.log('skipping: ' + filePath);
                this.Progress.Skipped++;
                this.directoryQueue = this.directoryQueue.concat(await this.readDir(filePath));
            }
        }
        else {
            if ((await this.isValidFile(filePath)) === false) {
                this.Progress.log('processing: ' + filePath);
                this.Progress.Processed++;
                await fs.promises.unlink(filePath);
            }
            else {
                this.Progress.log('skipping: ' + filePath);
                this.Progress.Skipped++;
            }
        }
        return true;
    }
    async step() {
        if (this.directoryQueue.length === 0) {
            this.Progress.Left = 0;
            return false;
        }
        if (this.tempRootCleaned === false) {
            this.tempRootCleaned = true;
            return this.stepTempDirectory();
        }
        return this.stepConvertedDirectory();
    }
}
exports.TempFolderCleaningJob = TempFolderCleaningJob;
