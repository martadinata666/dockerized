"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumCoverFillingJob = void 0;
const ObjectManagers_1 = require("../../ObjectManagers");
const JobDTO_1 = require("../../../../common/entities/job/JobDTO");
const Job_1 = require("./Job");
class AlbumCoverFillingJob extends Job_1.Job {
    constructor() {
        super(...arguments);
        this.Name = JobDTO_1.DefaultsJobs[JobDTO_1.DefaultsJobs['Album Cover Filling']];
        this.ConfigTemplate = null;
        this.directoryToSetCover = null;
        this.status = 'Persons';
    }
    get Supported() {
        return true;
    }
    async init() {
        this.status = 'Persons';
    }
    async step() {
        if (!this.directoryToSetCover) {
            this.Progress.log('Loading Directories to process');
            this.directoryToSetCover =
                await ObjectManagers_1.ObjectManagers.getInstance().CoverManager.getPartialDirsWithoutCovers();
            this.Progress.Left = this.directoryToSetCover.length + 2;
            return true;
        }
        switch (this.status) {
            case 'Persons':
                await this.stepPersonsPreview();
                this.status = 'Albums';
                return true;
            case 'Albums':
                await this.stepAlbumCover();
                this.status = 'Directory';
                return true;
            case 'Directory':
                return await this.stepDirectoryCover();
        }
        return false;
    }
    async stepAlbumCover() {
        await ObjectManagers_1.ObjectManagers.getInstance().AlbumManager.getAlbums();
        this.Progress.log('Updating Albums cover');
        this.Progress.Processed++;
        return false;
    }
    async stepPersonsPreview() {
        await ObjectManagers_1.ObjectManagers.getInstance().PersonManager.getAll();
        this.Progress.log('Updating Persons preview');
        this.Progress.Processed++;
        return false;
    }
    async stepDirectoryCover() {
        if (this.directoryToSetCover.length === 0) {
            this.directoryToSetCover =
                await ObjectManagers_1.ObjectManagers.getInstance().CoverManager.getPartialDirsWithoutCovers();
            // double check if there is really no more
            if (this.directoryToSetCover.length > 0) {
                return true; // continue
            }
            this.Progress.Left = 0;
            return false;
        }
        const directory = this.directoryToSetCover.shift();
        this.Progress.log('Setting cover: ' + directory.path + directory.name);
        this.Progress.Left = this.directoryToSetCover.length;
        await ObjectManagers_1.ObjectManagers.getInstance().CoverManager.setAndGetCoverForDirectory(directory);
        this.Progress.Processed++;
        return true;
    }
}
exports.AlbumCoverFillingJob = AlbumCoverFillingJob;
