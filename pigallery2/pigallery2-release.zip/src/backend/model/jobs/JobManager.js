"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JobManager = void 0;
const JobProgressDTO_1 = require("../../../common/entities/job/JobProgressDTO");
const JobRepository_1 = require("./JobRepository");
const Config_1 = require("../../../common/config/private/Config");
const JobScheduleDTO_1 = require("../../../common/entities/job/JobScheduleDTO");
const Logger_1 = require("../../Logger");
const NotifocationManager_1 = require("../NotifocationManager");
const JobProgressManager_1 = require("./JobProgressManager");
const JobDTO_1 = require("../../../common/entities/job/JobDTO");
const Utils_1 = require("../../../common/Utils");
const LOG_TAG = '[JobManager]';
class JobManager {
    constructor() {
        this.timers = [];
        this.progressManager = null;
        this.onProgressUpdate = (progress) => {
            this.progressManager.onJobProgressUpdate(progress.toDTO());
        };
        this.onJobFinished = async (job, state, soloRun) => {
            // if it was not finished peacefully or was a soloRun, do not start the next one
            if (state !== JobProgressDTO_1.JobProgressStates.finished || soloRun === true) {
                return;
            }
            const sch = Config_1.Config.Jobs.scheduled.find((s) => s.jobName === job.Name);
            if (sch) {
                const children = Config_1.Config.Jobs.scheduled.filter((s) => s.trigger.type === JobScheduleDTO_1.JobTriggerType.after &&
                    s.trigger.afterScheduleName === sch.name);
                for (const item of children) {
                    try {
                        await this.run(item.jobName, item.config, false, item.allowParallelRun);
                    }
                    catch (e) {
                        NotifocationManager_1.NotificationManager.warning('Job running error:' + item.name, e.toString());
                    }
                }
            }
        };
        this.progressManager = new JobProgressManager_1.JobProgressManager();
        this.runSchedules();
    }
    get JobRunning() {
        return (JobRepository_1.JobRepository.Instance.getAvailableJobs().findIndex((j) => j.InProgress === true) !== -1);
    }
    get JobNoParallelRunning() {
        return (JobRepository_1.JobRepository.Instance.getAvailableJobs().findIndex((j) => j.InProgress === true && j.allowParallelRun) !== -1);
    }
    getProgresses() {
        const prg = Utils_1.Utils.clone(this.progressManager.Progresses);
        this.timers.forEach(t => {
            if (!prg[JobDTO_1.JobDTOUtils.getHashName(t.schedule.jobName, t.schedule.config)]) {
                return;
            }
            prg[JobDTO_1.JobDTOUtils.getHashName(t.schedule.jobName, t.schedule.config)].onTimer = true;
        });
        return prg;
    }
    async run(jobName, config, soloRun, allowParallelRun) {
        if ((allowParallelRun === false && this.JobRunning === true) ||
            this.JobNoParallelRunning === true) {
            throw new Error('Can\'t start this job while another is running');
        }
        const t = this.findJob(jobName);
        if (t) {
            t.JobListener = this;
            await t.start(config, soloRun, allowParallelRun);
        }
        else {
            Logger_1.Logger.warn(LOG_TAG, 'cannot find job to start:' + jobName);
        }
    }
    stop(jobName) {
        const t = this.findJob(jobName);
        if (t) {
            t.cancel();
        }
        else {
            Logger_1.Logger.warn(LOG_TAG, 'cannot find job to stop:' + jobName);
        }
    }
    getAvailableJobs() {
        return JobRepository_1.JobRepository.Instance.getAvailableJobs();
    }
    stopSchedules() {
        this.timers.forEach((t) => clearTimeout(t.timer));
        this.timers = [];
    }
    /**
     * Schedules all jobs to run
     */
    runSchedules() {
        this.stopSchedules();
        Logger_1.Logger.info(LOG_TAG, 'Running job schedules');
        Config_1.Config.Jobs.scheduled.forEach((s) => this.runSchedule(s));
    }
    findJob(jobName) {
        return this.getAvailableJobs().find((t) => t.Name === jobName);
    }
    /**
     * Schedules a single job to run
     */
    runSchedule(schedule) {
        const nextDate = JobScheduleDTO_1.JobScheduleDTOUtils.getNextRunningDate(new Date(), schedule);
        if (nextDate && nextDate.getTime() > Date.now()) {
            Logger_1.Logger.debug(LOG_TAG, 'running schedule: ' +
                schedule.jobName +
                ' at ' +
                nextDate.toLocaleString(undefined, { hour12: false }));
            const timer = setTimeout(async () => {
                this.timers = this.timers.filter((t) => t.timer !== timer);
                await this.run(schedule.jobName, schedule.config, false, schedule.allowParallelRun);
                this.runSchedule(schedule);
            }, nextDate.getTime() - Date.now());
            this.timers.push({ schedule, timer });
        }
        else {
            Logger_1.Logger.debug(LOG_TAG, 'skipping schedule:' + schedule.jobName);
        }
    }
}
exports.JobManager = JobManager;
