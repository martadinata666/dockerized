"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoverManager = void 0;
const Config_1 = require("../../../common/config/private/Config");
const typeorm_1 = require("typeorm");
const MediaEntity_1 = require("./enitites/MediaEntity");
const DiskMangerWorker_1 = require("../threading/DiskMangerWorker");
const ObjectManagers_1 = require("../ObjectManagers");
const PrivateConfig_1 = require("../../../common/config/private/PrivateConfig");
const SQLConnection_1 = require("./SQLConnection");
const SearchQueryDTO_1 = require("../../../common/entities/SearchQueryDTO");
const DirectoryEntity_1 = require("./enitites/DirectoryEntity");
const path = require("path");
const Utils_1 = require("../../../common/Utils");
const Logger_1 = require("../../Logger");
const SearchManager_1 = require("./SearchManager");
const LOG_TAG = '[CoverManager]';
class CoverManager {
    static { this.DIRECTORY_SELECT = ['directory.name', 'directory.path']; }
    async resetCovers() {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        await connection
            .createQueryBuilder()
            .update(DirectoryEntity_1.DirectoryEntity)
            .set({ validCover: false })
            .execute();
    }
    async onNewDataVersion(changedDir) {
        // Invalidating Album cover
        let fullPath = DiskMangerWorker_1.DiskMangerWorker.normalizeDirPath(path.join(changedDir.path, changedDir.name));
        const query = (await SQLConnection_1.SQLConnection.getConnection())
            .createQueryBuilder()
            .update(DirectoryEntity_1.DirectoryEntity)
            .set({ validCover: false });
        let i = 0;
        const root = DiskMangerWorker_1.DiskMangerWorker.pathFromRelativeDirName('.');
        while (fullPath !== root) {
            const name = DiskMangerWorker_1.DiskMangerWorker.dirName(fullPath);
            const parentPath = DiskMangerWorker_1.DiskMangerWorker.pathFromRelativeDirName(fullPath);
            fullPath = parentPath;
            ++i;
            query.orWhere(new typeorm_1.Brackets((q) => {
                const param = {};
                param['name' + i] = name;
                param['path' + i] = parentPath;
                q.where(`path = :path${i}`, param);
                q.andWhere(`name = :name${i}`, param);
            }));
        }
        ++i;
        query.orWhere(new typeorm_1.Brackets((q) => {
            const param = {};
            param['name' + i] = DiskMangerWorker_1.DiskMangerWorker.dirName('.');
            param['path' + i] = DiskMangerWorker_1.DiskMangerWorker.pathFromRelativeDirName('.');
            q.where(`path = :path${i}`, param);
            q.andWhere(`name = :name${i}`, param);
        }));
        await query.execute();
    }
    async getAlbumCover(album) {
        const albumQuery = await ObjectManagers_1.ObjectManagers.getInstance().SearchManager.prepareAndBuildWhereQuery(album.searchQuery);
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const coverQuery = () => {
            const query = connection
                .getRepository(MediaEntity_1.MediaEntity)
                .createQueryBuilder('media')
                .innerJoin('media.directory', 'directory')
                .select(['media.name', 'media.id', ...CoverManager.DIRECTORY_SELECT])
                .where(albumQuery);
            SearchManager_1.SearchManager.setSorting(query, Config_1.Config.AlbumCover.Sorting);
            return query;
        };
        let coverMedia = null;
        if (Config_1.Config.AlbumCover.SearchQuery &&
            !Utils_1.Utils.equalsFilter(Config_1.Config.AlbumCover.SearchQuery, {
                type: SearchQueryDTO_1.SearchQueryTypes.any_text,
                text: '',
            })) {
            try {
                const coverFilterQuery = await ObjectManagers_1.ObjectManagers.getInstance().SearchManager.prepareAndBuildWhereQuery(Config_1.Config.AlbumCover.SearchQuery);
                coverMedia = await coverQuery()
                    .andWhere(coverFilterQuery)
                    .limit(1)
                    .getOne();
            }
            catch (e) {
                Logger_1.Logger.error(LOG_TAG, 'Cant get album cover using:', JSON.stringify(album.searchQuery), JSON.stringify(Config_1.Config.AlbumCover.SearchQuery));
                throw e;
            }
        }
        if (!coverMedia) {
            try {
                coverMedia = await coverQuery().limit(1).getOne();
            }
            catch (e) {
                Logger_1.Logger.error(LOG_TAG, 'Cant get album cover using:', JSON.stringify(album.searchQuery));
                throw e;
            }
        }
        return coverMedia || null;
    }
    async getPartialDirsWithoutCovers() {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        return await connection
            .getRepository(DirectoryEntity_1.DirectoryEntity)
            .createQueryBuilder('directory')
            .where('directory.validCover = :validCover', { validCover: 0 }) // 0 === false
            .select(['name', 'id', 'path'])
            .getRawMany();
    }
    async setAndGetCoverForDirectory(dir) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const coverQuery = () => {
            const query = connection
                .getRepository(MediaEntity_1.MediaEntity)
                .createQueryBuilder('media')
                .innerJoin('media.directory', 'directory')
                .select(['media.name', 'media.id', ...CoverManager.DIRECTORY_SELECT])
                .where(new typeorm_1.Brackets((q) => {
                q.where('media.directory = :dir', {
                    dir: dir.id,
                });
                if (Config_1.Config.Database.type === PrivateConfig_1.DatabaseType.mysql) {
                    q.orWhere('directory.path like :path || \'%\'', {
                        path: DiskMangerWorker_1.DiskMangerWorker.pathFromParent(dir),
                    });
                }
                else {
                    q.orWhere('directory.path GLOB :path', {
                        path: DiskMangerWorker_1.DiskMangerWorker.pathFromParent(dir)
                            // glob escaping. see https://github.com/bpatrik/pigallery2/issues/621
                            .replaceAll('[', '[[]') + '*',
                    });
                }
            }));
            // Select from the directory if any otherwise from any subdirectories.
            // (There is no priority between subdirectories)
            query.orderBy(`CASE WHEN directory.id = ${dir.id} THEN 0 ELSE 1 END`, 'ASC');
            SearchManager_1.SearchManager.setSorting(query, Config_1.Config.AlbumCover.Sorting);
            return query;
        };
        let coverMedia = null;
        if (Config_1.Config.AlbumCover.SearchQuery &&
            !Utils_1.Utils.equalsFilter(Config_1.Config.AlbumCover.SearchQuery, {
                type: SearchQueryDTO_1.SearchQueryTypes.any_text,
                text: '',
            })) {
            coverMedia = await coverQuery()
                .andWhere(await ObjectManagers_1.ObjectManagers.getInstance().SearchManager.prepareAndBuildWhereQuery(Config_1.Config.AlbumCover.SearchQuery))
                .limit(1)
                .getOne();
        }
        if (!coverMedia) {
            coverMedia = await coverQuery().limit(1).getOne();
        }
        // set validCover bit to true even if there is no cover (to prevent future updates)
        await connection
            .createQueryBuilder()
            .update(DirectoryEntity_1.DirectoryEntity)
            .set({ cover: coverMedia, validCover: true })
            .where('id = :dir', {
            dir: dir.id,
        })
            .execute();
        return coverMedia || null;
    }
}
exports.CoverManager = CoverManager;
