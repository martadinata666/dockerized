"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PersonManager = void 0;
const SQLConnection_1 = require("./SQLConnection");
const PersonEntry_1 = require("./enitites/PersonEntry");
const Logger_1 = require("../../Logger");
const EntityUtils_1 = require("./enitites/EntityUtils");
const PersonJunctionTable_1 = require("./enitites/PersonJunctionTable");
const LOG_TAG = '[PersonManager]';
class PersonManager {
    constructor() {
        this.persons = null;
        /**
         * Person table contains denormalized data that needs to update when isDBValid = false
         */
        this.isDBValid = false;
    }
    static async updateCounts() {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        await connection.query('UPDATE person_entry SET count = ' +
            ' (SELECT COUNT(1) FROM person_junction_table WHERE person_junction_table.personId = person_entry.id)');
        // remove persons without photo
        await connection
            .createQueryBuilder()
            .delete()
            .from(PersonEntry_1.PersonEntry)
            .where('count = 0')
            .execute();
    }
    static async updateSamplePhotos() {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        await connection.query('update person_entry set sampleRegionId = ' +
            '(Select person_junction_table.id from  media_entity ' +
            'left join person_junction_table on media_entity.id = person_junction_table.mediaId ' +
            'where person_junction_table.personId=person_entry.id ' +
            'order by media_entity.metadataRating desc, ' +
            'media_entity.metadataCreationdate desc ' +
            'limit 1)');
    }
    async updatePerson(name, partialPerson) {
        this.isDBValid = false;
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const repository = connection.getRepository(PersonEntry_1.PersonEntry);
        const person = await repository
            .createQueryBuilder('person')
            .limit(1)
            .where('person.name LIKE :name COLLATE ' + EntityUtils_1.SQL_COLLATE, { name })
            .getOne();
        if (typeof partialPerson.name !== 'undefined') {
            person.name = partialPerson.name;
        }
        if (typeof partialPerson.isFavourite !== 'undefined') {
            person.isFavourite = partialPerson.isFavourite;
        }
        await repository.save(person);
        await this.loadAll();
        return person;
    }
    async getAll() {
        if (this.persons === null) {
            await this.loadAll();
        }
        return this.persons;
    }
    /**
     * Used for statistic
     */
    async countFaces() {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        return await connection
            .getRepository(PersonJunctionTable_1.PersonJunctionTable)
            .createQueryBuilder('personJunction')
            .getCount();
    }
    async get(name) {
        if (this.persons === null) {
            await this.loadAll();
        }
        return this.persons.find((p) => p.name === name);
    }
    async saveAll(persons) {
        const toSave = [];
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const personRepository = connection.getRepository(PersonEntry_1.PersonEntry);
        const personJunction = connection.getRepository(PersonJunctionTable_1.PersonJunctionTable);
        const savedPersons = await personRepository.find();
        // filter already existing persons
        for (const personToSave of persons) {
            const person = savedPersons.find((p) => p.name === personToSave.name);
            if (!person) {
                toSave.push(personToSave);
            }
        }
        if (toSave.length > 0) {
            for (let i = 0; i < toSave.length / 200; i++) {
                const saving = toSave.slice(i * 200, (i + 1) * 200);
                // saving person
                const inserted = await personRepository.insert(saving.map((p) => ({ name: p.name })));
                // saving junction table
                const junctionTable = inserted.identifiers.map((idObj, j) => ({ person: idObj, media: { id: saving[j].mediaId } }));
                await personJunction.insert(junctionTable);
            }
        }
        this.isDBValid = false;
    }
    async onNewDataVersion() {
        await this.resetPreviews();
    }
    async resetPreviews() {
        this.persons = null;
        this.isDBValid = false;
    }
    async loadAll() {
        await this.updateDerivedValues();
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const personRepository = connection.getRepository(PersonEntry_1.PersonEntry);
        this.persons = await personRepository.find({
            relations: [
                'sampleRegion',
                'sampleRegion.media',
                'sampleRegion.media.directory',
                'sampleRegion.media.metadata',
            ],
        });
    }
    /**
     * Person table contains derived, denormalized data for faster select, this needs to be updated after data change
     * @private
     */
    async updateDerivedValues() {
        if (this.isDBValid === true) {
            return;
        }
        Logger_1.Logger.debug(LOG_TAG, 'Updating derived persons data');
        await PersonManager.updateCounts();
        await PersonManager.updateSamplePhotos();
        this.isDBValid = false;
    }
}
exports.PersonManager = PersonManager;
