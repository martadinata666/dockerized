"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VideoEntity = exports.VideoMetadataEntity = void 0;
const tslib_1 = require("tslib");
const typeorm_1 = require("typeorm");
const MediaEntity_1 = require("./MediaEntity");
class VideoMetadataEntity extends MediaEntity_1.MediaMetadataEntity {
}
tslib_1.__decorate([
    (0, typeorm_1.Column)('int'),
    tslib_1.__metadata("design:type", Number)
], VideoMetadataEntity.prototype, "bitRate", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('bigint', {
        unsigned: true,
        nullable: true,
        transformer: {
            from: (v) => parseInt(v, 10) || null,
            to: (v) => v,
        },
    }),
    tslib_1.__metadata("design:type", Number)
], VideoMetadataEntity.prototype, "duration", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('int'),
    tslib_1.__metadata("design:type", Number)
], VideoMetadataEntity.prototype, "fps", void 0);
exports.VideoMetadataEntity = VideoMetadataEntity;
let VideoEntity = class VideoEntity extends MediaEntity_1.MediaEntity {
};
tslib_1.__decorate([
    (0, typeorm_1.Column)(() => VideoMetadataEntity),
    tslib_1.__metadata("design:type", VideoMetadataEntity)
], VideoEntity.prototype, "metadata", void 0);
VideoEntity = tslib_1.__decorate([
    (0, typeorm_1.ChildEntity)()
], VideoEntity);
exports.VideoEntity = VideoEntity;
