"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SharingEntity = void 0;
const tslib_1 = require("tslib");
const typeorm_1 = require("typeorm");
const UserEntity_1 = require("./UserEntity");
let SharingEntity = class SharingEntity {
};
tslib_1.__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ unsigned: true }),
    tslib_1.__metadata("design:type", Number)
], SharingEntity.prototype, "id", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)(),
    tslib_1.__metadata("design:type", String)
], SharingEntity.prototype, "sharingKey", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)(),
    tslib_1.__metadata("design:type", String)
], SharingEntity.prototype, "path", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    tslib_1.__metadata("design:type", String)
], SharingEntity.prototype, "password", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('bigint', {
        unsigned: true,
        transformer: {
            from: (v) => parseInt(v, 10),
            to: (v) => v,
        },
    }),
    tslib_1.__metadata("design:type", Number)
], SharingEntity.prototype, "expires", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('bigint', {
        unsigned: true,
        transformer: {
            from: (v) => parseInt(v, 10),
            to: (v) => v,
        },
    }),
    tslib_1.__metadata("design:type", Number)
], SharingEntity.prototype, "timeStamp", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)(),
    tslib_1.__metadata("design:type", Boolean)
], SharingEntity.prototype, "includeSubfolders", void 0);
tslib_1.__decorate([
    (0, typeorm_1.ManyToOne)(() => UserEntity_1.UserEntity, { onDelete: 'CASCADE', nullable: false }),
    tslib_1.__metadata("design:type", Object)
], SharingEntity.prototype, "creator", void 0);
SharingEntity = tslib_1.__decorate([
    (0, typeorm_1.Entity)()
], SharingEntity);
exports.SharingEntity = SharingEntity;
