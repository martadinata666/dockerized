"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PersonJunctionTable = void 0;
const tslib_1 = require("tslib");
const typeorm_1 = require("typeorm");
const PersonEntry_1 = require("./PersonEntry");
const MediaEntity_1 = require("./MediaEntity");
/**
 * This is a junction table between media and persons
 */
let PersonJunctionTable = class PersonJunctionTable {
};
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.PrimaryGeneratedColumn)({ unsigned: true }),
    tslib_1.__metadata("design:type", Number)
], PersonJunctionTable.prototype, "id", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.ManyToOne)(() => MediaEntity_1.MediaEntity, (media) => media.metadata.faces, {
        onDelete: 'CASCADE',
        nullable: false,
    }),
    tslib_1.__metadata("design:type", MediaEntity_1.MediaEntity)
], PersonJunctionTable.prototype, "media", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.ManyToOne)(() => PersonEntry_1.PersonEntry, (person) => person.faces, {
        onDelete: 'CASCADE',
        nullable: false,
    }),
    tslib_1.__metadata("design:type", PersonEntry_1.PersonEntry)
], PersonJunctionTable.prototype, "person", void 0);
PersonJunctionTable = tslib_1.__decorate([
    (0, typeorm_1.Entity)()
], PersonJunctionTable);
exports.PersonJunctionTable = PersonJunctionTable;
