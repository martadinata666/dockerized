"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaEntity = exports.MediaMetadataEntity = exports.PositionMetaDataEntity = exports.GPSMetadataEntity = exports.CameraMetadataEntity = exports.MediaDimensionEntity = void 0;
const tslib_1 = require("tslib");
const typeorm_1 = require("typeorm");
const DirectoryEntity_1 = require("./DirectoryEntity");
const PersonJunctionTable_1 = require("./PersonJunctionTable");
const EntityUtils_1 = require("./EntityUtils");
class MediaDimensionEntity {
}
tslib_1.__decorate([
    (0, typeorm_1.Column)('int'),
    tslib_1.__metadata("design:type", Number)
], MediaDimensionEntity.prototype, "width", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('int'),
    tslib_1.__metadata("design:type", Number)
], MediaDimensionEntity.prototype, "height", void 0);
exports.MediaDimensionEntity = MediaDimensionEntity;
class CameraMetadataEntity {
}
tslib_1.__decorate([
    (0, typeorm_1.Column)('int', { nullable: true, unsigned: true }),
    tslib_1.__metadata("design:type", Number)
], CameraMetadataEntity.prototype, "ISO", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({
        type: 'text',
        nullable: true,
        charset: EntityUtils_1.columnCharsetCS.charset,
        collation: EntityUtils_1.columnCharsetCS.collation,
    }),
    tslib_1.__metadata("design:type", String)
], CameraMetadataEntity.prototype, "model", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({
        type: 'text',
        nullable: true,
        charset: EntityUtils_1.columnCharsetCS.charset,
        collation: EntityUtils_1.columnCharsetCS.collation,
    }),
    tslib_1.__metadata("design:type", String)
], CameraMetadataEntity.prototype, "make", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('float', { nullable: true }),
    tslib_1.__metadata("design:type", Number)
], CameraMetadataEntity.prototype, "fStop", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('float', { nullable: true }),
    tslib_1.__metadata("design:type", Number)
], CameraMetadataEntity.prototype, "exposure", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('float', { nullable: true }),
    tslib_1.__metadata("design:type", Number)
], CameraMetadataEntity.prototype, "focalLength", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('text', { nullable: true }),
    tslib_1.__metadata("design:type", String)
], CameraMetadataEntity.prototype, "lens", void 0);
exports.CameraMetadataEntity = CameraMetadataEntity;
class GPSMetadataEntity {
}
tslib_1.__decorate([
    (0, typeorm_1.Column)('float', { nullable: true }),
    tslib_1.__metadata("design:type", Number)
], GPSMetadataEntity.prototype, "latitude", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('float', { nullable: true }),
    tslib_1.__metadata("design:type", Number)
], GPSMetadataEntity.prototype, "longitude", void 0);
exports.GPSMetadataEntity = GPSMetadataEntity;
class PositionMetaDataEntity {
}
tslib_1.__decorate([
    (0, typeorm_1.Column)(() => GPSMetadataEntity),
    tslib_1.__metadata("design:type", GPSMetadataEntity)
], PositionMetaDataEntity.prototype, "GPSData", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({
        type: 'text',
        nullable: true,
        charset: EntityUtils_1.columnCharsetCS.charset,
        collation: EntityUtils_1.columnCharsetCS.collation,
    }),
    tslib_1.__metadata("design:type", String)
], PositionMetaDataEntity.prototype, "country", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({
        type: 'text',
        nullable: true,
        charset: EntityUtils_1.columnCharsetCS.charset,
        collation: EntityUtils_1.columnCharsetCS.collation,
    }),
    tslib_1.__metadata("design:type", String)
], PositionMetaDataEntity.prototype, "state", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({
        type: 'text',
        nullable: true,
        charset: EntityUtils_1.columnCharsetCS.charset,
        collation: EntityUtils_1.columnCharsetCS.collation,
    }),
    tslib_1.__metadata("design:type", String)
], PositionMetaDataEntity.prototype, "city", void 0);
exports.PositionMetaDataEntity = PositionMetaDataEntity;
class MediaMetadataEntity {
}
tslib_1.__decorate([
    (0, typeorm_1.Column)('text'),
    tslib_1.__metadata("design:type", String)
], MediaMetadataEntity.prototype, "caption", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)(() => MediaDimensionEntity),
    tslib_1.__metadata("design:type", MediaDimensionEntity)
], MediaMetadataEntity.prototype, "size", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('bigint', {
        transformer: {
            from: (v) => parseInt(v, 10),
            to: (v) => v,
        },
    }),
    (0, typeorm_1.Index)(),
    tslib_1.__metadata("design:type", Number)
], MediaMetadataEntity.prototype, "creationDate", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('int', { unsigned: true }),
    tslib_1.__metadata("design:type", Number)
], MediaMetadataEntity.prototype, "fileSize", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({
        type: 'simple-array',
        charset: EntityUtils_1.columnCharsetCS.charset,
        collation: EntityUtils_1.columnCharsetCS.collation,
    }),
    tslib_1.__metadata("design:type", Array)
], MediaMetadataEntity.prototype, "keywords", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)(() => CameraMetadataEntity),
    tslib_1.__metadata("design:type", CameraMetadataEntity)
], MediaMetadataEntity.prototype, "cameraData", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)(() => PositionMetaDataEntity),
    tslib_1.__metadata("design:type", PositionMetaDataEntity)
], MediaMetadataEntity.prototype, "positionData", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('tinyint', { unsigned: true }),
    (0, typeorm_1.Index)(),
    tslib_1.__metadata("design:type", Number)
], MediaMetadataEntity.prototype, "rating", void 0);
tslib_1.__decorate([
    (0, typeorm_1.OneToMany)(() => PersonJunctionTable_1.PersonJunctionTable, (junctionTable) => junctionTable.media),
    tslib_1.__metadata("design:type", Array)
], MediaMetadataEntity.prototype, "personJunction", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({
        type: 'simple-json',
        nullable: true,
        charset: EntityUtils_1.columnCharsetCS.charset,
        collation: EntityUtils_1.columnCharsetCS.collation
    }),
    tslib_1.__metadata("design:type", Array)
], MediaMetadataEntity.prototype, "faces", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({
        type: 'simple-array',
        select: false,
        nullable: true,
        charset: EntityUtils_1.columnCharsetCS.charset,
        collation: EntityUtils_1.columnCharsetCS.collation,
    }),
    tslib_1.__metadata("design:type", Array)
], MediaMetadataEntity.prototype, "persons", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({
        type: 'tinyint',
        select: false,
        nullable: false,
        default: 0
    }),
    tslib_1.__metadata("design:type", Number)
], MediaMetadataEntity.prototype, "personsLength", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('int', { unsigned: true }),
    tslib_1.__metadata("design:type", Number)
], MediaMetadataEntity.prototype, "bitRate", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('int', { unsigned: true }),
    tslib_1.__metadata("design:type", Number)
], MediaMetadataEntity.prototype, "duration", void 0);
exports.MediaMetadataEntity = MediaMetadataEntity;
// TODO: fix inheritance once its working in typeorm
let MediaEntity = class MediaEntity {
};
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.PrimaryGeneratedColumn)({ unsigned: true }),
    tslib_1.__metadata("design:type", Number)
], MediaEntity.prototype, "id", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)(EntityUtils_1.columnCharsetCS),
    tslib_1.__metadata("design:type", String)
], MediaEntity.prototype, "name", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.ManyToOne)(() => DirectoryEntity_1.DirectoryEntity, (directory) => directory.media, {
        onDelete: 'CASCADE',
        nullable: false,
    }),
    tslib_1.__metadata("design:type", DirectoryEntity_1.DirectoryEntity)
], MediaEntity.prototype, "directory", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)(() => MediaMetadataEntity),
    tslib_1.__metadata("design:type", MediaMetadataEntity)
], MediaEntity.prototype, "metadata", void 0);
MediaEntity = tslib_1.__decorate([
    (0, typeorm_1.Entity)(),
    (0, typeorm_1.Unique)(['name', 'directory']),
    (0, typeorm_1.TableInheritance)({ column: { type: 'varchar', name: 'type', length: 16 } })
], MediaEntity);
exports.MediaEntity = MediaEntity;
