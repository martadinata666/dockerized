"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SavedSearchEntity = void 0;
const tslib_1 = require("tslib");
const typeorm_1 = require("typeorm");
const AlbumBaseEntity_1 = require("./AlbumBaseEntity");
let SavedSearchEntity = class SavedSearchEntity extends AlbumBaseEntity_1.AlbumBaseEntity {
};
tslib_1.__decorate([
    (0, typeorm_1.Column)({
        type: 'text',
        nullable: false,
        transformer: {
            // used to deserialize your data from db field value
            from: (val) => {
                return JSON.parse(val);
            },
            // used to serialize your data to db field
            to: (val) => {
                return JSON.stringify(val);
            },
        },
    }),
    tslib_1.__metadata("design:type", Object)
], SavedSearchEntity.prototype, "searchQuery", void 0);
SavedSearchEntity = tslib_1.__decorate([
    (0, typeorm_1.ChildEntity)()
], SavedSearchEntity);
exports.SavedSearchEntity = SavedSearchEntity;
