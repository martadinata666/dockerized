"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumBaseEntity = void 0;
const tslib_1 = require("tslib");
const typeorm_1 = require("typeorm");
const MediaEntity_1 = require("../MediaEntity");
const EntityUtils_1 = require("../EntityUtils");
let AlbumBaseEntity = class AlbumBaseEntity {
};
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.PrimaryGeneratedColumn)({ unsigned: true }),
    tslib_1.__metadata("design:type", Number)
], AlbumBaseEntity.prototype, "id", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.Column)(EntityUtils_1.columnCharsetCS),
    tslib_1.__metadata("design:type", String)
], AlbumBaseEntity.prototype, "name", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({ default: false }),
    tslib_1.__metadata("design:type", Boolean)
], AlbumBaseEntity.prototype, "locked", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('int', { unsigned: true, default: 0 }),
    tslib_1.__metadata("design:type", Number)
], AlbumBaseEntity.prototype, "count", void 0);
tslib_1.__decorate([
    (0, typeorm_1.ManyToOne)(() => MediaEntity_1.MediaEntity, { onDelete: 'SET NULL', nullable: true }),
    tslib_1.__metadata("design:type", MediaEntity_1.MediaEntity)
], AlbumBaseEntity.prototype, "cover", void 0);
AlbumBaseEntity = tslib_1.__decorate([
    (0, typeorm_1.Entity)(),
    (0, typeorm_1.TableInheritance)({ column: { type: 'varchar', name: 'type', length: 24 } })
], AlbumBaseEntity);
exports.AlbumBaseEntity = AlbumBaseEntity;
