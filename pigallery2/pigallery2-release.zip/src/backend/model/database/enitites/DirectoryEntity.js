"use strict";
var DirectoryEntity_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DirectoryEntity = void 0;
const tslib_1 = require("tslib");
const typeorm_1 = require("typeorm");
const MediaEntity_1 = require("./MediaEntity");
const FileEntity_1 = require("./FileEntity");
const EntityUtils_1 = require("./EntityUtils");
let DirectoryEntity = DirectoryEntity_1 = class DirectoryEntity {
};
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.PrimaryGeneratedColumn)({ unsigned: true }),
    tslib_1.__metadata("design:type", Number)
], DirectoryEntity.prototype, "id", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.Column)(EntityUtils_1.columnCharsetCS),
    tslib_1.__metadata("design:type", String)
], DirectoryEntity.prototype, "name", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.Column)(EntityUtils_1.columnCharsetCS),
    tslib_1.__metadata("design:type", String)
], DirectoryEntity.prototype, "path", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('bigint', {
        unsigned: true,
        transformer: {
            from: (v) => parseInt(v, 10),
            to: (v) => v,
        },
    }),
    tslib_1.__metadata("design:type", Number)
], DirectoryEntity.prototype, "lastModified", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({
        type: 'bigint',
        nullable: true,
        unsigned: true,
        transformer: {
            from: (v) => parseInt(v, 10) || null,
            to: (v) => v,
        },
    }),
    tslib_1.__metadata("design:type", Number)
], DirectoryEntity.prototype, "lastScanned", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('mediumint', { unsigned: true }),
    tslib_1.__metadata("design:type", Number)
], DirectoryEntity.prototype, "mediaCount", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('bigint', {
        nullable: true,
        transformer: {
            from: (v) => parseInt(v, 10),
            to: (v) => v,
        },
    }),
    tslib_1.__metadata("design:type", Number)
], DirectoryEntity.prototype, "oldestMedia", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('bigint', {
        nullable: true,
        transformer: {
            from: (v) => parseInt(v, 10),
            to: (v) => v,
        },
    }),
    tslib_1.__metadata("design:type", Number)
], DirectoryEntity.prototype, "youngestMedia", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.ManyToOne)(() => DirectoryEntity_1, (directory) => directory.directories, {
        onDelete: 'CASCADE',
    }),
    tslib_1.__metadata("design:type", DirectoryEntity)
], DirectoryEntity.prototype, "parent", void 0);
tslib_1.__decorate([
    (0, typeorm_1.OneToMany)(() => DirectoryEntity_1, (dir) => dir.parent),
    tslib_1.__metadata("design:type", Array)
], DirectoryEntity.prototype, "directories", void 0);
tslib_1.__decorate([
    (0, typeorm_1.ManyToOne)(() => MediaEntity_1.MediaEntity, { onDelete: 'SET NULL' }),
    tslib_1.__metadata("design:type", MediaEntity_1.MediaEntity)
], DirectoryEntity.prototype, "cover", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    tslib_1.__metadata("design:type", Boolean)
], DirectoryEntity.prototype, "validCover", void 0);
tslib_1.__decorate([
    (0, typeorm_1.OneToMany)(() => MediaEntity_1.MediaEntity, (media) => media.directory),
    tslib_1.__metadata("design:type", Array)
], DirectoryEntity.prototype, "media", void 0);
tslib_1.__decorate([
    (0, typeorm_1.OneToMany)(() => FileEntity_1.FileEntity, (file) => file.directory),
    tslib_1.__metadata("design:type", Array)
], DirectoryEntity.prototype, "metaFile", void 0);
DirectoryEntity = DirectoryEntity_1 = tslib_1.__decorate([
    (0, typeorm_1.Entity)(),
    (0, typeorm_1.Unique)(['name', 'path'])
], DirectoryEntity);
exports.DirectoryEntity = DirectoryEntity;
