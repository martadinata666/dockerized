"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PersonEntry = void 0;
const tslib_1 = require("tslib");
const typeorm_1 = require("typeorm");
const PersonJunctionTable_1 = require("./PersonJunctionTable");
const EntityUtils_1 = require("./EntityUtils");
let PersonEntry = class PersonEntry {
};
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.PrimaryGeneratedColumn)({ unsigned: true }),
    tslib_1.__metadata("design:type", Number)
], PersonEntry.prototype, "id", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)(EntityUtils_1.columnCharsetCS),
    tslib_1.__metadata("design:type", String)
], PersonEntry.prototype, "name", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)('int', { unsigned: true, default: 0 }),
    tslib_1.__metadata("design:type", Number)
], PersonEntry.prototype, "count", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)({ default: false }),
    tslib_1.__metadata("design:type", Boolean)
], PersonEntry.prototype, "isFavourite", void 0);
tslib_1.__decorate([
    (0, typeorm_1.OneToMany)(() => PersonJunctionTable_1.PersonJunctionTable, (junctionTable) => junctionTable.person),
    tslib_1.__metadata("design:type", Array)
], PersonEntry.prototype, "faces", void 0);
tslib_1.__decorate([
    (0, typeorm_1.ManyToOne)(() => PersonJunctionTable_1.PersonJunctionTable, {
        onDelete: 'SET NULL',
        nullable: true,
    }),
    tslib_1.__metadata("design:type", PersonJunctionTable_1.PersonJunctionTable)
], PersonEntry.prototype, "sampleRegion", void 0);
PersonEntry = tslib_1.__decorate([
    (0, typeorm_1.Entity)(),
    (0, typeorm_1.Unique)(['name'])
], PersonEntry);
exports.PersonEntry = PersonEntry;
