"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileEntity = void 0;
const tslib_1 = require("tslib");
const typeorm_1 = require("typeorm");
const DirectoryEntity_1 = require("./DirectoryEntity");
const EntityUtils_1 = require("./EntityUtils");
let FileEntity = class FileEntity {
};
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.PrimaryGeneratedColumn)({ unsigned: true }),
    tslib_1.__metadata("design:type", Number)
], FileEntity.prototype, "id", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Column)(EntityUtils_1.columnCharsetCS),
    tslib_1.__metadata("design:type", String)
], FileEntity.prototype, "name", void 0);
tslib_1.__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.ManyToOne)(() => DirectoryEntity_1.DirectoryEntity, (directory) => directory.metaFile, {
        onDelete: 'CASCADE',
        nullable: false,
    }),
    tslib_1.__metadata("design:type", DirectoryEntity_1.DirectoryEntity)
], FileEntity.prototype, "directory", void 0);
FileEntity = tslib_1.__decorate([
    (0, typeorm_1.Entity)(),
    (0, typeorm_1.TableInheritance)({ column: { type: 'varchar', name: 'type', length: 16 } })
], FileEntity);
exports.FileEntity = FileEntity;
