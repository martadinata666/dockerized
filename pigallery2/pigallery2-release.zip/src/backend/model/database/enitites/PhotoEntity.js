"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PhotoEntity = exports.PhotoMetadataEntity = void 0;
const tslib_1 = require("tslib");
const typeorm_1 = require("typeorm");
const MediaEntity_1 = require("./MediaEntity");
class PhotoMetadataEntity extends MediaEntity_1.MediaMetadataEntity {
}
exports.PhotoMetadataEntity = PhotoMetadataEntity;
let PhotoEntity = class PhotoEntity extends MediaEntity_1.MediaEntity {
};
tslib_1.__decorate([
    (0, typeorm_1.Column)(() => PhotoMetadataEntity),
    tslib_1.__metadata("design:type", PhotoMetadataEntity)
], PhotoEntity.prototype, "metadata", void 0);
PhotoEntity = tslib_1.__decorate([
    (0, typeorm_1.ChildEntity)()
], PhotoEntity);
exports.PhotoEntity = PhotoEntity;
