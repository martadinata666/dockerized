"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MDFileEntity = void 0;
const tslib_1 = require("tslib");
const typeorm_1 = require("typeorm");
const FileEntity_1 = require("./FileEntity");
let MDFileEntity = class MDFileEntity extends FileEntity_1.FileEntity {
};
tslib_1.__decorate([
    (0, typeorm_1.Column)('bigint', {
        transformer: {
            from: (v) => parseInt(v, 10),
            to: (v) => v,
        },
    }),
    tslib_1.__metadata("design:type", Number)
], MDFileEntity.prototype, "date", void 0);
MDFileEntity = tslib_1.__decorate([
    (0, typeorm_1.ChildEntity)()
], MDFileEntity);
exports.MDFileEntity = MDFileEntity;
