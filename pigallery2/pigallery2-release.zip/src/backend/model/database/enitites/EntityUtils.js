"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SQL_COLLATE = exports.columnCharsetCS = exports.ColumnCharsetCS = void 0;
const Config_1 = require("../../../../common/config/private/Config");
const PrivateConfig_1 = require("../../../../common/config/private/PrivateConfig");
class ColumnCharsetCS {
    get charset() {
        return Config_1.Config.Database.type === PrivateConfig_1.DatabaseType.mysql
            ? 'utf8mb4'
            : 'utf8';
    }
    get collation() {
        return Config_1.Config.Database.type === PrivateConfig_1.DatabaseType.mysql
            ? 'utf8mb4_bin'
            : null;
    }
}
exports.ColumnCharsetCS = ColumnCharsetCS;
exports.columnCharsetCS = new ColumnCharsetCS();
exports.SQL_COLLATE = 'utf8mb4_general_ci';
