"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VersionManager = void 0;
const crypto = require("crypto");
const DataStructureVersion_1 = require("../../../common/DataStructureVersion");
const SQLConnection_1 = require("./SQLConnection");
const DirectoryEntity_1 = require("./enitites/DirectoryEntity");
const MediaEntity_1 = require("./enitites/MediaEntity");
class VersionManager {
    constructor() {
        this.allMediaCount = 0;
        this.latestDirectoryStatus = null;
    }
    async getDataVersion() {
        if (this.latestDirectoryStatus === null) {
            await this.onNewDataVersion();
        }
        if (!this.latestDirectoryStatus) {
            return DataStructureVersion_1.DataStructureVersion.toString();
        }
        const versionString = DataStructureVersion_1.DataStructureVersion +
            '_' +
            this.latestDirectoryStatus.name +
            '_' +
            this.latestDirectoryStatus.lastModified +
            '_' +
            this.latestDirectoryStatus.mediaCount +
            '_' +
            this.allMediaCount;
        return crypto.createHash('md5').update(versionString).digest('hex');
    }
    async onNewDataVersion() {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const dir = await connection
            .getRepository(DirectoryEntity_1.DirectoryEntity)
            .createQueryBuilder('directory')
            .limit(1)
            .orderBy('directory.lastModified')
            .getOne();
        this.allMediaCount = await connection
            .getRepository(MediaEntity_1.MediaEntity)
            .createQueryBuilder('media')
            .getCount();
        if (!dir) {
            return;
        }
        this.latestDirectoryStatus = {
            mediaCount: dir.mediaCount,
            lastModified: dir.lastModified,
            name: dir.name,
        };
    }
}
exports.VersionManager = VersionManager;
