"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserManager = void 0;
const UserEntity_1 = require("./enitites/UserEntity");
const SQLConnection_1 = require("./SQLConnection");
const PasswordHelper_1 = require("../PasswordHelper");
class UserManager {
    async findOne(filter) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const pass = filter.password;
        delete filter.password;
        const user = await connection.getRepository(UserEntity_1.UserEntity).findOneBy(filter);
        if (pass && !PasswordHelper_1.PasswordHelper.comparePassword(pass, user.password)) {
            throw new Error('No entry found');
        }
        return user;
    }
    async find(filter) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        return await connection.getRepository(UserEntity_1.UserEntity).findBy(filter);
    }
    async createUser(user) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        user.password = PasswordHelper_1.PasswordHelper.cryptPassword(user.password);
        return connection.getRepository(UserEntity_1.UserEntity).save(user);
    }
    async deleteUser(id) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const user = await connection.getRepository(UserEntity_1.UserEntity).findOneBy({ id });
        return await connection.getRepository(UserEntity_1.UserEntity).remove(user);
    }
    async changeRole(id, newRole) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const userRepository = connection.getRepository(UserEntity_1.UserEntity);
        const user = await userRepository.findOneBy({ id });
        user.role = newRole;
        return userRepository.save(user);
    }
}
exports.UserManager = UserManager;
