"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SQLConnection = void 0;
require("reflect-metadata");
const typeorm_1 = require("typeorm");
const UserEntity_1 = require("./enitites/UserEntity");
const UserDTO_1 = require("../../../common/entities/UserDTO");
const PhotoEntity_1 = require("./enitites/PhotoEntity");
const DirectoryEntity_1 = require("./enitites/DirectoryEntity");
const Config_1 = require("../../../common/config/private/Config");
const SharingEntity_1 = require("./enitites/SharingEntity");
const PasswordHelper_1 = require("../PasswordHelper");
const ProjectPath_1 = require("../../ProjectPath");
const VersionEntity_1 = require("./enitites/VersionEntity");
const Logger_1 = require("../../Logger");
const MediaEntity_1 = require("./enitites/MediaEntity");
const VideoEntity_1 = require("./enitites/VideoEntity");
const DataStructureVersion_1 = require("../../../common/DataStructureVersion");
const FileEntity_1 = require("./enitites/FileEntity");
const PersonEntry_1 = require("./enitites/PersonEntry");
const Utils_1 = require("../../../common/Utils");
const path = require("path");
const PrivateConfig_1 = require("../../../common/config/private/PrivateConfig");
const AlbumBaseEntity_1 = require("./enitites/album/AlbumBaseEntity");
const SavedSearchEntity_1 = require("./enitites/album/SavedSearchEntity");
const NotifocationManager_1 = require("../NotifocationManager");
const PersonJunctionTable_1 = require("./enitites/PersonJunctionTable");
const MDFileEntity_1 = require("./enitites/MDFileEntity");
const LOG_TAG = '[SQLConnection]';
class SQLConnection {
    static { this.connection = null; }
    static async getConnection() {
        if (this.connection == null) {
            const options = this.getDriver(Config_1.Config.Database);
            Logger_1.Logger.debug(LOG_TAG, 'Creating connection: ' + PrivateConfig_1.DatabaseType[Config_1.Config.Database.type], ', with driver:', options.type);
            this.connection = await this.createConnection(options);
            await SQLConnection.schemeSync(this.connection);
        }
        return this.connection;
    }
    static async tryConnection(config) {
        try {
            await (0, typeorm_1.getConnection)('test').close();
            // eslint-disable-next-line no-empty
        }
        catch (err) {
        }
        const options = this.getDriver(config);
        options.name = 'test';
        const conn = await this.createConnection(options);
        await SQLConnection.schemeSync(conn);
        await conn.close();
        return true;
    }
    static async init() {
        const connection = await this.getConnection();
        if (Config_1.Config.Users.authenticationRequired !== true) {
            return;
        }
        // Adding enforced users to the db
        const userRepository = connection.getRepository(UserEntity_1.UserEntity);
        if (Array.isArray(Config_1.Config.Users.enforcedUsers) &&
            Config_1.Config.Users.enforcedUsers.length > 0) {
            for (let i = 0; i < Config_1.Config.Users.enforcedUsers.length; ++i) {
                const uc = Config_1.Config.Users.enforcedUsers[i];
                const user = await userRepository.findOneBy({ name: uc.name });
                if (!user) {
                    Logger_1.Logger.info(LOG_TAG, 'Saving enforced user: ' + uc.name);
                    const a = new UserEntity_1.UserEntity();
                    a.name = uc.name;
                    a.password = uc.encryptedPassword;
                    a.role = uc.role;
                    await userRepository.save(a);
                }
            }
        }
        // Add dummy Admin to the db
        const admins = await userRepository.findBy({ role: UserDTO_1.UserRoles.Admin });
        const devs = await userRepository.findBy({ role: UserDTO_1.UserRoles.Developer });
        if (admins.length === 0 && devs.length === 0) {
            const a = new UserEntity_1.UserEntity();
            a.name = 'admin';
            a.password = PasswordHelper_1.PasswordHelper.cryptPassword('admin');
            a.role = UserDTO_1.UserRoles.Admin;
            await userRepository.save(a);
        }
        const defAdmin = await userRepository.findOneBy({
            name: 'admin',
            role: UserDTO_1.UserRoles.Admin,
        });
        if (defAdmin &&
            PasswordHelper_1.PasswordHelper.comparePassword('admin', defAdmin.password)) {
            NotifocationManager_1.NotificationManager.error('Using default admin user!', 'You are using the default admin/admin user/password, please change or remove it.');
        }
    }
    static async close() {
        try {
            if (this.connection != null) {
                await this.connection.close();
                this.connection = null;
            }
        }
        catch (err) {
            console.error('Error during closing sql db:');
            console.error(err);
        }
    }
    static getSQLiteDB(config) {
        return path.join(ProjectPath_1.ProjectPath.getAbsolutePath(config.dbFolder), 'sqlite.db');
    }
    static async createConnection(options) {
        if (options.type === 'sqlite' || options.type === 'better-sqlite3') {
            return await (0, typeorm_1.createConnection)(options);
        }
        try {
            return await (0, typeorm_1.createConnection)(options);
        }
        catch (e) {
            if (e.sqlMessage === 'Unknown database \'' + options.database + '\'') {
                Logger_1.Logger.debug(LOG_TAG, 'creating database: ' + options.database);
                const tmpOption = Utils_1.Utils.clone(options);
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-ignore
                delete tmpOption.database;
                const tmpConn = await (0, typeorm_1.createConnection)(tmpOption);
                await tmpConn.query('CREATE DATABASE IF NOT EXISTS ' + options.database);
                await tmpConn.close();
                return await (0, typeorm_1.createConnection)(options);
            }
            throw e;
        }
    }
    static async schemeSync(connection) {
        let version = null;
        try {
            version = (await connection.getRepository(VersionEntity_1.VersionEntity).find())[0];
            // eslint-disable-next-line no-empty
        }
        catch (ex) {
        }
        if (version && version.version === DataStructureVersion_1.DataStructureVersion) {
            return;
        }
        Logger_1.Logger.info(LOG_TAG, 'Updating database scheme');
        if (!version) {
            version = new VersionEntity_1.VersionEntity();
        }
        version.version = DataStructureVersion_1.DataStructureVersion;
        let users = [];
        try {
            users = await connection
                .getRepository(UserEntity_1.UserEntity)
                .createQueryBuilder('user')
                .getMany();
            // eslint-disable-next-line no-empty
        }
        catch (ex) {
        }
        await connection.dropDatabase();
        await connection.synchronize();
        await connection.getRepository(VersionEntity_1.VersionEntity).save(version);
        try {
            await connection.getRepository(UserEntity_1.UserEntity).save(users);
        }
        catch (e) {
            await connection.dropDatabase();
            await connection.synchronize();
            await connection.getRepository(VersionEntity_1.VersionEntity).save(version);
            Logger_1.Logger.warn(LOG_TAG, 'Could not move users to the new db scheme, deleting them. Details:' +
                e.toString());
        }
    }
    static getDriver(config) {
        let driver;
        if (config.type === PrivateConfig_1.DatabaseType.mysql) {
            driver = {
                type: 'mysql',
                host: config.mysql.host,
                port: config.mysql.port,
                username: config.mysql.username,
                password: config.mysql.password,
                database: config.mysql.database,
                charset: 'utf8mb4',
            };
        }
        else if (config.type === PrivateConfig_1.DatabaseType.sqlite) {
            driver = {
                type: 'better-sqlite3',
                database: path.join(ProjectPath_1.ProjectPath.getAbsolutePath(config.dbFolder), config.sqlite.DBFileName),
            };
        }
        driver.entities = [
            UserEntity_1.UserEntity,
            FileEntity_1.FileEntity,
            MDFileEntity_1.MDFileEntity,
            PersonJunctionTable_1.PersonJunctionTable,
            PersonEntry_1.PersonEntry,
            MediaEntity_1.MediaEntity,
            PhotoEntity_1.PhotoEntity,
            VideoEntity_1.VideoEntity,
            DirectoryEntity_1.DirectoryEntity,
            SharingEntity_1.SharingEntity,
            AlbumBaseEntity_1.AlbumBaseEntity,
            SavedSearchEntity_1.SavedSearchEntity,
            VersionEntity_1.VersionEntity,
        ];
        driver.synchronize = false;
        if (Config_1.Config.Server.Log.sqlLevel !== PrivateConfig_1.SQLLogLevel.none) {
            driver.logging = PrivateConfig_1.SQLLogLevel[Config_1.Config.Server.Log.sqlLevel];
        }
        return driver;
    }
}
exports.SQLConnection = SQLConnection;
