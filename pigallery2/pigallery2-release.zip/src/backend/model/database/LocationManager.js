"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocationManager = void 0;
const NodeGeocoder = require("node-geocoder");
const LocationLookupException_1 = require("../../exceptions/LocationLookupException");
const Utils_1 = require("../../../common/Utils");
class LocationManager {
    constructor() {
        this.cache = new Utils_1.LRU(100);
        this.geocoder = NodeGeocoder({ provider: 'openstreetmap' });
    }
    async getGPSData(text) {
        if (!this.cache.get(text)) {
            const ret = await this.geocoder.geocode(text);
            if (ret.length < 1) {
                throw new LocationLookupException_1.LocationLookupException('Cannot find location:' + text, text);
            }
            this.cache.set(text, {
                latitude: ret[0].latitude,
                longitude: ret[0].longitude,
            });
        }
        return this.cache.get(text);
    }
}
exports.LocationManager = LocationManager;
