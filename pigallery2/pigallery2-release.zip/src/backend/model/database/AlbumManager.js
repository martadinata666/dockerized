"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumManager = void 0;
const SQLConnection_1 = require("./SQLConnection");
const AlbumBaseEntity_1 = require("./enitites/album/AlbumBaseEntity");
const ObjectManagers_1 = require("../ObjectManagers");
const SavedSearchEntity_1 = require("./enitites/album/SavedSearchEntity");
const Logger_1 = require("../../Logger");
const LOG_TAG = '[AlbumManager]';
class AlbumManager {
    constructor() {
        /**
         * Person table contains denormalized data that needs to update when isDBValid = false
         */
        this.isDBValid = false;
    }
    static async updateAlbum(album) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const cover = await ObjectManagers_1.ObjectManagers.getInstance().CoverManager.getAlbumCover(album);
        const count = await ObjectManagers_1.ObjectManagers.getInstance().SearchManager.getCount(album.searchQuery);
        await connection
            .createQueryBuilder()
            .update(AlbumBaseEntity_1.AlbumBaseEntity)
            .set({ cover: cover, count })
            .where('id = :id', { id: album.id })
            .execute();
    }
    async addIfNotExistSavedSearch(name, searchQuery, lockedAlbum) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const album = await connection
            .getRepository(SavedSearchEntity_1.SavedSearchEntity)
            .findOneBy({ name, searchQuery });
        if (album) {
            return;
        }
        await this.addSavedSearch(name, searchQuery, lockedAlbum);
    }
    async addSavedSearch(name, searchQuery, lockedAlbum) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const a = await connection
            .getRepository(SavedSearchEntity_1.SavedSearchEntity)
            .save({ name, searchQuery, locked: lockedAlbum });
        await AlbumManager.updateAlbum(a);
    }
    async deleteAlbum(id) {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        if ((await connection
            .getRepository(AlbumBaseEntity_1.AlbumBaseEntity)
            .countBy({ id, locked: false })) !== 1) {
            throw new Error('Could not delete album, id:' + id);
        }
        await connection
            .getRepository(AlbumBaseEntity_1.AlbumBaseEntity)
            .delete({ id, locked: false });
    }
    async getAlbums() {
        await this.updateAlbums();
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        return await connection
            .getRepository(AlbumBaseEntity_1.AlbumBaseEntity)
            .createQueryBuilder('album')
            .leftJoin('album.cover', 'cover')
            .leftJoin('cover.directory', 'directory')
            .select(['album', 'cover.name', 'directory.name', 'directory.path'])
            .getMany();
    }
    async onNewDataVersion() {
        await this.resetCovers();
    }
    async resetCovers() {
        this.isDBValid = false;
    }
    async updateAlbums() {
        if (this.isDBValid === true) {
            return;
        }
        Logger_1.Logger.debug(LOG_TAG, 'Updating derived album data');
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        const albums = await connection.getRepository(AlbumBaseEntity_1.AlbumBaseEntity).find();
        for (const a of albums) {
            await AlbumManager.updateAlbum(a);
            // giving back the control to the main event loop (Macrotask queue)
            // https://blog.insiderattack.net/promises-next-ticks-and-immediates-nodejs-event-loop-part-3-9226cbe7a6aa
            await new Promise(setImmediate);
        }
        this.isDBValid = true;
    }
    async deleteAll() {
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        await connection
            .getRepository(AlbumBaseEntity_1.AlbumBaseEntity)
            .createQueryBuilder('album')
            .delete()
            .execute();
    }
}
exports.AlbumManager = AlbumManager;
