"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IndexingManager = void 0;
const DirectoryDTO_1 = require("../../../common/entities/DirectoryDTO");
const DirectoryEntity_1 = require("./enitites/DirectoryEntity");
const SQLConnection_1 = require("./SQLConnection");
const DiskManger_1 = require("../DiskManger");
const PhotoEntity_1 = require("./enitites/PhotoEntity");
const Utils_1 = require("../../../common/Utils");
const MediaEntity_1 = require("./enitites/MediaEntity");
const MediaDTO_1 = require("../../../common/entities/MediaDTO");
const VideoEntity_1 = require("./enitites/VideoEntity");
const FileEntity_1 = require("./enitites/FileEntity");
const NotifocationManager_1 = require("../NotifocationManager");
const ObjectManagers_1 = require("../ObjectManagers");
const DiskMangerWorker_1 = require("../threading/DiskMangerWorker");
const Logger_1 = require("../../Logger");
const PG2ConfMap_1 = require("../../../common/PG2ConfMap");
const ProjectPath_1 = require("../../ProjectPath");
const path = require("path");
const fs = require("fs");
const PersonEntry_1 = require("./enitites/PersonEntry");
const PersonJunctionTable_1 = require("./enitites/PersonJunctionTable");
const MDFileEntity_1 = require("./enitites/MDFileEntity");
const LOG_TAG = '[IndexingManager]';
class IndexingManager {
    constructor() {
        this.SavingReady = null;
        this.SavingReadyPR = null;
        this.savingQueue = [];
        this.isSaving = false;
    }
    get IsSavingInProgress() {
        return this.SavingReady !== null;
    }
    static async processServerSidePG2Conf(parent, files) {
        for (const f of files) {
            if (PG2ConfMap_1.ServerPG2ConfMap[f.name] === PG2ConfMap_1.ServerSidePG2ConfAction.SAVED_SEARCH) {
                const fullMediaPath = path.join(ProjectPath_1.ProjectPath.ImageFolder, parent.path, parent.name, f.name);
                Logger_1.Logger.silly(LOG_TAG, 'Saving saved-searches to DB from:', fullMediaPath);
                const savedSearches = JSON.parse(await fs.promises.readFile(fullMediaPath, 'utf8'));
                for (const s of savedSearches) {
                    await ObjectManagers_1.ObjectManagers.getInstance().AlbumManager.addIfNotExistSavedSearch(s.name, s.searchQuery, true);
                }
            }
        }
    }
    /**
     * Indexes a dir, but returns early with the scanned version,
     * does not wait for the DB to be saved
     */
    indexDirectory(relativeDirectoryName) {
        // eslint-disable-next-line no-async-promise-executor
        return new Promise(async (resolve, reject) => {
            try {
                // Check if root is still a valid (non-empty) folder
                // With weak devices it is possible that the media that stores
                // the galley gets unmounted that triggers a full gallery wipe.
                // Prevent it by stopping indexing on an empty folder.
                if (fs.readdirSync(ProjectPath_1.ProjectPath.ImageFolder).length === 0) {
                    return reject(new Error('Root directory is empty. This is probably error and would erase gallery database. Stopping indexing.'));
                }
                const scannedDirectory = await DiskManger_1.DiskManager.scanDirectory(relativeDirectoryName);
                const dirClone = Utils_1.Utils.clone(scannedDirectory);
                // filter server side only config from returning
                dirClone.metaFile = dirClone.metaFile.filter((m) => !PG2ConfMap_1.ServerPG2ConfMap[m.name]);
                DirectoryDTO_1.DirectoryDTOUtils.addReferences(dirClone);
                resolve(dirClone);
                // save directory to DB
                this.queueForSave(scannedDirectory).catch(console.error);
            }
            catch (error) {
                NotifocationManager_1.NotificationManager.warning('Unknown indexing error for: ' + relativeDirectoryName, error.toString());
                console.error(error);
                return reject(error);
            }
        });
    }
    async resetDB() {
        Logger_1.Logger.info(LOG_TAG, 'Resetting DB');
        const connection = await SQLConnection_1.SQLConnection.getConnection();
        await connection
            .getRepository(DirectoryEntity_1.DirectoryEntity)
            .createQueryBuilder('directory')
            .delete()
            .execute();
    }
    async saveToDB(scannedDirectory) {
        this.isSaving = true;
        try {
            const connection = await SQLConnection_1.SQLConnection.getConnection();
            const serverSideConfigs = scannedDirectory.metaFile.filter((m) => !!PG2ConfMap_1.ServerPG2ConfMap[m.name]);
            scannedDirectory.metaFile = scannedDirectory.metaFile.filter((m) => !PG2ConfMap_1.ServerPG2ConfMap[m.name]);
            const currentDirId = await this.saveParentDir(connection, scannedDirectory);
            await this.saveChildDirs(connection, currentDirId, scannedDirectory);
            await this.saveMedia(connection, currentDirId, scannedDirectory.media);
            await this.saveMetaFiles(connection, currentDirId, scannedDirectory);
            await IndexingManager.processServerSidePG2Conf(scannedDirectory, serverSideConfigs);
            await ObjectManagers_1.ObjectManagers.getInstance().onDataChange(scannedDirectory);
        }
        finally {
            this.isSaving = false;
        }
    }
    // Todo fix it, once typeorm support connection pools for sqlite
    /**
     * Queues up a directory to save to the DB.
     */
    async queueForSave(scannedDirectory) {
        // Is this dir  already queued for saving?
        if (this.savingQueue.findIndex((dir) => dir.name === scannedDirectory.name &&
            dir.path === scannedDirectory.path &&
            dir.lastModified === scannedDirectory.lastModified &&
            dir.lastScanned === scannedDirectory.lastScanned &&
            (dir.media || dir.media.length) ===
                (scannedDirectory.media || scannedDirectory.media.length) &&
            (dir.metaFile || dir.metaFile.length) ===
                (scannedDirectory.metaFile || scannedDirectory.metaFile.length)) !== -1) {
            return;
        }
        this.savingQueue.push(scannedDirectory);
        if (!this.SavingReady) {
            this.SavingReady = new Promise((resolve) => {
                this.SavingReadyPR = resolve;
            });
        }
        try {
            while (this.isSaving === false && this.savingQueue.length > 0) {
                await this.saveToDB(this.savingQueue[0]);
                this.savingQueue.shift();
            }
        }
        catch (e) {
            this.savingQueue = [];
            throw e;
        }
        finally {
            if (this.savingQueue.length === 0) {
                this.SavingReady = null;
                this.SavingReadyPR();
            }
        }
    }
    async saveParentDir(connection, scannedDirectory) {
        const directoryRepository = connection.getRepository(DirectoryEntity_1.DirectoryEntity);
        const currentDir = await directoryRepository
            .createQueryBuilder('directory')
            .where('directory.name = :name AND directory.path = :path', {
            name: scannedDirectory.name,
            path: scannedDirectory.path,
        })
            .getOne();
        if (currentDir) {
            // Updated parent dir (if it was in the DB previously)
            currentDir.lastModified = scannedDirectory.lastModified;
            currentDir.lastScanned = scannedDirectory.lastScanned;
            currentDir.mediaCount = scannedDirectory.mediaCount;
            currentDir.youngestMedia = scannedDirectory.youngestMedia;
            currentDir.oldestMedia = scannedDirectory.oldestMedia;
            await directoryRepository.save(currentDir);
            return currentDir.id;
        }
        else {
            return (await directoryRepository.insert({
                mediaCount: scannedDirectory.mediaCount,
                lastModified: scannedDirectory.lastModified,
                lastScanned: scannedDirectory.lastScanned,
                youngestMedia: scannedDirectory.youngestMedia,
                oldestMedia: scannedDirectory.oldestMedia,
                name: scannedDirectory.name,
                path: scannedDirectory.path,
            })).identifiers[0]['id'];
        }
    }
    async saveChildDirs(connection, currentDirId, scannedDirectory) {
        const directoryRepository = connection.getRepository(DirectoryEntity_1.DirectoryEntity);
        // update subdirectories that does not have a parent
        await directoryRepository
            .createQueryBuilder()
            .update(DirectoryEntity_1.DirectoryEntity)
            .set({ parent: currentDirId })
            .where('path = :path', {
            path: DiskMangerWorker_1.DiskMangerWorker.pathFromParent(scannedDirectory),
        })
            .andWhere('name NOT LIKE :root', { root: DiskMangerWorker_1.DiskMangerWorker.dirName('.') })
            .andWhere('parent IS NULL')
            .execute();
        // save subdirectories
        const childDirectories = await directoryRepository
            .createQueryBuilder('directory')
            .leftJoinAndSelect('directory.parent', 'parent')
            .where('directory.parent = :dir', {
            dir: currentDirId,
        })
            .getMany();
        for (const directory of scannedDirectory.directories) {
            // Was this child Dir already indexed before?
            const dirIndex = childDirectories.findIndex((d) => d.name === directory.name);
            if (dirIndex !== -1) {
                // directory found
                childDirectories.splice(dirIndex, 1);
            }
            else {
                // dir does not exist yet
                directory.parent = { id: currentDirId };
                directory.lastScanned = null; // new child dir, not fully scanned yet
                const d = await directoryRepository.insert(directory);
                await this.saveMedia(connection, d.identifiers[0]['id'], directory.media);
            }
        }
        // Remove child Dirs that are not anymore in the parent dir
        await directoryRepository.remove(childDirectories, {
            chunk: Math.max(Math.ceil(childDirectories.length / 500), 1),
        });
    }
    async saveMetaFiles(connection, currentDirID, scannedDirectory) {
        const fileRepository = connection.getRepository(FileEntity_1.FileEntity);
        const MDfileRepository = connection.getRepository(MDFileEntity_1.MDFileEntity);
        // save files
        const indexedMetaFiles = await fileRepository
            .createQueryBuilder('file')
            .where('file.directory = :dir', {
            dir: currentDirID,
        })
            .getMany();
        const metaFilesToInsert = [];
        const MDFilesToUpdate = [];
        for (const item of scannedDirectory.metaFile) {
            let metaFile = null;
            for (let j = 0; j < indexedMetaFiles.length; j++) {
                if (indexedMetaFiles[j].name === item.name) {
                    metaFile = indexedMetaFiles[j];
                    indexedMetaFiles.splice(j, 1);
                    break;
                }
            }
            if (metaFile == null) {
                // not in DB yet
                item.directory = null;
                metaFile = Utils_1.Utils.clone(item);
                item.directory = scannedDirectory;
                metaFile.directory = { id: currentDirID };
                metaFilesToInsert.push(metaFile);
            }
            else if (item.date) {
                if (item.date != metaFile.date) {
                    metaFile.date = item.date;
                    MDFilesToUpdate.push(metaFile);
                }
            }
        }
        const MDFiles = metaFilesToInsert.filter(f => !isNaN(f.date));
        const generalFiles = metaFilesToInsert.filter(f => isNaN(f.date));
        await fileRepository.save(generalFiles, {
            chunk: Math.max(Math.ceil(generalFiles.length / 500), 1),
        });
        await MDfileRepository.save(MDFiles, {
            chunk: Math.max(Math.ceil(MDFiles.length / 500), 1),
        });
        await MDfileRepository.save(MDFilesToUpdate, {
            chunk: Math.max(Math.ceil(MDFilesToUpdate.length / 500), 1),
        });
        await fileRepository.remove(indexedMetaFiles, {
            chunk: Math.max(Math.ceil(indexedMetaFiles.length / 500), 1),
        });
    }
    async saveMedia(connection, parentDirId, media) {
        const mediaRepository = connection.getRepository(MediaEntity_1.MediaEntity);
        const photoRepository = connection.getRepository(PhotoEntity_1.PhotoEntity);
        const videoRepository = connection.getRepository(VideoEntity_1.VideoEntity);
        // save media
        let indexedMedia = await mediaRepository
            .createQueryBuilder('media')
            .where('media.directory = :dir', {
            dir: parentDirId,
        })
            .getMany();
        const mediaChange = {
            saveP: [],
            saveV: [],
            insertP: [],
            insertV: [], // insert video
        };
        const personsPerPhoto = [];
        // eslint-disable-next-line @typescript-eslint/prefer-for-of
        for (let i = 0; i < media.length; i++) {
            let mediaItem = null;
            for (let j = 0; j < indexedMedia.length; j++) {
                if (indexedMedia[j].name === media[i].name) {
                    mediaItem = indexedMedia[j];
                    indexedMedia.splice(j, 1);
                    break;
                }
            }
            const scannedFaces = media[i].metadata.faces || [];
            if (media[i].metadata.faces) {
                // if it has faces, cache them
                // make the list distinct (some photos may contain the same person multiple times)
                media[i].metadata.persons = [
                    ...new Set(media[i].metadata.faces.map((f) => f.name)),
                ];
            }
            media[i].metadata.personsLength = media[i].metadata?.persons?.length || 0;
            if (mediaItem == null) {
                // Media not in DB yet
                media[i].directory = null;
                mediaItem = Utils_1.Utils.clone(media[i]);
                mediaItem.directory = { id: parentDirId };
                (MediaDTO_1.MediaDTOUtils.isPhoto(mediaItem)
                    ? mediaChange.insertP
                    : mediaChange.insertV).push(mediaItem);
            }
            else {
                // Media already in the DB, only needs to be updated
                delete mediaItem.metadata.faces;
                if (!Utils_1.Utils.equalsFilter(mediaItem.metadata, media[i].metadata)) {
                    mediaItem.metadata = media[i].metadata;
                    (MediaDTO_1.MediaDTOUtils.isPhoto(mediaItem)
                        ? mediaChange.saveP
                        : mediaChange.saveV).push(mediaItem);
                }
            }
            personsPerPhoto.push({
                faces: scannedFaces,
                mediaName: mediaItem.name
            });
        }
        await this.saveChunk(photoRepository, mediaChange.saveP, 100);
        await this.saveChunk(videoRepository, mediaChange.saveV, 100);
        await this.saveChunk(photoRepository, mediaChange.insertP, 100);
        await this.saveChunk(videoRepository, mediaChange.insertV, 100);
        indexedMedia = await mediaRepository
            .createQueryBuilder('media')
            .where('media.directory = :dir', {
            dir: parentDirId,
        })
            .select(['media.name', 'media.id'])
            .getMany();
        const persons = [];
        personsPerPhoto.forEach((group) => {
            const mIndex = indexedMedia.findIndex((m) => m.name === group.mediaName);
            group.faces.forEach((sf) => (sf.mediaId = indexedMedia[mIndex].id));
            persons.push(...group.faces);
            indexedMedia.splice(mIndex, 1);
        });
        await this.savePersonsToMedia(connection, parentDirId, persons);
        await mediaRepository.remove(indexedMedia);
    }
    async savePersonsToMedia(connection, parentDirId, scannedFaces) {
        const personJunctionTable = connection.getRepository(PersonJunctionTable_1.PersonJunctionTable);
        const personRepository = connection.getRepository(PersonEntry_1.PersonEntry);
        const persons = [];
        // Make a set
        for (const face of scannedFaces) {
            if (persons.findIndex((f) => f.name === face.name) === -1) {
                persons.push(face);
            }
        }
        await ObjectManagers_1.ObjectManagers.getInstance().PersonManager.saveAll(persons);
        // get saved persons without triggering denormalized data update (i.e.: do not use PersonManager.get).
        const savedPersons = await personRepository.find();
        const indexedFaces = await personJunctionTable
            .createQueryBuilder('face')
            .leftJoin('face.media', 'media')
            .where('media.directory = :directory', {
            directory: parentDirId,
        })
            .leftJoinAndSelect('face.person', 'person')
            .getMany();
        const faceToInsert = [];
        // eslint-disable-next-line @typescript-eslint/prefer-for-of
        for (let i = 0; i < scannedFaces.length; i++) {
            // was the Person - media connection already indexed
            let face = null;
            for (let j = 0; j < indexedFaces.length; j++) {
                if (indexedFaces[j].person.name === scannedFaces[i].name) {
                    face = indexedFaces[j];
                    indexedFaces.splice(j, 1);
                    break; // region found, stop processing
                }
            }
            if (face == null) {
                faceToInsert.push({
                    person: savedPersons.find((p) => p.name === scannedFaces[i].name),
                    media: { id: scannedFaces[i].mediaId }
                });
            }
        }
        if (faceToInsert.length > 0) {
            await this.insertChunk(personJunctionTable, faceToInsert, 100);
        }
        await personJunctionTable.remove(indexedFaces, {
            chunk: Math.max(Math.ceil(indexedFaces.length / 500), 1),
        });
    }
    async saveChunk(repository, entities, size) {
        if (entities.length === 0) {
            return [];
        }
        if (entities.length < size) {
            return await repository.save(entities);
        }
        let list = [];
        for (let i = 0; i < entities.length / size; i++) {
            list = list.concat(await repository.save(entities.slice(i * size, (i + 1) * size)));
        }
        return list;
    }
    async insertChunk(repository, entities, size) {
        if (entities.length === 0) {
            return [];
        }
        if (entities.length < size) {
            return (await repository.insert(entities)).identifiers.map((i) => i.id);
        }
        let list = [];
        for (let i = 0; i < entities.length / size; i++) {
            list = list.concat((await repository.insert(entities.slice(i * size, (i + 1) * size))).identifiers.map((ids) => ids['id']));
        }
        return list;
    }
}
exports.IndexingManager = IndexingManager;
