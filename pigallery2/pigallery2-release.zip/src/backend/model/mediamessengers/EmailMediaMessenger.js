"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmailMediaMessenger = void 0;
const nodemailer_1 = require("nodemailer");
const MediaDTO_1 = require("../../../common/entities/MediaDTO");
const Config_1 = require("../../../common/config/private/Config");
const PhotoProcessing_1 = require("../fileprocessing/PhotoProcessing");
const PhotoWorker_1 = require("../threading/PhotoWorker");
const ProjectPath_1 = require("../../ProjectPath");
const path = require("path");
const Utils_1 = require("../../../common/Utils");
const QueryParams_1 = require("../../../common/QueryParams");
class EmailMediaMessenger {
    constructor() {
        this.transporter = (0, nodemailer_1.createTransport)({
            host: Config_1.Config.Messaging.Email.smtp.host,
            port: Config_1.Config.Messaging.Email.smtp.port,
            secure: Config_1.Config.Messaging.Email.smtp.secure,
            requireTLS: Config_1.Config.Messaging.Email.smtp.requireTLS,
            auth: {
                user: Config_1.Config.Messaging.Email.smtp.user,
                pass: Config_1.Config.Messaging.Email.smtp.password
            }
        });
    }
    async getThumbnail(m) {
        return await PhotoProcessing_1.PhotoProcessing.generateThumbnail(path.join(ProjectPath_1.ProjectPath.ImageFolder, m.directory.path, m.directory.name, m.name), Config_1.Config.Media.Thumbnail.thumbnailSizes[0], MediaDTO_1.MediaDTOUtils.isPhoto(m) ? PhotoWorker_1.ThumbnailSourceType.Photo : PhotoWorker_1.ThumbnailSourceType.Video, false);
    }
    async sendMedia(mailSettings, media) {
        const attachments = [];
        const htmlStart = '<h1 style="text-align: center; margin-bottom: 2em">' + Config_1.Config.Server.applicationTitle + '</h1>\n' +
            '<h3>' + mailSettings.text + '</h3>\n' +
            '<table style="margin-left: auto;  margin-right: auto;">\n' +
            '  <tbody>\n';
        const htmlEnd = '  </tr>\n' +
            '  </tbody>\n' +
            '</table>';
        let htmlMiddle = '';
        const numberOfColumns = media.length >= 6 ? 3 : 2;
        for (let i = 0; i < media.length; ++i) {
            const thPath = await this.getThumbnail(media[i]);
            const linkUrl = Utils_1.Utils.concatUrls(Config_1.Config.Server.publicUrl, '/gallery/', encodeURIComponent(path.join(media[i].directory.path, media[i].directory.name))) +
                '?' + QueryParams_1.QueryParams.gallery.photo + '=' + encodeURIComponent(media[i].name);
            const location = media[i].metadata.positionData?.country ?
                media[i].metadata.positionData?.country :
                (media[i].metadata.positionData?.city ?
                    media[i].metadata.positionData?.city : '');
            const caption = (new Date(media[i].metadata.creationDate)).getFullYear() + (location ? ', ' + location : '');
            attachments.push({
                filename: media[i].name,
                path: thPath,
                cid: 'img' + i
            });
            if (i % numberOfColumns == 0) {
                htmlMiddle += '<tr>';
            }
            htmlMiddle += '<td>\n' +
                '      <a style="display: block;text-align: center;" href="' + linkUrl + '"><img alt="' + media[i].name + '" style="max-width: 200px; max-height: 150px;  height:auto; width:auto;" src="cid:img' + i + '"/></a>\n' +
                caption +
                '    </td>\n';
            if (i % numberOfColumns == (numberOfColumns - 1) || i === media.length - 1) {
                htmlMiddle += '</tr>';
            }
        }
        return await this.transporter.sendMail({
            from: Config_1.Config.Messaging.Email.emailFrom,
            to: mailSettings.to,
            subject: mailSettings.subject,
            html: htmlStart + htmlMiddle + htmlEnd,
            attachments: attachments
        });
    }
}
exports.EmailMediaMessenger = EmailMediaMessenger;
