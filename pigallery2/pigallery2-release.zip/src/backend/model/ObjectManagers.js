"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ObjectManagers = void 0;
/* eslint-disable @typescript-eslint/no-var-requires */
const SQLConnection_1 = require("./database/SQLConnection");
const Logger_1 = require("../Logger");
const LocationManager_1 = require("./database/LocationManager");
const JobManager_1 = require("./jobs/JobManager");
const GalleryManager_1 = require("./database/GalleryManager");
const UserManager_1 = require("./database/UserManager");
const IndexingManager_1 = require("./database/IndexingManager");
const SearchManager_1 = require("./database/SearchManager");
const VersionManager_1 = require("./database/VersionManager");
const CoverManager_1 = require("./database/CoverManager");
const AlbumManager_1 = require("./database/AlbumManager");
const PersonManager_1 = require("./database/PersonManager");
const SharingManager_1 = require("./database/SharingManager");
const LOG_TAG = '[ObjectManagers]';
class ObjectManagers {
    constructor() {
        this.managers = [];
    }
    static { this.instance = null; }
    get VersionManager() {
        return this.versionManager;
    }
    set VersionManager(value) {
        if (this.versionManager) {
            this.managers.splice(this.managers.indexOf(this.versionManager), 1);
        }
        this.versionManager = value;
        this.managers.push(this.versionManager);
    }
    get LocationManager() {
        return this.locationManager;
    }
    set LocationManager(value) {
        if (this.locationManager) {
            this.managers.splice(this.managers.indexOf(this.locationManager), 1);
        }
        this.locationManager = value;
        this.managers.push(this.locationManager);
    }
    get AlbumManager() {
        return this.albumManager;
    }
    set AlbumManager(value) {
        if (this.albumManager) {
            this.managers.splice(this.managers.indexOf(this.albumManager), 1);
        }
        this.albumManager = value;
        this.managers.push(this.albumManager);
    }
    get PersonManager() {
        return this.personManager;
    }
    set PersonManager(value) {
        if (this.personManager) {
            this.managers.splice(this.managers.indexOf(this.personManager), 1);
        }
        this.personManager = value;
        this.managers.push(this.personManager);
    }
    get CoverManager() {
        return this.coverManager;
    }
    set CoverManager(value) {
        if (this.coverManager) {
            this.managers.splice(this.managers.indexOf(this.coverManager), 1);
        }
        this.coverManager = value;
        this.managers.push(this.coverManager);
    }
    get IndexingManager() {
        return this.indexingManager;
    }
    set IndexingManager(value) {
        if (this.indexingManager) {
            this.managers.splice(this.managers.indexOf(this.indexingManager), 1);
        }
        this.indexingManager = value;
        this.managers.push(this.indexingManager);
    }
    get GalleryManager() {
        return this.galleryManager;
    }
    set GalleryManager(value) {
        if (this.galleryManager) {
            this.managers.splice(this.managers.indexOf(this.galleryManager), 1);
        }
        this.galleryManager = value;
        this.managers.push(this.galleryManager);
    }
    get UserManager() {
        return this.userManager;
    }
    set UserManager(value) {
        if (this.userManager) {
            this.managers.splice(this.managers.indexOf(this.userManager), 1);
        }
        this.userManager = value;
        this.managers.push(this.userManager);
    }
    get SearchManager() {
        return this.searchManager;
    }
    set SearchManager(value) {
        if (this.searchManager) {
            this.managers.splice(this.managers.indexOf(this.searchManager), 1);
        }
        this.searchManager = value;
        this.managers.push(this.searchManager);
    }
    get SharingManager() {
        return this.sharingManager;
    }
    set SharingManager(value) {
        if (this.sharingManager) {
            this.managers.splice(this.managers.indexOf(this.sharingManager), 1);
        }
        this.sharingManager = value;
        this.managers.push(this.sharingManager);
    }
    get JobManager() {
        return this.jobManager;
    }
    set JobManager(value) {
        if (this.jobManager) {
            this.managers.splice(this.managers.indexOf(this.jobManager), 1);
        }
        this.jobManager = value;
        this.managers.push(this.jobManager);
    }
    static getInstance() {
        if (this.instance === null) {
            this.instance = new ObjectManagers();
        }
        return this.instance;
    }
    static async reset() {
        Logger_1.Logger.silly(LOG_TAG, 'Object manager reset begin');
        if (ObjectManagers.getInstance().IndexingManager &&
            ObjectManagers.getInstance().IndexingManager.IsSavingInProgress) {
            await ObjectManagers.getInstance().IndexingManager.SavingReady;
        }
        if (ObjectManagers.getInstance().JobManager) {
            ObjectManagers.getInstance().JobManager.stopSchedules();
        }
        await SQLConnection_1.SQLConnection.close();
        this.instance = null;
        Logger_1.Logger.debug(LOG_TAG, 'Object manager reset');
    }
    static async InitSQLManagers() {
        await ObjectManagers.reset();
        await SQLConnection_1.SQLConnection.init();
        this.initManagers();
        Logger_1.Logger.debug(LOG_TAG, 'SQL DB inited');
    }
    static initManagers() {
        ObjectManagers.getInstance().AlbumManager = new AlbumManager_1.AlbumManager();
        ObjectManagers.getInstance().GalleryManager = new GalleryManager_1.GalleryManager();
        ObjectManagers.getInstance().IndexingManager = new IndexingManager_1.IndexingManager();
        ObjectManagers.getInstance().PersonManager = new PersonManager_1.PersonManager();
        ObjectManagers.getInstance().CoverManager = new CoverManager_1.CoverManager();
        ObjectManagers.getInstance().SearchManager = new SearchManager_1.SearchManager();
        ObjectManagers.getInstance().SharingManager = new SharingManager_1.SharingManager();
        ObjectManagers.getInstance().UserManager = new UserManager_1.UserManager();
        ObjectManagers.getInstance().VersionManager = new VersionManager_1.VersionManager();
        ObjectManagers.getInstance().JobManager = new JobManager_1.JobManager();
        ObjectManagers.getInstance().LocationManager = new LocationManager_1.LocationManager();
    }
    async onDataChange(changedDir = null) {
        await this.VersionManager.onNewDataVersion();
        for (const manager of this.managers) {
            if (manager === this.versionManager) {
                continue;
            }
            if (manager.onNewDataVersion) {
                await manager.onNewDataVersion(changedDir);
            }
        }
    }
}
exports.ObjectManagers = ObjectManagers;
