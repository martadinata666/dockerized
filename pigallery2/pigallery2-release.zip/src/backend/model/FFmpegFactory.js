"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FFmpegFactory = void 0;
/* eslint-disable @typescript-eslint/no-var-requires */
class FFmpegFactory {
    static get() {
        const ffmpeg = require('fluent-ffmpeg');
        try {
            const ffmpegPath = require('ffmpeg-static');
            ffmpeg.setFfmpegPath(ffmpegPath);
            const ffprobePath = require('ffprobe-static');
            ffmpeg.setFfprobePath(ffprobePath.path);
        }
        catch (e) {
            // ignoring errors
        }
        return ffmpeg;
    }
}
exports.FFmpegFactory = FFmpegFactory;
