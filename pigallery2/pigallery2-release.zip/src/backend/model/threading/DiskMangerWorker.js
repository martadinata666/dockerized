"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DiskMangerWorker = void 0;
const fs_1 = require("fs");
const path = require("path");
const ProjectPath_1 = require("../../ProjectPath");
const Config_1 = require("../../../common/config/private/Config");
const MetadataLoader_1 = require("./MetadataLoader");
const Logger_1 = require("../../Logger");
const VideoProcessing_1 = require("../fileprocessing/VideoProcessing");
const PhotoProcessing_1 = require("../fileprocessing/PhotoProcessing");
const Utils_1 = require("../../../common/Utils");
const GPXProcessing_1 = require("../fileprocessing/GPXProcessing");
class DiskMangerWorker {
    static calcLastModified(stat) {
        return Math.max(stat.ctime.getTime(), stat.mtime.getTime());
    }
    static normalizeDirPath(dirPath) {
        return path.normalize(path.join('.' + path.sep, dirPath));
    }
    static pathFromRelativeDirName(relativeDirectoryName) {
        return path.join(path.dirname(this.normalizeDirPath(relativeDirectoryName)), path.sep);
    }
    static pathFromParent(parent) {
        return path.join(this.normalizeDirPath(path.join(parent.path, parent.name)), path.sep);
    }
    static dirName(dirPath) {
        if (dirPath.trim().length === 0) {
            return '.';
        }
        return path.basename(dirPath);
    }
    static async excludeDir(name, relativeDirectoryName, absoluteDirectoryName) {
        if (Config_1.Config.Indexing.excludeFolderList.length === 0 &&
            Config_1.Config.Indexing.excludeFileList.length === 0) {
            return false;
        }
        const absoluteName = path.normalize(path.join(absoluteDirectoryName, name));
        const relativeName = path.normalize(path.join(relativeDirectoryName, name));
        for (const exclude of Config_1.Config.Indexing.excludeFolderList) {
            if (exclude.startsWith('/')) {
                if (exclude === absoluteName) {
                    return true;
                }
            }
            else if (exclude.includes('/')) {
                if (path.normalize(exclude) === relativeName) {
                    return true;
                }
            }
            else {
                if (exclude === name) {
                    return true;
                }
            }
        }
        // exclude dirs that have the given files (like .ignore)
        for (const exclude of Config_1.Config.Indexing.excludeFileList) {
            try {
                await fs_1.promises.access(path.join(absoluteName, exclude));
                return true;
            }
            catch (e) {
                // ignoring errors
            }
        }
        return false;
    }
    static async scanDirectoryNoMetadata(relativeDirectoryName, settings = {}) {
        settings.noMetadata = true;
        return (await this.scanDirectory(relativeDirectoryName, settings));
    }
    static async scanDirectory(relativeDirectoryName, settings = {}) {
        relativeDirectoryName = this.normalizeDirPath(relativeDirectoryName);
        const directoryName = DiskMangerWorker.dirName(relativeDirectoryName);
        const directoryParent = this.pathFromRelativeDirName(relativeDirectoryName);
        const absoluteDirectoryName = path.join(ProjectPath_1.ProjectPath.ImageFolder, relativeDirectoryName);
        const stat = await fs_1.promises.stat(path.join(ProjectPath_1.ProjectPath.ImageFolder, relativeDirectoryName));
        const directory = {
            id: null,
            parent: null,
            name: directoryName,
            path: directoryParent,
            lastModified: this.calcLastModified(stat),
            directories: [],
            isPartial: settings.coverOnly === true,
            mediaCount: 0,
            cover: null,
            validCover: false,
            media: [],
            metaFile: [],
        };
        if (!settings.coverOnly) {
            directory.lastScanned = Date.now();
        }
        // nothing to scan, we are here for the empty dir
        if (settings.noPhoto === true &&
            settings.noMetaFile === true &&
            settings.noVideo === true) {
            return directory;
        }
        const list = await fs_1.promises.readdir(absoluteDirectoryName);
        for (const file of list) {
            const fullFilePath = path.normalize(path.join(absoluteDirectoryName, file));
            if ((await fs_1.promises.stat(fullFilePath)).isDirectory()) {
                if (settings.noDirectory === true ||
                    settings.coverOnly === true ||
                    (await DiskMangerWorker.excludeDir(file, relativeDirectoryName, absoluteDirectoryName))) {
                    continue;
                }
                // create cover directory
                const d = (await DiskMangerWorker.scanDirectory(path.join(relativeDirectoryName, file), {
                    coverOnly: true,
                }));
                directory.directories.push(d);
            }
            else if (PhotoProcessing_1.PhotoProcessing.isPhoto(fullFilePath)) {
                if (settings.noPhoto === true) {
                    continue;
                }
                const photo = {
                    name: file,
                    directory: null,
                    metadata: settings.noMetadata === true
                        ? null
                        : await MetadataLoader_1.MetadataLoader.loadPhotoMetadata(fullFilePath),
                };
                if (!directory.cover) {
                    directory.cover = Utils_1.Utils.clone(photo);
                    directory.cover.directory = {
                        path: directory.path,
                        name: directory.name,
                    };
                }
                // add the cover photo to the list of media, so it will be saved to the DB
                // and can be queried to populate covers,
                // otherwise we do not return media list that is only partial
                directory.media.push(photo);
                if (settings.coverOnly === true) {
                    break;
                }
            }
            else if (VideoProcessing_1.VideoProcessing.isVideo(fullFilePath)) {
                if (Config_1.Config.Media.Video.enabled === false ||
                    settings.noVideo === true ||
                    settings.coverOnly === true) {
                    continue;
                }
                try {
                    directory.media.push({
                        name: file,
                        directory: null,
                        metadata: settings.noMetadata === true
                            ? null
                            : await MetadataLoader_1.MetadataLoader.loadVideoMetadata(fullFilePath),
                    });
                }
                catch (e) {
                    Logger_1.Logger.warn('Media loading error, skipping: ' +
                        file +
                        ', reason: ' +
                        e.toString());
                }
            }
            else if (GPXProcessing_1.GPXProcessing.isMetaFile(fullFilePath)) {
                if (!DiskMangerWorker.isEnabledMetaFile(fullFilePath) ||
                    settings.noMetaFile === true ||
                    settings.coverOnly === true) {
                    continue;
                }
                directory.metaFile.push({
                    name: file,
                    directory: null,
                });
            }
        }
        directory.mediaCount = directory.media.length;
        if (!directory.isPartial) {
            directory.youngestMedia = Number.MAX_SAFE_INTEGER;
            directory.oldestMedia = Number.MIN_SAFE_INTEGER;
            directory.media.forEach((m) => {
                directory.youngestMedia = Math.min(m.metadata.creationDate, directory.youngestMedia);
                directory.oldestMedia = Math.max(m.metadata.creationDate, directory.oldestMedia);
            });
            directory.metaFile.forEach(mf => {
                if (DiskMangerWorker.isMarkdown(mf.name)) {
                    mf.date = directory.youngestMedia;
                }
            });
        }
        return directory;
    }
    static isEnabledMetaFile(fullPath) {
        const extension = path.extname(fullPath).toLowerCase();
        switch (extension) {
            case '.gpx':
                return Config_1.Config.MetaFile.gpx;
            case '.md':
                return Config_1.Config.MetaFile.markdown;
            case '.pg2conf':
                return Config_1.Config.MetaFile.pg2conf;
        }
        return false;
    }
    static isMarkdown(fullPath) {
        const extension = path.extname(fullPath).toLowerCase();
        return extension == '.md';
    }
}
exports.DiskMangerWorker = DiskMangerWorker;
