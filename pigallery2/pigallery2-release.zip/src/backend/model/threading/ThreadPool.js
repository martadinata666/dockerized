"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DiskManagerTH = exports.ThreadPool = void 0;
const cluster = require("cluster");
const Logger_1 = require("../../Logger");
const Worker_1 = require("./Worker");
const TaskQue_1 = require("./TaskQue");
const LOG_TAG = '[ThreadPool]';
class ThreadPool {
    constructor(size) {
        this.size = size;
        this.workers = [];
        this.taskQue = new TaskQue_1.TaskQue();
        this.run = () => {
            if (this.taskQue.isEmpty()) {
                return;
            }
            const worker = this.getFreeWorker();
            if (worker == null) {
                return;
            }
            const poolTask = this.taskQue.get();
            worker.poolTask = poolTask;
            worker.worker.send(poolTask.data);
        };
        Logger_1.Logger.silly(LOG_TAG, 'Creating thread pool with', size, 'workers');
        for (let i = 0; i < size; i++) {
            this.startWorker();
        }
    }
    static { this.WorkerCount = 0; }
    executeTask(task) {
        const promise = this.taskQue.add(task).promise.obj;
        this.run();
        return promise;
    }
    getFreeWorker() {
        for (const worker of this.workers) {
            if (worker.poolTask == null) {
                return worker;
            }
        }
        return null;
    }
    startWorker() {
        const worker = {
            poolTask: null,
            worker: cluster.fork(),
        };
        this.workers.push(worker);
        worker.worker.on('online', () => {
            ThreadPool.WorkerCount++;
            Logger_1.Logger.debug(LOG_TAG, 'Worker ' + worker.worker.process.pid + ' is online, worker count:', ThreadPool.WorkerCount);
        });
        worker.worker.on('exit', (code, signal) => {
            ThreadPool.WorkerCount--;
            Logger_1.Logger.warn(LOG_TAG, 'Worker ' +
                worker.worker.process.pid +
                ' died with code: ' +
                code +
                ', and signal: ' +
                signal +
                ', worker count:', ThreadPool.WorkerCount);
            Logger_1.Logger.debug(LOG_TAG, 'Starting a new worker');
            this.startWorker();
        });
        worker.worker.on('message', (msg) => {
            if (worker.poolTask == null) {
                throw new Error('No worker task after worker task is completed');
            }
            if (msg.error) {
                worker.poolTask.promise.reject(msg.error);
            }
            else {
                worker.poolTask.promise.resolve(msg.result);
            }
            this.taskQue.ready(worker.poolTask);
            worker.poolTask = null;
            this.run();
        });
    }
}
exports.ThreadPool = ThreadPool;
class DiskManagerTH extends ThreadPool {
    execute(relativeDirectoryName, settings = {}) {
        return super.executeTask({
            type: Worker_1.WorkerTaskTypes.diskManager,
            relativeDirectoryName,
            settings,
        });
    }
}
exports.DiskManagerTH = DiskManagerTH;
