"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImageRendererFactory = exports.VideoRendererFactory = exports.ThumbnailSourceType = exports.PhotoWorker = void 0;
/* eslint-disable @typescript-eslint/no-var-requires */
const sharp = require("sharp");
const Logger_1 = require("../../Logger");
const FFmpegFactory_1 = require("../FFmpegFactory");
const path = require("path");
sharp.cache(false);
class PhotoWorker {
    static { this.videoRenderer = null; }
    static render(input) {
        if (input.type === ThumbnailSourceType.Photo) {
            return this.renderFromImage(input);
        }
        if (input.type === ThumbnailSourceType.Video) {
            return this.renderFromVideo(input);
        }
        throw new Error('Unsupported media type to render thumbnail:' + input.type);
    }
    static renderFromImage(input) {
        return ImageRendererFactory.render(input);
    }
    static renderFromVideo(input) {
        if (PhotoWorker.videoRenderer === null) {
            PhotoWorker.videoRenderer = VideoRendererFactory.build();
        }
        return PhotoWorker.videoRenderer(input);
    }
}
exports.PhotoWorker = PhotoWorker;
var ThumbnailSourceType;
(function (ThumbnailSourceType) {
    ThumbnailSourceType[ThumbnailSourceType["Photo"] = 1] = "Photo";
    ThumbnailSourceType[ThumbnailSourceType["Video"] = 2] = "Video";
})(ThumbnailSourceType = exports.ThumbnailSourceType || (exports.ThumbnailSourceType = {}));
class VideoRendererFactory {
    static build() {
        const ffmpeg = FFmpegFactory_1.FFmpegFactory.get();
        return (input) => {
            return new Promise((resolve, reject) => {
                Logger_1.Logger.silly('[FFmpeg] rendering thumbnail: ' + input.mediaPath);
                ffmpeg(input.mediaPath).ffprobe((err, data) => {
                    if (!!err || data === null) {
                        return reject('[FFmpeg] ' + err.toString());
                    }
                    let width = null;
                    let height = null;
                    for (const stream of data.streams) {
                        if (stream.width) {
                            width = stream.width;
                            height = stream.height;
                            break;
                        }
                    }
                    if (!width || !height) {
                        return reject('[FFmpeg] Can not read video dimension');
                    }
                    const command = ffmpeg(input.mediaPath);
                    const fileName = path.basename(input.outPath);
                    const folder = path.dirname(input.outPath);
                    let executedCmd = '';
                    command
                        .on('start', (cmd) => {
                        executedCmd = cmd;
                    })
                        .on('end', () => {
                        resolve();
                    })
                        .on('error', (e) => {
                        reject('[FFmpeg] ' + e.toString() + ' executed: ' + executedCmd);
                    })
                        .outputOptions(['-qscale:v 4']);
                    if (input.makeSquare === false) {
                        const newSize = width < height
                            ? Math.min(input.size, width) + 'x?'
                            : '?x' + Math.min(input.size, height);
                        command.takeScreenshots({
                            timemarks: ['10%'],
                            size: newSize,
                            filename: fileName,
                            folder,
                        });
                    }
                    else {
                        command.takeScreenshots({
                            timemarks: ['10%'],
                            size: input.size + 'x' + input.size,
                            filename: fileName,
                            folder,
                        });
                    }
                });
            });
        };
    }
}
exports.VideoRendererFactory = VideoRendererFactory;
class ImageRendererFactory {
    static async render(input) {
        let image;
        if (input.mediaPath) {
            Logger_1.Logger.silly('[SharpRenderer] rendering photo:' +
                input.mediaPath +
                ', size:' +
                input.size);
            image = sharp(input.mediaPath, { failOnError: false });
        }
        else {
            const svg_buffer = Buffer.from(input.svgString);
            image = sharp(svg_buffer, { density: 450 });
        }
        image.rotate();
        const metadata = await image.metadata();
        const kernel = input.useLanczos3 === true
            ? sharp.kernel.lanczos3
            : sharp.kernel.nearest;
        if (input.cut) {
            image.extract(input.cut);
        }
        if (input.makeSquare === false) {
            if (metadata.height > metadata.width) {
                image.resize(Math.min(input.size, metadata.width), null, {
                    kernel,
                });
            }
            else {
                image.resize(null, Math.min(input.size, metadata.height), {
                    kernel,
                });
            }
        }
        else {
            image.resize(input.size, input.size, {
                kernel,
                position: sharp.gravity.centre,
                fit: 'cover',
            });
        }
        if (input.mediaPath) {
            await image.webp({
                effort: 6,
                quality: input.quality,
                smartSubsample: input.smartSubsample
            }).toFile(input.outPath);
        }
        else {
            if (input.svgString) {
                await image.png({ effort: 6, quality: input.quality }).toFile(input.outPath);
            }
        }
    }
}
exports.ImageRendererFactory = ImageRendererFactory;
