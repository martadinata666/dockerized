"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TaskExecuter = void 0;
const TaskQue_1 = require("./TaskQue");
const EventLoopHandler_1 = require("../EventLoopHandler");
class TaskExecuter {
    constructor(size, worker) {
        this.size = size;
        this.worker = worker;
        this.taskQue = new TaskQue_1.TaskQue();
        this.taskInProgress = 0;
        this.el = new EventLoopHandler_1.EventLoopHandler();
        this.run = async () => {
            if (this.taskQue.isEmpty() || this.taskInProgress >= this.size) {
                return;
            }
            this.taskInProgress++;
            const task = this.taskQue.get();
            try {
                task.promise.resolve(await this.worker(task.data));
            }
            catch (err) {
                task.promise.reject(err);
            }
            this.taskQue.ready(task);
            this.taskInProgress--;
            this.el.step(this.run);
        };
    }
    execute(input) {
        const promise = this.taskQue.add(input).promise.obj;
        this.run().catch(console.error);
        return promise;
    }
}
exports.TaskExecuter = TaskExecuter;
