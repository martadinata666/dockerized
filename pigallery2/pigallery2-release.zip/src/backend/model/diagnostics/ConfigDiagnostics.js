"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigDiagnostics = void 0;
const Config_1 = require("../../../common/config/private/Config");
const Logger_1 = require("../../Logger");
const NotifocationManager_1 = require("../NotifocationManager");
const SQLConnection_1 = require("../database/SQLConnection");
const fs = require("fs");
const FFmpegFactory_1 = require("../FFmpegFactory");
const ClientConfig_1 = require("../../../common/config/public/ClientConfig");
const PrivateConfig_1 = require("../../../common/config/private/PrivateConfig");
const SearchQueryParser_1 = require("../../../common/SearchQueryParser");
const SearchQueryDTO_1 = require("../../../common/entities/SearchQueryDTO");
const Utils_1 = require("../../../common/Utils");
const LOG_TAG = '[ConfigDiagnostics]';
class ConfigDiagnostics {
    static testAlbumsConfig(
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    albumConfig, 
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    original) {
        Logger_1.Logger.debug(LOG_TAG, 'Testing album config');
        // nothing to check
    }
    static checkReadWritePermission(path) {
        return new Promise((resolve, reject) => {
            // eslint-disable-next-line no-bitwise
            fs.access(path, fs.constants.R_OK | fs.constants.W_OK, (err) => {
                if (err) {
                    return reject(err);
                }
                return resolve();
            });
        });
    }
    static async testDatabase(databaseConfig) {
        Logger_1.Logger.debug(LOG_TAG, 'Testing database config');
        await SQLConnection_1.SQLConnection.tryConnection(databaseConfig);
        if (databaseConfig.type === PrivateConfig_1.DatabaseType.sqlite) {
            try {
                await this.checkReadWritePermission(SQLConnection_1.SQLConnection.getSQLiteDB(databaseConfig));
            }
            catch (e) {
                throw new Error('Cannot read or write sqlite storage file: ' +
                    SQLConnection_1.SQLConnection.getSQLiteDB(databaseConfig));
            }
        }
    }
    static async testMetaFileConfig(metaFileConfig, config) {
        Logger_1.Logger.debug(LOG_TAG, 'Testing meta file config');
        if (metaFileConfig.gpx === true && config.Map.enabled === false) {
            throw new Error('*.gpx meta files are not supported without MAP');
        }
    }
    static testVideoConfig(videoConfig, config) {
        Logger_1.Logger.debug(LOG_TAG, 'Testing video config with ffmpeg test');
        return new Promise((resolve, reject) => {
            try {
                if (config.Media.Video.enabled === true) {
                    if (videoConfig.transcoding.fps <= 0) {
                        throw new Error('fps should be grater than 0');
                    }
                }
                if (videoConfig.enabled === true) {
                    const ffmpeg = FFmpegFactory_1.FFmpegFactory.get();
                    ffmpeg().getAvailableCodecs((err) => {
                        if (err) {
                            return reject(new Error('Error accessing ffmpeg, cant find executable: ' +
                                err.toString()));
                        }
                        ffmpeg(__dirname + '/blank.jpg').ffprobe((err2) => {
                            if (err2) {
                                return reject(new Error('Error accessing ffmpeg-probe, cant find executable: ' +
                                    err2.toString()));
                            }
                            return resolve();
                        });
                    });
                }
                else {
                    return resolve();
                }
            }
            catch (e) {
                return reject(new Error('unknown video error: ' + e.toString()));
            }
        });
    }
    static async testSharp() {
        Logger_1.Logger.debug(LOG_TAG, 'Testing sharp package');
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        const sharp = require('sharp');
        sharp();
    }
    static async testTempFolder(folder) {
        Logger_1.Logger.debug(LOG_TAG, 'Testing temp folder');
        await this.checkReadWritePermission(folder);
    }
    static testImageFolder(folder) {
        Logger_1.Logger.debug(LOG_TAG, 'Testing images folder');
        return new Promise((resolve, reject) => {
            if (!fs.existsSync(folder)) {
                reject('Images folder not exists: \'' + folder + '\'');
            }
            fs.access(folder, fs.constants.R_OK, (err) => {
                if (err) {
                    reject({
                        message: 'Error during getting read access to images folder',
                        error: err.toString(),
                    });
                }
            });
            resolve();
        });
    }
    static async testThumbnailConfig(thumbnailConfig) {
        Logger_1.Logger.debug(LOG_TAG, 'Testing thumbnail config');
        if (thumbnailConfig.personFaceMargin < 0 || thumbnailConfig.personFaceMargin > 1) {
            throw new Error('personFaceMargin should be between 0 and 1');
        }
        if (isNaN(thumbnailConfig.iconSize) || thumbnailConfig.iconSize <= 0) {
            throw new Error('IconSize has to be >= 0 integer, got: ' + thumbnailConfig.iconSize);
        }
        if (!thumbnailConfig.thumbnailSizes.length) {
            throw new Error('At least one thumbnail size is needed');
        }
        for (const item of thumbnailConfig.thumbnailSizes) {
            if (isNaN(item) || item <= 0) {
                throw new Error('Thumbnail size has to be >= 0 integer, got: ' + item);
            }
        }
    }
    static async testTasksConfig(
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    task, 
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    config) {
        Logger_1.Logger.debug(LOG_TAG, 'Testing tasks config');
        return;
    }
    static async testFacesConfig(faces, config) {
        Logger_1.Logger.debug(LOG_TAG, 'Testing faces config');
        if (faces.enabled === true) {
            if (config.Search.enabled === false) {
                throw new Error('Faces support needs enabled search');
            }
        }
    }
    static async testSearchConfig(
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    search, 
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    config) {
        Logger_1.Logger.debug(LOG_TAG, 'Testing search config');
        //nothing to check
    }
    static async testSharingConfig(sharing, config) {
        Logger_1.Logger.debug(LOG_TAG, 'Testing sharing config');
        if (sharing.enabled === true &&
            config.Users.authenticationRequired === false) {
            throw new Error('In case of no authentication, sharing is not supported');
        }
    }
    static async testRandomPhotoConfig(
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    sharing, 
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    config) {
        Logger_1.Logger.debug(LOG_TAG, 'Testing random photo config');
        //nothing to check
    }
    static async testMapConfig(map) {
        Logger_1.Logger.debug(LOG_TAG, 'Testing map config');
        if (map.enabled === false) {
            return;
        }
        if (map.mapProvider === ClientConfig_1.MapProviders.Mapbox &&
            (!map.mapboxAccessToken || map.mapboxAccessToken.length === 0)) {
            throw new Error('Mapbox needs a valid api key.');
        }
        if (map.mapProvider === ClientConfig_1.MapProviders.Custom &&
            (!map.customLayers || map.customLayers.length === 0)) {
            throw new Error('Custom maps need at least one valid layer');
        }
        if (map.mapProvider === ClientConfig_1.MapProviders.Custom) {
            map.customLayers.forEach((l) => {
                if (!l.url || l.url.length === 0) {
                    throw new Error('Custom maps url need to be a valid layer');
                }
            });
        }
    }
    static async testAlbumCoverConfig(settings) {
        Logger_1.Logger.debug(LOG_TAG, 'Testing cover config');
        const sp = new SearchQueryParser_1.SearchQueryParser();
        if (!Utils_1.Utils.equalsFilter(sp.parse(sp.stringify(settings.SearchQuery)), settings.SearchQuery)) {
            throw new Error('SearchQuery is not valid. Got: ' + JSON.stringify(sp.parse(sp.stringify(settings.SearchQuery))));
        }
    }
    static async testConfig(config) {
        await ConfigDiagnostics.testDatabase(config.Database);
        await ConfigDiagnostics.testSharp();
        await ConfigDiagnostics.testTempFolder(config.Media.tempFolder);
        await ConfigDiagnostics.testVideoConfig(config.Media.Video, config);
        await ConfigDiagnostics.testMetaFileConfig(config.MetaFile, config);
        await ConfigDiagnostics.testAlbumsConfig(config.Album, config);
        await ConfigDiagnostics.testImageFolder(config.Media.folder);
        await ConfigDiagnostics.testThumbnailConfig(config.Media.Thumbnail);
        await ConfigDiagnostics.testSearchConfig(config.Search, config);
        await ConfigDiagnostics.testAlbumCoverConfig(config.AlbumCover);
        await ConfigDiagnostics.testFacesConfig(config.Faces, config);
        await ConfigDiagnostics.testTasksConfig(config.Jobs, config);
        await ConfigDiagnostics.testSharingConfig(config.Sharing, config);
        await ConfigDiagnostics.testRandomPhotoConfig(config.Sharing, config);
        await ConfigDiagnostics.testMapConfig(config.Map);
    }
    static async runDiagnostics() {
        if (process.env['NODE_ENV'] === 'debug') {
            NotifocationManager_1.NotificationManager.warning('You are running the application with NODE_ENV=debug. This exposes a lot of debug information that can be a security vulnerability. Set NODE_ENV=production, when you finished debugging.');
        }
        try {
            await ConfigDiagnostics.testDatabase(Config_1.Config.Database);
        }
        catch (ex) {
            const err = ex;
            Logger_1.Logger.warn(LOG_TAG, '[SQL error]', err.toString());
            Logger_1.Logger.error(LOG_TAG, 'Error during initializing SQL DB, check DB connection and settings');
            process.exit(1);
        }
        try {
            await ConfigDiagnostics.testSharp();
        }
        catch (ex) {
            const err = ex;
            Logger_1.Logger.warn(LOG_TAG, '[Thumbnail hardware acceleration] module error: ', err.toString());
            Logger_1.Logger.warn(LOG_TAG, 'Thumbnail hardware acceleration is not possible.' +
                ' \'sharp\' node module is not found.' +
                ' Falling back temporally to JS based thumbnail generation');
            process.exit(1);
        }
        try {
            await ConfigDiagnostics.testTempFolder(Config_1.Config.Media.tempFolder);
        }
        catch (ex) {
            const err = ex;
            NotifocationManager_1.NotificationManager.error('Thumbnail folder error', err.toString());
            Logger_1.Logger.error(LOG_TAG, 'Thumbnail folder error', err.toString());
        }
        try {
            await ConfigDiagnostics.testVideoConfig(Config_1.Config.Media.Video, Config_1.Config);
        }
        catch (ex) {
            const err = ex;
            NotifocationManager_1.NotificationManager.warning('Video support error, switching off..', err.toString());
            Logger_1.Logger.warn(LOG_TAG, 'Video support error, switching off..', err.toString());
            Config_1.Config.Media.Video.enabled = false;
        }
        try {
            await ConfigDiagnostics.testMetaFileConfig(Config_1.Config.MetaFile, Config_1.Config);
        }
        catch (ex) {
            const err = ex;
            NotifocationManager_1.NotificationManager.warning('Meta file support error, switching off gpx..', err.toString());
            Logger_1.Logger.warn(LOG_TAG, 'Meta file support error, switching off..', err.toString());
            Config_1.Config.MetaFile.gpx = false;
        }
        try {
            await ConfigDiagnostics.testAlbumsConfig(Config_1.Config.Album, Config_1.Config);
        }
        catch (ex) {
            const err = ex;
            NotifocationManager_1.NotificationManager.warning('Albums support error, switching off..', err.toString());
            Logger_1.Logger.warn(LOG_TAG, 'Meta file support error, switching off..', err.toString());
            Config_1.Config.Album.enabled = false;
        }
        try {
            await ConfigDiagnostics.testImageFolder(Config_1.Config.Media.folder);
        }
        catch (ex) {
            const err = ex;
            NotifocationManager_1.NotificationManager.error('Images folder error', err.toString());
            Logger_1.Logger.error(LOG_TAG, 'Images folder error', err.toString());
        }
        try {
            await ConfigDiagnostics.testThumbnailConfig(Config_1.Config.Media.Thumbnail);
        }
        catch (ex) {
            const err = ex;
            NotifocationManager_1.NotificationManager.error('Thumbnail settings error', err.toString());
            Logger_1.Logger.error(LOG_TAG, 'Thumbnail settings error', err.toString());
        }
        try {
            await ConfigDiagnostics.testSearchConfig(Config_1.Config.Search, Config_1.Config);
        }
        catch (ex) {
            const err = ex;
            NotifocationManager_1.NotificationManager.warning('Search is not supported with these settings. Disabling temporally. ' +
                'Please adjust the config properly.', err.toString());
            Logger_1.Logger.warn(LOG_TAG, 'Search is not supported with these settings, switching off..', err.toString());
            Config_1.Config.Search.enabled = false;
        }
        try {
            await ConfigDiagnostics.testAlbumCoverConfig(Config_1.Config.AlbumCover);
        }
        catch (ex) {
            const err = ex;
            NotifocationManager_1.NotificationManager.warning('Cover settings are not valid, resetting search query', err.toString());
            Logger_1.Logger.warn(LOG_TAG, 'Cover settings are not valid, resetting search query', err.toString());
            Config_1.Config.AlbumCover.SearchQuery = {
                type: SearchQueryDTO_1.SearchQueryTypes.any_text,
                text: '',
            };
        }
        try {
            await ConfigDiagnostics.testFacesConfig(Config_1.Config.Faces, Config_1.Config);
        }
        catch (ex) {
            const err = ex;
            NotifocationManager_1.NotificationManager.warning('Faces are not supported with these settings. Disabling temporally. ' +
                'Please adjust the config properly.', err.toString());
            Logger_1.Logger.warn(LOG_TAG, 'Faces are not supported with these settings, switching off..', err.toString());
            Config_1.Config.Faces.enabled = false;
        }
        try {
            await ConfigDiagnostics.testTasksConfig(Config_1.Config.Jobs, Config_1.Config);
        }
        catch (ex) {
            const err = ex;
            NotifocationManager_1.NotificationManager.warning('Some Tasks are not supported with these settings. Disabling temporally. ' +
                'Please adjust the config properly.', err.toString());
            Logger_1.Logger.warn(LOG_TAG, 'Some Tasks not supported with these settings, switching off..', err.toString());
            Config_1.Config.Faces.enabled = false;
        }
        try {
            await ConfigDiagnostics.testSharingConfig(Config_1.Config.Sharing, Config_1.Config);
        }
        catch (ex) {
            const err = ex;
            NotifocationManager_1.NotificationManager.warning('Sharing is not supported with these settings. Disabling temporally. ' +
                'Please adjust the config properly.', err.toString());
            Logger_1.Logger.warn(LOG_TAG, 'Sharing is not supported with these settings, switching off..', err.toString());
            Config_1.Config.Sharing.enabled = false;
        }
        try {
            await ConfigDiagnostics.testRandomPhotoConfig(Config_1.Config.Sharing, Config_1.Config);
        }
        catch (ex) {
            const err = ex;
            NotifocationManager_1.NotificationManager.warning('Random Media is not supported with these settings. Disabling temporally. ' +
                'Please adjust the config properly.', err.toString());
            Logger_1.Logger.warn(LOG_TAG, 'Random Media is not supported with these settings, switching off..', err.toString());
            Config_1.Config.Sharing.enabled = false;
        }
        try {
            await ConfigDiagnostics.testMapConfig(Config_1.Config.Map);
        }
        catch (ex) {
            const err = ex;
            NotifocationManager_1.NotificationManager.warning('Maps is not supported with these settings. Using open street maps temporally. ' +
                'Please adjust the config properly.', err.toString());
            Logger_1.Logger.warn(LOG_TAG, 'Maps is not supported with these settings. Using open street maps temporally ' +
                'Please adjust the config properly.', err.toString());
            Config_1.Config.Map.mapProvider = ClientConfig_1.MapProviders.OpenStreetMap;
        }
    }
}
exports.ConfigDiagnostics = ConfigDiagnostics;
