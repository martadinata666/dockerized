"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventLoopHandler = void 0;
class EventLoopHandler {
    constructor(MAX_LOOP = 10) {
        this.MAX_LOOP = MAX_LOOP;
        this.eventCounter = 0;
    }
    /*
    * setImmediate is slow, but does the right thing
    * next tick is super fast, but does not help much with the event loop as it does not allow a full event loop cycle
    * https://medium.com/dkatalis/eventloop-in-nodejs-settimeout-setimmediate-vs-process-nexttick-37c852c67acb
    * */
    step(fn) {
        this.eventCounter = this.eventCounter % 10;
        const eventFN = this.eventCounter++ === 1 ? setImmediate : process.nextTick;
        eventFN(fn);
    }
}
exports.EventLoopHandler = EventLoopHandler;
